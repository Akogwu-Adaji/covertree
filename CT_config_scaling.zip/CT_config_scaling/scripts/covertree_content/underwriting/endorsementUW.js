let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");
let moment = require("../libraries/moment-with-locales.js")

function getEndorsementUWDecision(data) {
  getendorsment(data);
}

function getendorsment(data) {
  let allExposures = data.policy.exposures;
  let allModifications = data.policy.modifications;
  let uw_state;
  let peril_nbfv;
  let peril_efv;
  let exposure_fv;
  let exposure_fgv;
  let nb_perilLocArray;
  if (data.operation == constantValues.operationConstants.endorsement) {
    for (let exposure of allExposures) {
      exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
      exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
      for (let peril of exposure.perils) {
        let nb_periloc = peril.characteristics[peril.characteristics.length - 1].perilLocator;
        let nb_pericharloc = peril.characteristics[peril.characteristics.length - 1].locator;
        for (let modification of allModifications) {
          if (modification.name == constantValues.endorsementConstants.nb_endorsement) {
            nb_perilLocArray = [];
            let exposureModifications = modification.exposureModifications;
            for (let exposuremod of exposureModifications) {
              for (let perilmod of exposuremod.perilModifications) {
                nb_perilLocArray.push(perilmod.perilLocator);
              }
            }
          }
          if (modification.name == constantValues.endorsementConstants.policy_endorsement) {
            let policy_start_timestamp = modification.effectiveTimestamp;
            let start_date_time = new Date(+policy_start_timestamp);
            start_date_time = moment(start_date_time).format(constantValues.dateFormat.year_month_date);
            let uw_today = new Date();
            uw_today = moment(uw_today).format(constantValues.dateFormat.year_month_date);
            let days_difference = moment(new Date(start_date_time)).diff(new Date(uw_today), 'days', true);
            let exposureModifications = modification.exposureModifications;
            for (let exposuremod of exposureModifications) {
              let perilModifications = exposuremod.perilModifications;
              for (let perilmod of perilModifications) {
                let endors_perilloc = perilmod.perilLocator;
                if (!((nb_perilLocArray.indexOf(endors_perilloc)) > -1)) {
                  if (nb_periloc == endors_perilloc) {
                    if ((exposure.name != constantValues.exposureNameConstants.tenant_occupied) &&
                      (exposure.name != constantValues.exposureNameConstants.policy_level_coverages)) {
                      if (peril.name == constantValues.perilNameConstants.trampoline_liability_extension) {
                        helpers.setUWDecision(constantValues.decisions.uw_none,
                          constantValues.messageConstants.endorsement)
                      }
                      if (peril.name == constantValues.perilNameConstants.diving_board) {
                        helpers.setUWDecision(constantValues.decisions.uw_none,
                          constantValues.messageConstants.endorsement)
                      }
                    }
                    if ((exposure.name == constantValues.exposureNameConstants.landlord_occupied) ||
                      (exposure.name == constantValues.exposureNameConstants.vacant)) {
                      if (peril.name == constantValues.perilNameConstants.landlord_personal_injury) {
                        helpers.setUWDecision(constantValues.decisions.uw_none,
                          constantValues.messageConstants.endorsement)
                      }
                    }
                    if ((exposure.name == constantValues.exposureNameConstants.owner_occupied) ||
                      (exposure.name == constantValues.exposureNameConstants.seasonal_occupied) ||
                      (exposure.name == constantValues.exposureNameConstants.landlord_occupied)) {
                      let uw_unit_address_group = exposure_fv.unit_address;
                      uw_state = exposure_fgv[uw_unit_address_group].state;
                      if (uw_state == constantValues.stateConstants.ohio) {
                        if ((days_difference < constantValues.numberConstants.fifteen) &&
                          (peril.name == constantValues.perilNameConstants.mine_subsidence)) {
                          helpers.setUWDecision(constantValues.decisions.uw_none,
                            constantValues.messageConstants.mine_subsidence)
                        }
                      }
                    }
                  }
                }

              }
            }
          }
          if (modification.name == constantValues.endorsementConstants.policy_endorsement) {
            let exposureModifications = modification.exposureModifications;
            for (let exposuremod of exposureModifications) {
              for (let perilmod of exposuremod.perilModifications) {
                let endors_perilcharloc = perilmod.newPerilCharacteristicsLocator;
                if (nb_pericharloc == endors_perilcharloc) {
                  if ((exposure.name == constantValues.exposureNameConstants.owner_occupied) ||
                    (exposure.name == constantValues.exposureNameConstants.tenant_occupied)) {
                    if (peril.name == constantValues.perilNameConstants.personal_liability) {
                      if (peril.characteristics.length > constantValues.numberConstants.one) {
                        peril_nbfv = peril.characteristics[peril.characteristics.length - 2].fieldValues;
                        peril_efv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
                        let nb_personal_liability = JSON.stringify(peril_nbfv.personal_liability);
                        nb_personal_liability = helpers.removeSpecialCharacters(nb_personal_liability)
                        let uw_endorsed_uw_personal_liability = JSON.stringify(peril_efv.personal_liability);
                        uw_endorsed_uw_personal_liability = helpers.removeSpecialCharacters(uw_endorsed_uw_personal_liability);
                        if (uw_endorsed_uw_personal_liability > nb_personal_liability) {
                          helpers.setUWDecision(constantValues.decisions.uw_none,
                            constantValues.messageConstants.endorsement);
                        }
                      }
                    }
                  }
                  if ((exposure.name == constantValues.exposureNameConstants.seasonal_occupied) ||
                    (exposure.name == constantValues.exposureNameConstants.landlord_occupied) ||
                    (exposure.name == constantValues.exposureNameConstants.vacant)) {
                    if (peril.name == constantValues.perilNameConstants.premises_liability) {
                      if (peril.characteristics.length > constantValues.numberConstants.one) {
                        peril_nbfv = peril.characteristics[peril.characteristics.length - 2].fieldValues;
                        peril_efv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
                        let nb_premises_liability = JSON.stringify(peril_nbfv.premises_liability_limit);
                        nb_premises_liability = helpers.removeSpecialCharacters(nb_premises_liability)
                        let uw_endorsed_uw_premises_liability = JSON.stringify(peril_efv.premises_liability_limit);
                        uw_endorsed_uw_premises_liability = helpers.removeSpecialCharacters(uw_endorsed_uw_premises_liability);
                        if (uw_endorsed_uw_premises_liability > nb_premises_liability) {
                          helpers.setUWDecision(constantValues.decisions.uw_none,
                            constantValues.messageConstants.endorsement);
                        }
                      }
                    }
                  }
                  if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
                    if (peril.name == constantValues.perilNameConstants.medical_payments) {
                      if (peril.characteristics.length > constantValues.numberConstants.one) {
                        peril_nbfv = peril.characteristics[peril.characteristics.length - 2].fieldValues;
                        peril_efv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
                        let nb_medical_payments = JSON.stringify(peril_nbfv.medical_payment_to_others_limit_PerPerson);
                        nb_medical_payments = helpers.removeSpecialCharacters(nb_medical_payments);
                        let uw_endorsed_uw_medical_payments = JSON.stringify(peril_efv.medical_payment_to_others_limit_PerPerson);
                        uw_endorsed_uw_medical_payments = helpers.removeSpecialCharacters(uw_endorsed_uw_medical_payments);
                        if (uw_endorsed_uw_medical_payments > nb_medical_payments) {
                          helpers.setUWDecision(constantValues.decisions.uw_none,
                            constantValues.messageConstants.endorsement);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

exports.getEndorsementUWDecision = getEndorsementUWDecision;