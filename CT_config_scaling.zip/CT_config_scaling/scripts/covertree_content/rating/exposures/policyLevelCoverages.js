"use strict";

let ratingConstants = require("../ratingConstants.js");
let ratingHelpers = require("../helpersRating.js");

function getPremiumForIdentityFraudExpense(peril, exposures)
{
  let exposure;
  let state;
  for (exposure of exposures)
  {
    if (exposure.name != ratingConstants.exposureNameConstants.policy_level_coverages)
    {
      let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
      let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
      let unit_address_group = exposure_fv.unit_address;
      state = exposure_fgv[unit_address_group].state;
      if(state != null)
      {
        break;
      }
    }
  }
  let identity_fraud_expense_premium = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.flat_premium),
    ratingConstants.flatPremiumKeys.identity_fraud_expense));
  return Math.round(identity_fraud_expense_premium);
}

function getPremiumForScheduledPersonalProperty(peril, exposures)
{
  let exposure; 
  let state;
  for (exposure of exposures)
  {
    if (exposure.name != ratingConstants.exposureNameConstants.policy_level_coverages)
    {
      let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
      let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
      let unit_address_group = exposure_fv.unit_address;
      state = exposure_fgv[unit_address_group].state;
    }
  }


  let scheduled_personal_property_premium;
  let stamps_premium = ratingConstants.numberConstants.zero;
  let cameras_premium = ratingConstants.numberConstants.zero;
  let rare_and_current_coins_premium = ratingConstants.numberConstants.zero;
  let fine_arts_premium = ratingConstants.numberConstants.zero;
  let furs_premium = ratingConstants.numberConstants.zero;
  let golf_equipment_premium = ratingConstants.numberConstants.zero;
  let guns_and_ammunition_premium = ratingConstants.numberConstants.zero;
  let jewelry_premium = ratingConstants.numberConstants.zero;
  let musical_instruments_premium = ratingConstants.numberConstants.zero;
  let silverware_premium = ratingConstants.numberConstants.zero;
  let all_other_premium = ratingConstants.numberConstants.zero;
  let tools_premium = ratingConstants.numberConstants.zero;
  let bikes_premium = ratingConstants.numberConstants.zero;
  let computer_equipment_premium = ratingConstants.numberConstants.zero;

  let stamps_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.stamps));
  let cameras_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.cameras));
  let rare_and_current_coins_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.rare_and_current_coins));
  let fine_arts_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.fine_arts));
  let furs_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.furs));
  let golf_equipment_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.golf_equipment));
  let guns_and_ammunition_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.guns_and_ammunition));
  let jewelry_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.jewelry));
  let musical_instruments_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.musical_instruments));
  let silverware_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.silverware));
  let other_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.all_other));
  let tools_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyKeyConstants.tools));
  let bikes_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyKeyConstants.bikes));
  let computer_equipment_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.scheduled_personal_property), ratingConstants.schedulePropertyConstants.computer_equipment));

  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
  let scheduled_personals_group = peril_fv.scheduled_personals;

  if (scheduled_personals_group != null || scheduled_personals_group != undefined)
  {
    for (let each_scheduled_personals_group of scheduled_personals_group)
    {
      let spp_type = peril_fgv[each_scheduled_personals_group].spp_type;
      let spp_value = peril_fgv[each_scheduled_personals_group].spp_value;

      if (spp_type == ratingConstants.schedulePropertyConstants.jewelry)
      {
        jewelry_premium = jewelry_premium + ((spp_value / ratingConstants.numberConstants.hundred) * jewelry_rate);
        jewelry_premium = Math.round(jewelry_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.stamps)
      {
        stamps_premium = stamps_premium + ((spp_value / ratingConstants.numberConstants.hundred) * stamps_rate);
        stamps_premium = Math.round(stamps_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.cameras)
      {
        cameras_premium = cameras_premium + ((spp_value / ratingConstants.numberConstants.hundred) * cameras_rate);
        cameras_premium = Math.round(cameras_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.rare_and_current_coins)
      {
        rare_and_current_coins_premium = rare_and_current_coins_premium + ((spp_value / ratingConstants.numberConstants.hundred) * rare_and_current_coins_rate);
        rare_and_current_coins_premium = Math.round(rare_and_current_coins_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.fine_arts)
      {
        fine_arts_premium = fine_arts_premium + ((spp_value / ratingConstants.numberConstants.hundred) * fine_arts_rate);
        fine_arts_premium = Math.round(fine_arts_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.furs)
      {
        furs_premium = furs_premium + ((spp_value / ratingConstants.numberConstants.hundred) * furs_rate);
        furs_premium = Math.round(furs_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.golf_equipment)
      {
        golf_equipment_premium = golf_equipment_premium + (spp_value / ratingConstants.numberConstants.hundred) * golf_equipment_rate;
        golf_equipment_premium = Math.round(golf_equipment_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.guns_and_ammunition)
      {
        guns_and_ammunition_premium = guns_and_ammunition_premium + (spp_value / ratingConstants.numberConstants.hundred) * guns_and_ammunition_rate;
        guns_and_ammunition_premium = Math.round(guns_and_ammunition_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.musical_instruments)
      {
        musical_instruments_premium = musical_instruments_premium + (spp_value / ratingConstants.numberConstants.hundred) * musical_instruments_rate;
        musical_instruments_premium = Math.round(musical_instruments_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.silverware)
      {
        silverware_premium = silverware_premium + (spp_value / ratingConstants.numberConstants.hundred) * silverware_rate;
        silverware_premium = Math.round(silverware_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.all_other)
      {
        all_other_premium = all_other_premium + (spp_value / ratingConstants.numberConstants.hundred) * other_rate;
        all_other_premium = Math.round(all_other_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.tools)
      {
        tools_premium = tools_premium + (spp_value / ratingConstants.numberConstants.hundred) * tools_rate;
        tools_premium = Math.round(tools_premium);

      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.bikes)
      {
        bikes_premium = bikes_premium + (spp_value / ratingConstants.numberConstants.hundred) * bikes_rate;
        bikes_premium = Math.round(bikes_premium);
      }
      else if (spp_type == ratingConstants.schedulePropertyConstants.computer_equipment)
      {
        computer_equipment_premium = computer_equipment_premium + (spp_value / ratingConstants.numberConstants.hundred) * computer_equipment_rate;
        computer_equipment_premium = Math.round(computer_equipment_premium);
      }
    }
  }

  scheduled_personal_property_premium = jewelry_premium + stamps_premium + cameras_premium + rare_and_current_coins_premium + fine_arts_premium +
    furs_premium + golf_equipment_premium + guns_and_ammunition_premium + musical_instruments_premium + silverware_premium + all_other_premium + tools_premium +
    bikes_premium + computer_equipment_premium;
  return Math.round(scheduled_personal_property_premium);
}

exports.getPremiumForScheduledPersonalProperty = getPremiumForScheduledPersonalProperty;
exports.getPremiumForIdentityFraudExpense = getPremiumForIdentityFraudExpense;