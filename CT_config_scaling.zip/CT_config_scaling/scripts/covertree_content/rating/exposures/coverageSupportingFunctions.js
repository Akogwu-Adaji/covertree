"use strict";

let ratingConstants = require("../ratingConstants.js");
let ratingHelpers = require("../helpersRating.js");

function getNumberOfClaims(policy_start_timestamp, policy_fv, policy_fgv, state)
{
  let number_of_claims_for_discount = ratingConstants.numberConstants.zero;
  let number_of_claims_for_surcharge = ratingConstants.numberConstants.zero;
  if (policy_fv.prior_claims != undefined)
  {
    for (let each_claim of policy_fv.prior_claims)
    {
      let category = policy_fgv[each_claim].category;
      let claim_date = policy_fgv[each_claim].claim_date;
      let claim_amount = parseInt(policy_fgv[each_claim].claim_amount)

      let applicability = socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.loss_chargeable_matrix), category);

      if (applicability == ratingConstants.binaryConstants.yes && claim_amount > ratingConstants.numberConstants.five_hundred && ratingHelpers.getDateOfLoss(claim_date, policy_start_timestamp) <= ratingConstants.numberConstants.three)
      {
        number_of_claims_for_discount = number_of_claims_for_discount + ratingConstants.numberConstants.one;
        number_of_claims_for_surcharge = number_of_claims_for_surcharge + ratingConstants.numberConstants.one;
      }
    }
  }
  return {
    number_of_claims_for_discount,
    number_of_claims_for_surcharge
  }
}

function getPvtFireTaxCreditRetableFactor(exposure_fv,exposure_fgv,coverage_constant,type_constant)
{
  let unit_address_group = exposure_fv.unit_address;
  let state = exposure_fgv[unit_address_group].state;
  let zip_code = exposure_fgv[unit_address_group].zip_code;
  let private_fire_company_tax_credit_discount_factor = ratingConstants.numberConstants.one;
  let private_fire_company_tax_credit_ratable = socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.private_fire_company_tax_credit_zip_codes), zip_code);
  if(private_fire_company_tax_credit_ratable == ratingConstants.binaryConstants.yes)
  {
    let private_fire_company_tax_credit_discount_factor_key = ratingConstants.binaryConstants.yes + ratingConstants.tableToObjectConstants.pipe + coverage_constant ;
    let privateFireCompanyTaxCreditDiscountTable =  ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.private_fire_company_tax_credit_factor), private_fire_company_tax_credit_discount_factor_key);
    private_fire_company_tax_credit_discount_factor = parseFloat(privateFireCompanyTaxCreditDiscountTable[type_constant]);
  }
  else
  {
    let private_fire_company_tax_credit_discount_factor_key = ratingConstants.binaryConstants.no + ratingConstants.tableToObjectConstants.pipe + coverage_constant ;
    let privateFireCompanyTaxCreditDiscountTable =  ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.private_fire_company_tax_credit_factor), private_fire_company_tax_credit_discount_factor_key);
    private_fire_company_tax_credit_discount_factor = parseFloat(privateFireCompanyTaxCreditDiscountTable[type_constant]);
  }
  return private_fire_company_tax_credit_discount_factor;
}
function getTerritoryFactor(territory_code, type_constant, coverage_constant, state)
{
  let territory_factor;
  if (territory_code != null && type_constant == ratingConstants.valueConstants.all_other_perils)
  {
    let territory_code_aop_key = territory_code + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let territoryCodeAOPTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.territory_factor), territory_code_aop_key);
    territory_factor = parseFloat(territoryCodeAOPTable[type_constant]);
  }
  if (territory_code != null && type_constant == ratingConstants.valueConstants.windstorm_or_hail)
  {
    let territory_code_windhail_key = territory_code + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let territoryCodeWindHailTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.territory_factor), territory_code_windhail_key);
    territory_factor = parseFloat(territoryCodeWindHailTable[type_constant]);
  }
  return territory_factor;
}

function getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant, state)
{
  let prior_lapse_surcharge_factor = ratingConstants.numberConstants.one;
  let number_of_days_uninsured;
  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    number_of_days_uninsured = ratingHelpers.getNumberOfDaysUninsuredForTenant(policy_fgv[policy_fv.prior_insurance_details].prior_insurance, policy_fgv[policy_fv.prior_insurance_details].prior_policy_expiration_date);
  }
  number_of_days_uninsured = ratingHelpers.getNumberOfDaysUninsured(exposure_fgv[exposure_fv.unit_details].purchase_date, policy_fgv[policy_fv.prior_insurance_details].prior_insurance, policy_fgv[policy_fv.prior_insurance_details].prior_policy_expiration_date);

  if (policy_term == ratingConstants.numberConstants.one)
  {
    let prior_lapse_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + number_of_days_uninsured + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let priorLapseSurchargeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.prior_lapse_surcharge_factor), prior_lapse_surcharge_factor_key);
    prior_lapse_surcharge_factor = parseFloat(priorLapseSurchargeFactorTable[type_constant]);
  }
  if (policy_term > ratingConstants.numberConstants.one)
  {
    let prior_lapse_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.two + ratingConstants.tableToObjectConstants.pipe + number_of_days_uninsured + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let priorLapseSurchargeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.prior_lapse_surcharge_factor), prior_lapse_surcharge_factor_key);
    prior_lapse_surcharge_factor = parseFloat(priorLapseSurchargeFactorTable[type_constant]);
  }
  return prior_lapse_surcharge_factor;
}

function getAgeOfHomeFactor(policy_start_timestamp, exposure_fgv, exposure_fv, policy_usage, type_constant, coverage_constant, state)
{
  let age_of_home_factor;
  let age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp);
  console.log("🚀 ~ file: coverageSupportingFunctions.js ~ line 102 ~ age_of_home", age_of_home)
  if(age_of_home > ratingConstants.maxValue.home_age)
  {
    if (policy_usage == ratingConstants.usageConstants.tenant)
    {
      let age_of_home_factor_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.home_age + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
    else
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.home_age + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }

  }
  else{
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    let age_of_home_factor_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }
  else
  {
    let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }
}
  return age_of_home_factor;
}

function getAgeOfInsuredFactor(date_of_birth, policy_start_timestamp, type_constant, coverage_constant, state)
{
  let age_of_insured_factor_key = (ratingHelpers.getInsuredAge(date_of_birth, policy_start_timestamp, state) + ratingConstants.tableToObjectConstants.pipe + coverage_constant)
  let ageOfInsuredFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_insured_factor), age_of_insured_factor_key);
  let age_of_insured_factor = parseFloat(ageOfInsuredFactorTable[type_constant]);
  return age_of_insured_factor;
}

function getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant, state)
{
  let calendar_year_modifier_factor = ratingConstants.numberConstants.one;
  if(state != ratingConstants.stateConstants.oh)
  {
  let calendarYearTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.calendar_year_modifier), coverage_constant);
  let calendar_year_modifier = parseFloat(calendarYearTable[type_constant]);

  let max_effective_year = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.maximum_effective_calender_year_table), ratingConstants.tableKeyConstants.rate));
  let effective_year = new Date(+policy_start_timestamp).getFullYear();

  let variable_a;
  if (effective_year <= max_effective_year)
  {
    variable_a = (calendar_year_modifier ** (effective_year - ratingConstants.numberConstants.twenty_twenty_two));
  }
  else if(effective_year > max_effective_year)
  {
    variable_a = (calendar_year_modifier ** (max_effective_year - ratingConstants.numberConstants.twenty_twenty_two));
  }
  if(variable_a > ratingConstants.numberConstants.one)
  {
    calendar_year_modifier_factor = variable_a;
  }
  else
  {
    calendar_year_modifier_factor = ratingConstants.numberConstants.one;
  }  
 }
  return calendar_year_modifier_factor;
}

function getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant, state)
{
  let occasional_vacation_rental_factor = ratingConstants.numberConstants.one;
  let deductible_factor = ratingConstants.numberConstants.one;

  let variable_b;
  let variable_c;
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    let variable_b_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.b + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let variable_c_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.c + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    variable_b = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.aop_variable_factor), variable_b_key));
    variable_c = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.aop_variable_factor), variable_c_key));
  }
  else
  {
    let variable_b_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.b + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let variable_c_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.c + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    variable_b = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.aop_variable_factor), variable_b_key));
    variable_c = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.aop_variable_factor), variable_c_key));
  }

  let aop_deductible;
  let wind_hail_deductible;
  let unscheduled_personal_property_limit;
  let manufactured_home_limit;
  let min_value;

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;

    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      manufactured_home_limit = otherPeril_fv.manufactured_home_limit;
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      unscheduled_personal_property_limit = otherPeril_fv.unscheduled_personal_property_limit;
    }
  }
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    coverage_limit = unscheduled_personal_property_limit;
  }
  else
  {
    coverage_limit = manufactured_home_limit;
  }


  if (state == ratingConstants.stateConstants.mi)
  {
    min_value = ratingConstants.numberConstants.one_point_five;
  }
  else if(state == ratingConstants.stateConstants.oh)
  {
    min_value = ratingConstants.numberConstants.two;
  }
  else if(state == ratingConstants.stateConstants.az)
  {
    min_value = ratingConstants.numberConstants.one_point_two;
  }


  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;

    if (otherPeril.name == ratingConstants.perilNameConstants.deductibles)
    {
      if (type_constant == ratingConstants.valueConstants.all_other_perils)
      {
        aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
        deductible_factor = Math.min(min_value,(variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
      }
      if (type_constant == ratingConstants.valueConstants.all_other_perils && (state == ratingConstants.stateConstants.nm || state == ratingConstants.stateConstants.in))
      { 
        aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
        let equivalent_percent_deductible = aop_deductible/coverage_limit;
        if(equivalent_percent_deductible < ratingConstants.numberConstants.zero_point_one)
        {
          deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
            (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))    
        }
        else if(equivalent_percent_deductible == ratingConstants.numberConstants.zero_point_one)
        {
            deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
            (variable_c * ratingConstants.numberConstants.zero_point_one ** variable_b))  
        }
        else if(equivalent_percent_deductible > ratingConstants.numberConstants.zero_point_one)
        {
            let upper_limit = ratingConstants.numberConstants.one;
            let lower_limit = ratingConstants.numberConstants.zero_point_one;
            let lower_limit_rate = Math.min(ratingConstants.numberConstants.one_point_two,
              (variable_c * ratingConstants.numberConstants.zero_point_one ** variable_b)) 
            lower_limit_rate = lower_limit_rate.toFixed(4);
            let upper_limit_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.aop_greater_deductible), ratingConstants.deductibleInterpolateConstants.deductible_interpolate));        
            deductible_factor = parseFloat(lower_limit_rate) + parseFloat(((upper_limit_rate - lower_limit_rate)/(upper_limit - lower_limit)) * (equivalent_percent_deductible - lower_limit));
        }

      }
      if (type_constant == ratingConstants.valueConstants.windstorm_or_hail)
      {

          if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
          {
          wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
          deductible_factor = Math.min(min_value,(variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
          }
          else if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
          {
            aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
            deductible_factor = Math.min(min_value,(variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
          }
          else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
          {
            wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
            deductible_factor = Math.min(min_value,(variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
          }
          else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
          {
            aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);;
            deductible_factor = Math.min(min_value,(variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
          }
          else
          {
            deductible_factor = ratingConstants.numberConstants.one;
          }
        if(state == ratingConstants.stateConstants.in || state == ratingConstants.stateConstants.nm)
        {
          let equivalent_percent_deductible;
          if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
          {
            aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
            equivalent_percent_deductible = aop_deductible/coverage_limit;
          }
          else if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
          {
            wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
            equivalent_percent_deductible = wind_hail_deductible/coverage_limit;
          }
          else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
          {
            aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
            equivalent_percent_deductible = aop_deductible/coverage_limit;
          }
          else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
          {
            wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
            equivalent_percent_deductible = wind_hail_deductible/coverage_limit;
          }

          if(equivalent_percent_deductible < ratingConstants.numberConstants.zero_point_one)
          {
            if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
            {
            wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
            deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
              (variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
            }
            else if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
            {
              aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
              deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
                (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
            }
            else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
            {
              wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
              deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
                (variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
            }
            else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
            {
              aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);;
              deductible_factor = Math.min(ratingConstants.numberConstants.one_point_two,
                (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
            }
          }
          else if(equivalent_percent_deductible == ratingConstants.numberConstants.zero_point_one)
          {
            deductible_factor =  Math.min(ratingConstants.numberConstants.one_point_two,
              (variable_c * (ratingConstants.numberConstants.zero_point_one) ** variable_b))
          }
          else if(equivalent_percent_deductible > ratingConstants.numberConstants.zero_point_one)
          {
            let upper_limit = ratingConstants.numberConstants.one;
            let lower_limit = ratingConstants.numberConstants.zero_point_one;
            let lower_limit_rate =  Math.min(ratingConstants.numberConstants.one_point_two,
              (variable_c * (ratingConstants.numberConstants.zero_point_one) ** variable_b))
              lower_limit_rate = lower_limit_rate.toFixed(4);
              let upper_limit_rate = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.wind_hail_greater_deductible), ratingConstants.deductibleInterpolateConstants.deductible_interpolate));
              deductible_factor = lower_limit_rate + (((upper_limit_rate - lower_limit_rate)/(upper_limit - lower_limit)) * (equivalent_percent_deductible - lower_limit));
          }
          else
          {
            deductible_factor = ratingConstants.numberConstants.one;
          }
        }


      }
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.vacation_rental_coverage)
    {
      if (otherPeril_fv.occasional_vacation_rental == ratingConstants.binaryConstants.yes)
      {
        let occasional_vacation_rental_key = otherPeril_fv.occasional_vacation_rental + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
        let occasionalVacationRentalTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.occasional_vacation_rental_coverage_factor), occasional_vacation_rental_key);
        occasional_vacation_rental_factor = parseFloat(occasionalVacationRentalTable[type_constant]);
      }
    }
  }
  deductible_factor = parseFloat(deductible_factor).toFixed(4);
  return {
    occasional_vacation_rental_factor,
    deductible_factor
  }

}

function getDistributionChanelFactor(application_intiation, type_constant, coverage_constant, state)
{
  let distribution_channel_factor = ratingConstants.numberConstants.one;
  let channel = ratingHelpers.getChannel(application_intiation);
  if (channel != null)
  {
    let distribution_channel_factor_key = channel + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let distributionChannelFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.distribution_channel_factor), distribution_channel_factor_key);
    distribution_channel_factor = parseFloat(distributionChannelFactorTable[type_constant]);
  }
  return distribution_channel_factor;
}

function getFormFactor(form, type_constant, coverage_constant, state)
{
  let form_factor = ratingConstants.numberConstants.one;
  if (form != null)
  {
    let form_factor_key = (form + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let formFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.form_factor), form_factor_key);
    form_factor = parseFloat(formFactorTable[type_constant]);
  }
  return form_factor;
}

function getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant, policy_usage, state)
{
  let insurance_score_factor = ratingConstants.numberConstants.one;

  if(state == ratingConstants.stateConstants.mi)
  {
    if (insurance_score != null)
    {
      let insurance_score_factor_key = ratingHelpers.getInsuranceScore(insurance_score) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let insuranceScoreFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.insurance_score_factor), insurance_score_factor_key);
      insurance_score_factor = parseFloat(insuranceScoreFactorTable[type_constant]);
    }
  }   
  else
  {
    if (insurance_score != null)
    {
      let insurance_score_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getInsuranceScore(insurance_score) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let insuranceScoreFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.insurance_score_factor), insurance_score_factor_key);
      insurance_score_factor = parseFloat(insuranceScoreFactorTable[type_constant]);
    }
  }
  return insurance_score_factor;
}

function getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant, state)
{
  let home_type_factor = ratingConstants.numberConstants.one;
  if (home_type != null)
  {
    let home_type_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + home_type + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let homeTypeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.home_type_factor), home_type_factor_key);
    home_type_factor = parseFloat(homeTypeFactorTable[type_constant]);
  }
  return home_type_factor;
}

function getOccupancyFactor(policy_usage, type_constant, coverage_constant, state)
{
  let occupancy_factor = ratingConstants.numberConstants.one;
  if (policy_usage != null)
  {
    let occupancy_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let occupancyFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.occupancy_factor), occupancy_factor_key);
    occupancy_factor = parseFloat(occupancyFactorTable[type_constant]);
  }
  return occupancy_factor;
}

function getCommunityStatusFactor(unit_location, type_constant, coverage_constant, state)
{
  let community_status_factor = ratingConstants.numberConstants.one;
  if (unit_location != null)
  {
    let community_status_factor_key = ratingHelpers.getUnitLocation(unit_location) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityStatusFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.community_status_factor), community_status_factor_key);
    community_status_factor = parseFloat(communityStatusFactorTable[type_constant]);
  }
  return community_status_factor;
}

function getRoofConditionFactor(roof_condition, type_constant, coverage_constant, state)
{
  let roof_condition_factor = ratingConstants.numberConstants.one;
  if (roof_condition != null)
  {
    let roof_condition_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let roofConditionFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_conditon_factor_table), roof_condition_factor_key);
    roof_condition_factor = parseFloat(roofConditionFactorTable[type_constant]);
  }
  return roof_condition_factor;
}

function getRoofAgeFactor(policy_start_timestamp, age_of_roof, roof_condition, model_year, type_constant, coverage_constant, state)
{
  let roof_age_factor = ratingConstants.numberConstants.one;
  if (age_of_roof != null && roof_condition != null)
  {
  if(age_of_roof > ratingConstants.maxValue.roof_age)
  {
    let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.roof_age  + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    

    let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);


    roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
  }
   else
   {
    let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;

    let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);

    roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
   }
  }

  return roof_age_factor;
}

function getRoofMaterialFactor(roof_material, type_constant, coverage_constant, state)
{
  let roof_material_factor = ratingConstants.numberConstants.one;
  if (roof_material != null && roof_material != undefined)
  {
    let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_material_factor), roof_material_factor_key);
    roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
  }
  return roof_material_factor;
}

function getSettlementOptionFactor(settlement_option, type_constant, coverage_constant, state)
{
  let settlement_option_factor;
  if (settlement_option != null)
  {
    let settlement_option_factor_key = settlement_option + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let settlementOptionFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.settlement_option_factor), settlement_option_factor_key);
    settlement_option_factor = parseFloat(settlementOptionFactorTable[type_constant]);
  }
  return !isNaN(settlement_option_factor) ? settlement_option_factor : ratingConstants.numberConstants.one;
}

function getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant, state)
{
  let coverage_limit_factor = ratingConstants.numberConstants.one; 
  let lower_limit; 
  let upper_limit;
  if(coverage_limit > ratingConstants.numberConstants.one_lakh_fifty_thousand) 
  {
    upper_limit = ratingConstants.numberConstants.fifty_lakh;
    lower_limit = ratingConstants.numberConstants.one_lakh_fifty_thousand;
  }
  else 
  {
    upper_limit = (Math.ceil(coverage_limit/1000))*1000;
    lower_limit = (Math.floor(coverage_limit/1000))*1000;
  }
  if(coverage_limit == upper_limit || coverage_limit == lower_limit)
  {
    let coverage_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_limit + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let coverageLimitFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.coverage_limit_factor), coverage_limit_factor_key);
    coverage_limit_factor = parseFloat(coverageLimitFactorTable[type_constant]);
  }
  else 
  {
    coverage_limit_factor = ratingHelpers.getInterPolatedFactor(coverage_limit, lower_limit, upper_limit, policy_usage, type_constant, coverage_constant, state);
  }
  return coverage_limit_factor;
}

function getAssociationDiscountFactor(association_discount, type_constant, coverage_constant, state)
{
  let association_discount_factor = ratingConstants.numberConstants.one;
  if (association_discount == ratingConstants.binaryConstants.no)
  {
    let association_discount_factor_key = association_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let associationDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.association_discount_factor), association_discount_factor_key);
    association_discount_factor = parseFloat(associationDiscountFactorTable[type_constant]);
  }
  if (association_discount == ratingConstants.binaryConstants.yes)
  {
    let association_discount_factor_key = association_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let associationDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.association_discount_factor), association_discount_factor_key);
    association_discount_factor = parseFloat(associationDiscountFactorTable[type_constant]);
  }
  return association_discount_factor;
}

function getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant, state)
{
  let claims_free_discount_factor;
  if (number_of_claims_for_discount > 0)
  {
    let claims_free_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsFreeDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.claims_free_discount_factor), claims_free_discount_factor_key);
    claims_free_discount_factor = parseFloat(claimsFreeDiscountFactorTable[type_constant]);
  }
  else if (number_of_claims_for_discount == 0)
  {
    let claims_free_discount_factor_key = ratingConstants.numberConstants.zero + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsFreeDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.claims_free_discount_factor), claims_free_discount_factor_key);
    claims_free_discount_factor = parseFloat(claimsFreeDiscountFactorTable[type_constant]);
  }
  return claims_free_discount_factor;
}

function getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant, state)
{
  let community_policy_discount_factor = ratingConstants.numberConstants.one;
  if (community_policy_discount == ratingConstants.binaryConstants.no)
  {
    let community_policy_discount_factor_key = community_policy_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityPolicyDiscountTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.community_policy_discount_factor), community_policy_discount_factor_key);
    community_policy_discount_factor = parseFloat(communityPolicyDiscountTable[type_constant]);
  }
  if (community_policy_discount == ratingConstants.binaryConstants.yes)
  {
    let community_policy_discount_factor_key = community_policy_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityPolicyDiscountTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.community_policy_discount_factor, community_policy_discount_factor_key);
    community_policy_discount_factor = parseFloat(communityPolicyDiscountTable[type_constant]);
  }
  return community_policy_discount_factor;
}

function getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant, state)
{
  let multi_policy_discount_factor;
  if (multi_policy_discount == ratingConstants.binaryConstants.no)
  {
    let multi_policy_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiPolicyDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.multi_policy_discount_factor), multi_policy_discount_factor_key);
    multi_policy_discount_factor = parseFloat(multiPolicyDiscountFactorTable[type_constant]);
  }
  else if (multi_policy_discount == ratingConstants.binaryConstants.yes)
  {
    let multi_policy_discount_factor_key = ratingConstants.numberConstants.two + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiPolicyDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.multi_policy_discount_factor), multi_policy_discount_factor_key);
    multi_policy_discount_factor = parseFloat(multiPolicyDiscountFactorTable[type_constant]);
  }
  return multi_policy_discount_factor;
}

function getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant, state)
{
  let multi_unit_discount_factor;
  if (num_of_exposures == ratingConstants.numberConstants.one)
  {
    let multi_unit_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiUnitDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.multi_unit_discount_factor), multi_unit_discount_factor_key);
    multi_unit_discount_factor = parseFloat(multiUnitDiscountFactorTable[type_constant]);
  }
  else if (num_of_exposures > ratingConstants.numberConstants.one && num_of_exposures <= ratingConstants.maxValue.multi_unit_discount)
  {
    let multi_unit_discount_factor_key = num_of_exposures + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiUnitDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.multi_unit_discount_factor), multi_unit_discount_factor_key);
    multi_unit_discount_factor = parseFloat(multiUnitDiscountFactorTable[type_constant]);
  }
  else if(num_of_exposures > ratingConstants.maxValue.multi_unit_discount)
  {
    let multi_unit_discount_factor_key = ratingConstants.maxValue.multi_unit_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiUnitDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.multi_unit_discount_factor), multi_unit_discount_factor_key);
    multi_unit_discount_factor = parseFloat(multiUnitDiscountFactorTable[type_constant]);
  }
  return multi_unit_discount_factor;
}

function getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant, state)
{
  let paid_in_full_discount_factor = ratingConstants.numberConstants.one;
  if (payment_schedule == ratingConstants.paymentConstants.full_pay)
  {
    let paid_in_full_discount_factor_key = ratingConstants.paymentConstants.full_pay + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let paidInFullDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.paid_in_full_discount_factor), paid_in_full_discount_factor_key);
    paid_in_full_discount_factor = parseFloat(paidInFullDiscountFactorTable[type_constant]);
  }
  else if(payment_schedule == ratingConstants.paymentConstants.mortgage_bill)
  {
    let paid_in_full_discount_factor_key = ratingConstants.paymentConstants.lienholder_billed + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let paidInFullDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.paid_in_full_discount_factor), paid_in_full_discount_factor_key);
    paid_in_full_discount_factor = parseFloat(paidInFullDiscountFactorTable[type_constant]);
  }
  else if(payment_schedule == ratingConstants.paymentConstants.two_pay || payment_schedule == ratingConstants.paymentConstants.eleven_pay)
  {
    let paid_in_full_discount_factor_key = ratingConstants.paymentConstants.payment_plan + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let paidInFullDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.paid_in_full_discount_factor), paid_in_full_discount_factor_key);
    paid_in_full_discount_factor = parseFloat(paidInFullDiscountFactorTable[type_constant]);
  }

  return paid_in_full_discount_factor;
}

function getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant,state)
{
  let claims_surcharge_factor;
  if (number_of_claims_for_surcharge <= ratingConstants.maxValue.claims_surcharge)
  {
    let schedule;
    if (exposure.name == ratingConstants.exposureNameConstants.vacant)
    {
      schedule = ratingHelpers.getSchedule(exposures);
    }
    else
    {
      schedule = ratingConstants.alphabetConstants.na;
    }
    let claims_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + schedule + ratingConstants.tableToObjectConstants.pipe + number_of_claims_for_surcharge + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsSurchargeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.claims_surcharge_factor), claims_surcharge_factor_key);
    claims_surcharge_factor = parseFloat(claimsSurchargeFactorTable[type_constant]);
  }
  else 
  {
    let schedule;
    if (exposure.name == ratingConstants.exposureNameConstants.vacant)
    {
      schedule = ratingHelpers.getSchedule(exposures);
    }
    else
    {
      schedule = ratingConstants.alphabetConstants.na;
    }
    let claims_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + schedule + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.claims_surcharge + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsSurchargeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.claims_surcharge_factor), claims_surcharge_factor_key);
    claims_surcharge_factor = parseFloat(claimsSurchargeFactorTable[type_constant]);
  }

  return claims_surcharge_factor;
}

function getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant, state)
{
  let short_term_rental_surcharge_factor;
  let short_term_rental_surcharge = ratingConstants.binaryConstants.no;
  if (exposure.name == ratingConstants.exposureNameConstants.landlord_occupied)
  {
    short_term_rental_surcharge = exposure_fgv[exposure_fv.usage].short_term_rental_surcharge;
  }
  if (short_term_rental_surcharge == ratingConstants.binaryConstants.yes)
  {
    let short_term_rental_surcharge_key = ratingConstants.binaryConstants.yes + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let shortTermRentalSurchargeTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.short_term_rental_surcharge_factor), short_term_rental_surcharge_key);
    short_term_rental_surcharge_factor = parseFloat(shortTermRentalSurchargeTable[type_constant]);
  }
  else
  {
    let short_term_rental_surcharge_key = ratingConstants.binaryConstants.no + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let shortTermRentalSurchargeTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.short_term_rental_surcharge_factor), short_term_rental_surcharge_key);
    short_term_rental_surcharge_factor = parseFloat(shortTermRentalSurchargeTable[type_constant]);
  }
  return short_term_rental_surcharge_factor;
}

function getPaperlessDiscountFactor(paperless_discount, policy_usage, coverage_constant, state)
{
  let paperless_discount_factor = ratingConstants.numberConstants.zero;
  if (policy_usage != ratingConstants.usageConstants.tenant && coverage_constant != ratingConstants.coverageConstants.coverage_c || policy_usage == ratingConstants.usageConstants.tenant  && coverage_constant == ratingConstants.coverageConstants.coverage_c)
  {
    if (paperless_discount == ratingConstants.binaryConstants.yes)
    {
      let paperless_discount_factor_key = paperless_discount + ratingConstants.tableToObjectConstants.pipe + policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      paperless_discount_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.paperless_discount_factor), paperless_discount_factor_key));
    }
    else if (paperless_discount == ratingConstants.binaryConstants.no)
    {
      let paperless_discount_factor_key = paperless_discount + ratingConstants.tableToObjectConstants.pipe + policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      paperless_discount_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.paperless_discount_factor), paperless_discount_factor_key));
    }
  }
  return paperless_discount_factor;
}

function getSupplementalHeatingSurchargeFactor(source_of_heat, coverage_constant, state)
{
  let supplemental_heating_surcharge_factor = ratingConstants.numberConstants.zero;

  if (source_of_heat == ratingConstants.binaryConstants.yes)
  {
    let supplemental_heating_surcharge_factor_key = ratingConstants.binaryConstants.yes + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    supplemental_heating_surcharge_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.supplemental_heating_surcharge_factor), supplemental_heating_surcharge_factor_key));
  }
  else if (source_of_heat == ratingConstants.binaryConstants.no)
  {
    let supplemental_heating_surcharge_factor_key = ratingConstants.binaryConstants.no + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    supplemental_heating_surcharge_factor = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.supplemental_heating_surcharge_factor), supplemental_heating_surcharge_factor_key));
  }
  return supplemental_heating_surcharge_factor;
}

function getHomeDiscountFactor(home_discount, type_constant, coverage_constant, state)
{
  let home_discount_key = home_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let homeDiscountFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.home_discount_factor), home_discount_key);
  let home_discount_factor = parseFloat(homeDiscountFactorTable[type_constant]);

  return home_discount_factor;
}

function getWroughtIronBarDiscountFactor(wrought_iron, form, coverage_constant, type_constant, state)
{
  let wrought_iron_key = form + ratingConstants.tableToObjectConstants.pipe  + wrought_iron + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let wroughtIronTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.wrought_iron_bar_discount_factor), wrought_iron_key);
  let wrought_iron_discount_factor = parseFloat(wroughtIronTable[type_constant]);

  return !isNaN(wrought_iron_discount_factor) ? wrought_iron_discount_factor : ratingConstants.numberConstants.one;
}
function getBurglarAlarmDiscountFactor(burglar_alarm, form, coverage_constant, type_constant, state)
{
  let burglar_alarm_key = form + ratingConstants.tableToObjectConstants.pipe  + burglar_alarm + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let BurglarAlarmTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.burglar_alarm_discount_factor), burglar_alarm_key);
  let burglar_alarm_discount_factor = parseFloat(BurglarAlarmTable[type_constant]);

  return !isNaN(burglar_alarm_discount_factor) ? burglar_alarm_discount_factor : ratingConstants.numberConstants.one;
}
exports.getBurglarAlarmDiscountFactor = getBurglarAlarmDiscountFactor;
exports.getWroughtIronBarDiscountFactor = getWroughtIronBarDiscountFactor;
exports.getHomeDiscountFactor = getHomeDiscountFactor;
exports.getFormFactor = getFormFactor;
exports.getRoofAgeFactor = getRoofAgeFactor;
exports.getNumberOfClaims = getNumberOfClaims;
exports.getHomeTypeFactor = getHomeTypeFactor;
exports.getAgeOfHomeFactor = getAgeOfHomeFactor;
exports.getOccupancyFactor = getOccupancyFactor;
exports.getTerritoryFactor = getTerritoryFactor;
exports.getAgeOfInsuredFactor = getAgeOfInsuredFactor;
exports.getRoofMaterialFactor = getRoofMaterialFactor;
exports.getRoofConditionFactor = getRoofConditionFactor;
exports.getCoverageLimitFactor = getCoverageLimitFactor;
exports.getCalendarYearModifier = getCalendarYearModifier;
exports.getInsuranceScoreFactor = getInsuranceScoreFactor;
exports.getClaimsSurchargeFactor = getClaimsSurchargeFactor;
exports.getCommunityStatusFactor = getCommunityStatusFactor;
exports.getSettlementOptionFactor = getSettlementOptionFactor;
exports.getPaperlessDiscountFactor = getPaperlessDiscountFactor;
exports.getMultiUnitDiscountFactor = getMultiUnitDiscountFactor;
exports.getDistributionChanelFactor = getDistributionChanelFactor;
exports.getPaidInFullDiscountFactor = getPaidInFullDiscountFactor;
exports.getClaimsFreeDiscountFactor = getClaimsFreeDiscountFactor;
exports.getPriorLapseSurchageFactor = getPriorLapseSurchageFactor;
exports.getMultiPolicyDiscountFactor = getMultiPolicyDiscountFactor;
exports.getAssociationDiscountFactor = getAssociationDiscountFactor;
exports.getPvtFireTaxCreditRetableFactor = getPvtFireTaxCreditRetableFactor;
exports.getCommunityPolicyDiscountFactor = getCommunityPolicyDiscountFactor;
exports.getShortTermRentalSurchargeFactor = getShortTermRentalSurchargeFactor;
exports.getSupplementalHeatingSurchargeFactor = getSupplementalHeatingSurchargeFactor;
exports.getAOPorWindDeductibleFactorandOccasionalRenatalFactor = getAOPorWindDeductibleFactorandOccasionalRenatalFactor;