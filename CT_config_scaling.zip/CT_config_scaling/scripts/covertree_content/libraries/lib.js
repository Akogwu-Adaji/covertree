"use strict";

function polyfill()
{
  // For flat() and flatMap() see https://github.com/jonathantneal/array-flat-polyfill
  if (!Array.prototype.flat)
  {
    Object.defineProperty(Array.prototype, 'flat',
    {
      configurable: true,
      value: function flat()
      {
        var depth = isNaN(arguments[0]) ? 1 : Number(arguments[0]);
        return depth ? Array.prototype.reduce.call(this, function(acc, cur)
        {
          if (Array.isArray(cur)) acc.push.apply(acc, flat.call(cur, depth - 1));
          else acc.push(cur);
          return acc;
        }, []) : Array.prototype.slice.call(this);
      },
      writable: true
    });
  }
  if (!Array.prototype.flatMap)
  {
    Object.defineProperty(Array.prototype, 'flatMap',
    {
      configurable: true,
      value: function flatMap(mapFn)
      {
        return Array.prototype.map.apply(this, arguments).flat();
      },
      writable: true
    });
  }
  if (!Array.prototype.groupBy)
  {
    Object.defineProperty(Array.prototype, 'groupBy',
    {
      configurable: true,
      value: function groupBy(keyFn, valFn)
      {
        return Array.prototype.reduce.call(this, function(map, item)
        {
          let key = keyFn(item);
          let arr = map.has(key) ? map.get(key) : [];
          arr.push(valFn(item));
          map.set(key, arr);
          return map;
        }, new Map());
      }
    });
  }
  if (!Array.prototype.sum)
  {
    Object.defineProperty(Array.prototype, 'sum',
    {
      configurable: true,
      value: function sum(evalFn = x => x)
      {
        return this.reduce((sum, x) => sum + evalFn(x), 0);
      }
    });
  }
  if (!Array.prototype.min)
  {
    Object.defineProperty(Array.prototype, 'min',
    {
      configurable: true,
      value: function min(evalFn = x => x)
      {
        return this.reduce((min, x) => Math.min(evalFn(x), min), Infinity)
      }
    });
  }
  if (!Array.prototype.max)
  {
    Object.defineProperty(Array.prototype, 'max',
    {
      configurable: true,
      value: function max(evalFn = x => x)
      {
        return this.reduce((max, x) => Math.max(evalFn(x), max), -Infinity)
      }
    });
  }
  if (!Array.prototype.count)
  {
    Object.defineProperty(Array.prototype, 'count',
    {
      configurable: true,
      value: function count(evalFn)
      {
        return (evalFn == null) ? this.length : this.filter(evalFn).length;
      }
    });
  }
}

function getIntVal(arg, defaultVal = 0)
{
  if (arg == null) return defaultVal;
  else if (Array.isArray(arg)) return parseInt(arg[0], 10);
  else return parseInt(arg, 10);
}

function getFloatVal(arg, defaultVal = 0.0)
{
  if (arg == null) return defaultVal;
  else if (Array.isArray(arg)) return parseFloat(arg[0]);
  else return parseFloat(arg);
}

function round2(num)
{
  return Math.round(num * 100) / 100.0;
}

function isNear(num1, num2)
{
  return Math.abs(num1 - num2) < 0.00000001;
}
/**
 * Calculates human age in years given a birth day. Optionally ageAtDate
 * can be provided to calculate age at a specific date
 *
 * @param string|Date Object birthDate
 * @param string|Date Object ageAtDate optional
 * @returns integer Age between birthday and a given date or today
 */
function getAge(birthDate, ageAtDate)
{
  // convert birthDate to date object if already not
  if (Object.prototype.toString.call(birthDate) !== '[object Date]') birthDate = new Date(birthDate);
  // use today's date if ageAtDate is not provided
  if (typeof ageAtDate == "undefined") ageAtDate = new Date();
  // convert ageAtDate to date object if already not
  else if (Object.prototype.toString.call(ageAtDate) !== '[object Date]') ageAtDate = new Date(ageAtDate);
  // if conversion to date object fails return null
  if (ageAtDate == null || birthDate == null) return null;
  var monthDelta = ageAtDate.getMonth() - birthDate.getMonth();
  // answer: ageAt year minus birth year less one (1) if month and day of
  // ageAt year is before month and day of birth year
  return (ageAtDate.getFullYear()) - birthDate.getFullYear() - ((monthDelta < 0 || (monthDelta === 0 && ageAtDate.getDate() < birthDate.getDate())) ? 1 : 0)
}
exports.polyfill = polyfill;
exports.getIntVal = getIntVal;
exports.getFloatVal = getFloatVal;
exports.round2 = round2;
exports.isNear = isNear;
exports.getAge = getAge;