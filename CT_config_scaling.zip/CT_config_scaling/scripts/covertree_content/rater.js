"use strict";

let ratingCalculations = require("./rating/ratingCalculations.js");

function getPerilRates(data)
{
  let result = ratingCalculations.getPerilRates(data);
  return result;
}

exports.getPerilRates = getPerilRates;