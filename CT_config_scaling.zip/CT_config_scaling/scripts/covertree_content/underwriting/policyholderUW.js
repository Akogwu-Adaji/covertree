let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");

function getPolicyHolderDecision(data) {
  getHomeowners(data)
}

function getHomeowners(data) {
  let values = data.policyholder.entity.values;
  let uw_relationship_organization;
  if (values.type_of_insured != constantValues.policyValueConstants.person) {
    if (values.relationship_organization != undefined) {
      uw_relationship_organization = values.relationship_organization;
    } else {
      uw_relationship_organization = helpers.getPolicyholderFieldValue("relationship_organization", values);
    }
    if (uw_relationship_organization == constantValues.policyValueConstants.other) {
      helpers.setUWDecision(constantValues.decisions.uw_none,
        constantValues.messageConstants.relationship_organization);
    }
  }
}

exports.getPolicyHolderDecision = getPolicyHolderDecision;