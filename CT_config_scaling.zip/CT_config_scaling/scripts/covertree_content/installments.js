let arrays = require("./libraries/arrays.js");
let dates = require('./libraries/dates.js');
let installmentConstants = require("./constants/constants.js");
let moment = require("./libraries/moment-with-locales.js");
let constantValues = require("./underwriting/ruleComparisionFactors.js");
const {
  addDays
} = require("./underwriting/helpersUW.js");

function createInstallments(data) {
  arrays.polyfill();

  let installments;
  if (data.operation == installmentConstants.operationConstants.new_business || data.operation == installmentConstants.operationConstants.fee_assessment) {
    switch (data.paymentScheduleName) {
      case installmentConstants.paymentScheduleConstants.mortgage:
        installments = getUpfrontMortgage(data);
        break;
      case installmentConstants.paymentScheduleConstants.full_pay:
        installments = getUpfront(data);
        break;
      case installmentConstants.paymentScheduleConstants.two_pay:
        installments = getTwoInstallments(data, installmentConstants.termConstants.semiannually, installmentConstants.numberConstants.two);
        break;
      case installmentConstants.paymentScheduleConstants.eleven_pay:
        installments = getElevenInstallments(data, installmentConstants.termConstants.month, installmentConstants.numberConstants.eleven);
        break;
      default:
        throw installmentConstants.termConstants.exception;
    }
  } else if (data.operation == installmentConstants.operationConstants.endorsement) {
    switch (data.paymentScheduleName) {
      case installmentConstants.paymentScheduleConstants.mortgage:
        installments = getUpfrontMortgageendorsement(data);
        break;
      case installmentConstants.paymentScheduleConstants.full_pay:
        installments = getUpfrontendorsement(data);
        break;
      case installmentConstants.paymentScheduleConstants.two_pay:
        installments = getTwoInstallmentsEndorsement(data, installmentConstants.termConstants.semiannually, installmentConstants.numberConstants.two);
        break;
      case installmentConstants.paymentScheduleConstants.eleven_pay:
        installments = getElevenInstallmentEndorsement(data, installmentConstants.termConstants.month, installmentConstants.numberConstants.eleven);
        break;
      default:
        throw installmentConstants.termConstants.exception;
    }
  } else if (data.operation == installmentConstants.operationConstants.cancellation || data.operation == installmentConstants.operationConstants.renewal ||
    data.operation == installmentConstants.operationConstants.reinstatement) {
    installments = getUpfront(data);
  }
  return {
    installments: installments
  };
}

function getUpfrontMortgage(data) {
  let invoiceItems = data.charges.map(ch => ({
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  let duetimestamp = data.coverageStartTimestamp;
  duetimestamp = new Date(+duetimestamp);
  let setdueTimestamp = addDays(duetimestamp, 30);
  setdueTimestamp = new Date(setdueTimestamp).getTime();

  return [{
    dueTimestamp: setdueTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    writeOff: false
  }];
}

function getUpfront(data) {
  let invoiceItems = data.charges.map(ch => ({
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  return [{
    dueTimestamp: data.coverageStartTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    writeOff: false
  }];
}

function getUpfrontMortgageendorsement(data) {
  let invoiceItems = data.charges.map(ch => ({
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  let duetimestamp = data.coverageStartTimestamp;
  duetimestamp = new Date(+duetimestamp);
  let setdueTimestamp = addDays(duetimestamp, 30);
  setdueTimestamp = new Date(setdueTimestamp).getTime();

  let amount = getinspectionFees(data);
  installmentFees = [{
      feeName: installmentConstants.feeConstants.inspection_fee_aerial,
      description: "Aerial",
      amount: amount.aerial_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_interior,
      description: "Interior",
      amount: amount.interior_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_exterior,
      description: "Exterior",
      amount: amount.exterior_fee
    }
  ];

  return [{
    dueTimestamp: setdueTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    installmentFees : installmentFees,
    writeOff: false
  }];
}

function getUpfrontendorsement(data) {
  let invoiceItems = data.charges.map(ch => ({
    amount: ch.amount,
    chargeId: ch.chargeId
  }));

  let amount = getinspectionFees(data);
  installmentFees = [{
      feeName: installmentConstants.feeConstants.inspection_fee_aerial,
      description: "Aerial",
      amount: amount.aerial_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_interior,
      description: "Interior",
      amount: amount.interior_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_exterior,
      description: "Exterior",
      amount: amount.exterior_fee
    }
  ];

  return [{
    dueTimestamp: data.coverageStartTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    installmentFees : installmentFees,
    writeOff: false
  }];
}


function getTwoInstallments(data, increment, maxInstallments = installmentConstants.numberConstants.thousand) {
  let nowTimestamp = new Date().getTime();

  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));

  if (installmentTimestamps.length == installmentConstants.numberConstants.zero)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(installmentConstants.numberConstants.zero, maxInstallments);

  let installments = [];
  let setissuetimestamp;
  for (let i = 0; i < installmentTimestamps.length; i++) {
    let it = installmentTimestamps[i];
    if (i == 0) {
      setissuetimestamp = it;
    } else {
      setissuetimestamp = addDays(it, -20);
    }
    setissuetimestamp = new Date(setissuetimestamp).getTime();
    installments.push({
      invoiceItems: [],
      dueTimestamp: it,
      startTimestamp: it,
      issueTimestamp: setissuetimestamp,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: false
    });
  }

  for (charge of data.charges) {
    let newItems = [];
    for (let i = 0; i < installments.length; i++) {
      if (charge.coverageStartTimestamp <= installments[i].dueTimestamp &&
        charge.coverageEndTimestamp >= installments[i].dueTimestamp) {
        let newItem = {
          chargeId: charge.chargeId
        };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }

    }

    if (newItems.length == installmentConstants.numberConstants.zero) {
      // No installments fell within the charge coverage time, so find one
      let item = {
        chargeId: charge.chargeId,
        amount: parseFloat(charge.amount)
      };
      let inst;
      for (let i = 0; i < installments.length; i++)
        if (installments[i].dueTimestamp <= charge.coverageStartTimestamp) {
          inst = installments[i];
          break;
        }
      if (inst === undefined)
        inst = installments[0];
      inst.invoiceItems.push(item);
    } else {
      let amount = parseFloat(charge.amount);
      newItems[0].amount = getTwoPayDownPayment(charge);
      newItems[1].amount = round2(amount - newItems.slice(0, 1).sum(ni => ni.amount));
    }
  }
  for (let i = 1; i < installments.length; i++) {
    installments[i].installmentFees = [{
      feeName: installmentConstants.feeConstants.two_pay_fee,
      description: "2-Pay",
      amount: 6
    }];
  }
  return installments.filter(inst => inst.invoiceItems.length > 0);
}

function getTwoInstallmentsEndorsement(data, increment, maxInstallments = installmentConstants.numberConstants.thousand) {
  let nowTimestamp = new Date().getTime();
  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));
  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);
  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));
  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
  let installments = [];
  let setissuetimestamp;
  let setstarttimestamp;
  let timestamps = 0;
  let prev_amount = 0;
  let total_amount = 0;
  let unprorated_amount=0;
  let times_date;
  let cov_date;
  let start_date;
  for (let i = 0; i < installmentTimestamps.length; i++) {
    cov_date = new Date(+data.coverageStartTimestamp);
    cov_date = moment(cov_date).format(constantValues.dateFormat.year_month_date);
    start_date = new Date(+startTimestamp);
    start_date = moment(start_date).format(constantValues.dateFormat.year_month_date);
    times_date = new Date(installmentTimestamps[i]);
    times_date = moment(times_date).format(constantValues.dateFormat.year_month_date);
    if ((installmentTimestamps[i] < data.coverageStartTimestamp) &&
      (data.coverageStartTimestamp < installmentTimestamps[i + 1])) {
      timestamps = i;
      break;
    }
    if (i == installmentTimestamps.length - 1) {
      if ((installmentTimestamps[i] < data.coverageStartTimestamp) &&
        (data.coverageStartTimestamp < endTimestamp)) {
        timestamps = i;
        break;
      }
    }
    if (times_date === cov_date) {
      timestamps = i;
      break;
    }
    if (data.policy.invoices[i] == undefined) {
      timestamps = i;
      break;
    }
  }
  for (let i = timestamps; i < installmentTimestamps.length; i++) {
    let it = installmentTimestamps[i];
    if (data.policy.invoices[i] == undefined) {
      setstarttimestamp = it;
      setissuetimestamp = addDays(it, -20);
    } else if (i == timestamps && it != data.coverageStartTimestamp) {
      setstarttimestamp = data.coverageStartTimestamp;
      setissuetimestamp = data.coverageStartTimestamp;
    } else if (i == timestamps && times_date === cov_date && cov_date !== start_date) {
      setstarttimestamp = it
      setissuetimestamp = addDays(it, -20);
    } else if (i == timestamps && cov_date == start_date) {
      setstarttimestamp = data.coverageStartTimestamp;
      setissuetimestamp = data.coverageStartTimestamp;
    } else if (data.policy.invoices[i] != undefined) {
      setstarttimestamp = it;
      setissuetimestamp = it;
    } else {
      setstarttimestamp = it;
      setissuetimestamp = addDays(it, -20);
    }

    setstarttimestamp = new Date(+setstarttimestamp).getTime();
    setissuetimestamp = new Date(+setissuetimestamp).getTime();

    installments.push({
      invoiceItems: [],
      dueTimestamp: setstarttimestamp,
      startTimestamp: setstarttimestamp,
      issueTimestamp: setissuetimestamp,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: false
    });

  }

  for (charge of data.charges) {
    let newItems = [];
    for (let i = 0; i < installments.length; i++) {
      if (charge.coverageEndTimestamp > charge.coverageStartTimestamp) {
        let newItem = {
          chargeId: charge.chargeId
        };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }
    }

    if (((charge.coverageStartTimestamp == data.coverageStartTimestamp) &&
        (data.coverageEndTimestamp == endTimestamp)) && (charge.isNew == true) && (charge.type == "premium")) {
      for (let i = 0; i < data.charges.length; i++) {
        if ((data.charges[i].isNew == true) && (data.charges[i].type == charge.type) && (data.charges[i].perilLocator == charge.perilLocator)) {
          if ((data.charges[i].coverageStartTimestamp == startTimestamp) &&
            (data.charges[i].coverageEndTimestamp == data.coverageStartTimestamp) && (data.charges[i].type == "premium") && (data.charges[i].isNew == true)) {
            prev_amount = 0;
            prev_amount = parseFloat(data.charges[i].amount);
          } else if ((data.charges[i].coverageStartTimestamp == startTimestamp) &&
            (data.charges[i].coverageEndTimestamp == endTimestamp) && (data.charges[i].type == "premium") && (data.charges[i].isNew == true) && (data.charges[i].amount < 0)) {
            total_amount = 0;
            total_amount = parseFloat(data.charges[i].amount);
            if (charge.amount != 0) {
              if (total_amount < 0) {
                total_amount = (-(total_amount))
              }
            }

          }
          if ((total_amount != 0) && (prev_amount != 0)) {
            if (total_amount < 0) {
              unprorated_amount = (total_amount + prev_amount);
            } else {
              unprorated_amount = (total_amount - prev_amount);
            }
          } else {
            unprorated_amount = total_amount - prev_amount;
          }
        }
      }
    }

    let amount = parseFloat(charge.amount);
    let down_payment;
    if (((charge.coverageStartTimestamp == data.coverageStartTimestamp) &&
        (data.coverageEndTimestamp == endTimestamp)) && (charge.isNew == true) && (charge.type == "premium")) {
      if (charge.perilName != installmentConstants.perilNameConstants.trip_collision) {
        down_payment = getProratedPremium(data, charge, unprorated_amount, increment, maxInstallments);
      } else if (charge.perilName == installmentConstants.perilNameConstants.trip_collision) {
        down_payment = round2(parseFloat(charge.amount));
      }
    } else {
      down_payment = 0;
    }
    for (let i = 0; i < newItems.length; i++) {
      if (i < newItems.length - 1) {
        newItems[i].amount = down_payment;
      } else {
        newItems[i].amount = round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));
      }
    }
  }

  let amount = getinspectionFees(data);
  installments[0].installmentFees = [{
      feeName: installmentConstants.feeConstants.inspection_fee_aerial,
      description: "Aerial",
      amount: amount.aerial_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_interior,
      description: "Interior",
      amount: amount.interior_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_exterior,
      description: "Exterior",
      amount: amount.exterior_fee
    }
  ];

  return installments.filter(inst => inst.invoiceItems.length > 0);
}

function getTwoPayDownPayment(charge) {
  let fraction = 0;
  if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
    let amount = parseFloat(charge.amount);
    return amount;
  } else if (charge.perilName == installmentConstants.perilNameConstants.trip_collision) {
    let amount = parseFloat(charge.amount);
    return amount;
  } else {
    let amount = parseFloat(charge.amount);
    fraction = round2(0.5479 * amount);
    return fraction;
  }
}

function getElevenInstallments(data, increment, maxInstallments = installmentConstants.numberConstants.thousand) {
  let nowTimestamp = new Date().getTime();

  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));

  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);

  let installments = [];
  let setissuetimestamp;
  for (let i = 0; i < installmentTimestamps.length; i++) {
    let it = installmentTimestamps[i];
    if (i == 0) {
      setissuetimestamp = it;
    } else {
      setissuetimestamp = addDays(it, -20);
    }
    setissuetimestamp = new Date(setissuetimestamp).getTime();
    installments.push({
      invoiceItems: [],
      dueTimestamp: it,
      startTimestamp: it,
      issueTimestamp: setissuetimestamp,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: false
    });
  }

  for (charge of data.charges) {
    let newItems = [];
    for (let i = 0; i < installments.length; i++) {
      if (charge.coverageStartTimestamp <= installments[i].dueTimestamp &&
        charge.coverageEndTimestamp >= installments[i].dueTimestamp) {
        let newItem = {
          chargeId: charge.chargeId
        };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }
    }

    if (newItems.length == 0) {
      // No installments fell within the charge coverage time, so find one
      let item = {
        chargeId: charge.chargeId,
        amount: parseFloat(charge.amount)
      };
      let inst;
      for (let i = 0; i < installments.length; i++)
        if (installments[i].dueTimestamp <= charge.coverageStartTimestamp) {
          inst = installments[i];
          break;
        }
      if (inst === undefined)
        inst = installments[0];
      inst.invoiceItems.push(item);
    } else {
      let amount = parseFloat(charge.amount);
      let down_payment = getElevenPayDownPayment(charge);
      let installment = getElevenPayInstallment(charge);
      for (let i = 0; i < newItems.length; i++) {
        if (i == 0)
          newItems[i].amount = down_payment;
        else if (i > 0 && i < newItems.length - 1)
          newItems[i].amount = installment;
        else
          newItems[i].amount = round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));

      }
    }
  }

  for (let i = 1; i < installments.length; i++) {
    installments[i].installmentFees = [{
      feeName: installmentConstants.feeConstants.eleven_pay_fee,
      description: "11-Pay",
      amount: 2
    }];
  }


  return installments.filter(inst => inst.invoiceItems.length > 0);
}

function getElevenInstallmentEndorsement(data, increment, maxInstallments = installmentConstants.numberConstants.thousand) {
  let nowTimestamp = new Date().getTime();
  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));
  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);
  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));
  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
  let installments = [];
  let setissuetimestamp;
  let setstarttimestamp;
  let timestamps = 0;
  let length = 0;
  let prev_amount = 0;
  let total_amount = 0;
  let unprorated_amount;
  let times_date;
  let cov_date;
  let current_timestamp_flag = false;
  let start_date;
  let times_date_array;
  let issue_date_array;
  let timestamp_start;
  let issue_timestamp;
  for (let i = 0; i < installmentTimestamps.length; i++) {
    cov_date = new Date(+data.coverageStartTimestamp);
    cov_date = moment(cov_date).format(constantValues.dateFormat.year_month_date);
    start_date = new Date(+startTimestamp);
    start_date = moment(start_date).format(constantValues.dateFormat.year_month_date);
    times_date = new Date(installmentTimestamps[i]);
    times_date = moment(times_date).format(constantValues.dateFormat.year_month_date);
    if (data.policy.invoices[i] == undefined) {
      timestamps = i;
      break;
    }
    if ((installmentTimestamps[i] < data.coverageStartTimestamp) &&
      (data.coverageStartTimestamp < installmentTimestamps[i + 1])) {
      current_timestamp_flag = true;
      timestamps = i;
      break;
    }
    if (i == installmentTimestamps.length - 1) {
      if ((installmentTimestamps[i] < data.coverageStartTimestamp) &&
        (data.coverageStartTimestamp < endTimestamp)) {
        timestamps = i;
        break;
      }
    }
    if (times_date === cov_date) {
      timestamps = i;
      break;
    }

  }
  for (let i = timestamps; i < installmentTimestamps.length; i++) {
    let it = installmentTimestamps[i];
    if (data.policy.invoices[i] == undefined) {
      setstarttimestamp = it;
      setissuetimestamp = addDays(it, -20);
    } else if (i == timestamps && it != data.coverageStartTimestamp) {
      setstarttimestamp = data.coverageStartTimestamp;
      setissuetimestamp = data.coverageStartTimestamp;
    } else if (i == timestamps && times_date === cov_date && cov_date !== start_date) {
      setstarttimestamp = it
      setissuetimestamp = addDays(it, -20);
    } else if (i == timestamps && cov_date == start_date) {
      setstarttimestamp = data.coverageStartTimestamp;
      setissuetimestamp = data.coverageStartTimestamp;
    } else if (data.policy.invoices[i] != undefined) {
      setstarttimestamp = it;
      setissuetimestamp = it;
    } else {
      setstarttimestamp = it;
      setissuetimestamp = addDays(it, -20);
    }

    setstarttimestamp = new Date(+setstarttimestamp).getTime();
    setissuetimestamp = new Date(+setissuetimestamp).getTime();

    installments.push({
      invoiceItems: [],
      dueTimestamp: setstarttimestamp,
      startTimestamp: setstarttimestamp,
      issueTimestamp: setissuetimestamp,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp, //
      writeOff: false
    });

  }

    for (charge of data.charges) {
    if (charge.type == "premium") {
      console.log("charge is", JSON.stringify(charge))
    }
  }

  for (charge of data.charges) {
    let newItems = [];
    for (let i = 0; i < installments.length; i++) {
      let newItem = {
        chargeId: charge.chargeId
      };
      if (data.coverageStartTimestamp <= installments[i].startTimestamp ||
        installments[i].endTimestamp > data.coverageStartTimestamp) {
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      } else if (charge.isNew == false) {
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }

    }
    if (((charge.coverageStartTimestamp == data.coverageStartTimestamp) &&
        (data.coverageEndTimestamp == endTimestamp)) && (charge.isNew == true) && (charge.type == "premium")) {
      for (let i = 0; i < data.charges.length; i++) {
        if ((data.charges[i].isNew == true) && (data.charges[i].type == charge.type) && (data.charges[i].perilLocator == charge.perilLocator)) {
          if ((data.charges[i].coverageStartTimestamp == startTimestamp) &&
            (data.charges[i].coverageEndTimestamp == data.coverageStartTimestamp) && (data.charges[i].type == "premium") && (data.charges[i].isNew == true)) {
            prev_amount = 0;
            prev_amount = parseFloat(data.charges[i].amount);
          } else if ((data.charges[i].coverageStartTimestamp == startTimestamp) &&
            (data.charges[i].coverageEndTimestamp == endTimestamp) && (data.charges[i].type == "premium") && (data.charges[i].isNew == true) && (data.charges[i].amount < 0)) {
            total_amount = 0;
            total_amount = parseFloat(data.charges[i].amount);
            if (charge.amount != 0) {
              if (total_amount < 0) {
                total_amount = (-(total_amount))
              }
            }
          }
          if ((total_amount != 0) && (prev_amount != 0)) {
            if (total_amount < 0) {
              unprorated_amount = (total_amount + prev_amount);
            } else {
              unprorated_amount = (total_amount - prev_amount);
            }
          } else if (total_amount == 0 && prev_amount == 0) {
            unprorated_amount = total_amount - prev_amount;
          }
        }
      }
    }


    let amount = parseFloat(charge.amount);
    let down_payment;
    let installment;
    times_date_array = [];
    issue_date_array = [];
    for (i = 0; i < installmentTimestamps.length; i++) {
      times_date = new Date(+installmentTimestamps[i]);
      times_date = moment(times_date).format(constantValues.dateFormat.year_month_date);
      times_date_array.push(times_date);
      let issue_date = addDays(times_date, -20);
      issue_date = moment(issue_date).format(constantValues.dateFormat.year_month_date);
      issue_date_array.push(issue_date);
      if ((installmentTimestamps[i] <= data.coverageStartTimestamp) &&
        (data.coverageStartTimestamp < installmentTimestamps[i + 1])) {
        length = installmentTimestamps.length - i;
      } else if (i == installmentTimestamps.length - 1) {
        if ((installmentTimestamps[i] <= data.coverageStartTimestamp) &&
          (data.coverageStartTimestamp < endTimestamp)) {
          length = installmentTimestamps.length - i;
        }
      }
    }
    let cov_start = new Date(+charge.coverageStartTimestamp)
    cov_start = moment(cov_start).format(constantValues.dateFormat.year_month_date);
    if ((times_date_array.indexOf(cov_start)) > -1) {
      timestamp_start = cov_start;
      timestamp_start = moment(timestamp_start).format(constantValues.dateFormat.year_month_date);
    }
    if ((issue_date_array.indexOf(cov_start)) > -1) {
      issue_timestamp = cov_start;
      issue_timestamp = moment(issue_timestamp).format(constantValues.dateFormat.year_month_date);
    }
    let policy_end = new Date(+endTimestamp);
    policy_end = moment(policy_end).format(constantValues.dateFormat.year_month_date);
    let cov_end = new Date(+charge.coverageEndTimestamp);
    cov_end = moment(cov_end).format(constantValues.dateFormat.year_month_date);
    if (installments.length == 1) {
      down_payment = round2(parseFloat(charge.amount));
    } else if (((charge.coverageStartTimestamp == data.coverageStartTimestamp) &&
        (data.coverageEndTimestamp == endTimestamp)) && (charge.isNew == true) && (charge.type == "premium")) {
      if (charge.perilName != installmentConstants.perilNameConstants.trip_collision) {
        down_payment = getProratedPremium(data, charge, unprorated_amount, increment, maxInstallments);
        installment = getEndorsementInstallment(down_payment, unprorated_amount, charge, length);
      } else if (charge.perilName == installmentConstants.perilNameConstants.trip_collision) {
        down_payment = round2(parseFloat(charge.amount));
        installment = 0;
      }
    } else if ((((cov_start === timestamp_start) || (cov_start === issue_timestamp)) && (cov_end === policy_end)) && (charge.type == "premium") && (charge.isNew == false) && (charge.perilName != installmentConstants.perilNameConstants.trip_collision)) {
      if (current_timestamp_flag == true ) {
        down_payment = 0;
      } else if (current_timestamp_flag == false) {
        down_payment = round2(0.0869 * (charge.originalAmount));

      }
      installment = round2(0.0869 * (charge.originalAmount));

    } else {
      down_payment = 0;
      installment = 0;
    }

    for (let i = 0; i < newItems.length; i++) {
      if (i == 0) {
        newItems[i].amount = down_payment;
      } else if (i > 0 && i < newItems.length - 1) {
        newItems[i].amount = installment;
      } else {
        newItems[i].amount = round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount)); //-410
      }
    }
  }


  let amount = getinspectionFees(data);
  installments[0].installmentFees = [{
      feeName: installmentConstants.feeConstants.inspection_fee_aerial,
      description: "Aerial",
      amount: amount.aerial_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_interior,
      description: "Interior",
      amount: amount.interior_fee
    },
    {
      feeName: installmentConstants.feeConstants.inspection_fee_exterior,
      description: "Exterior",
      amount: amount.exterior_fee
    }
  ];

  return installments.filter(inst => inst.invoiceItems.length > 0);

}


function getElevenPayDownPayment(charge) {
  let fraction = 0;
  if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
    let amount = parseFloat(charge.amount);
    return amount;
  } else if (charge.perilName == installmentConstants.perilNameConstants.trip_collision) {
    let amount = parseFloat(charge.amount);
    return amount;
  } else {
    let amount = parseFloat(charge.amount);
    fraction = round2(0.1315 * amount);
    return fraction;
  }
}

function getElevenPayInstallment(charge) {
  let fraction = 0;
  if (charge.type == installmentConstants.feeConstants.fee || charge.type == installmentConstants.feeConstants.tax) {
    let amount = 0;
    return amount;
  } else if (charge.perilName == installmentConstants.perilNameConstants.trip_collision) {
    let amount = 0;
    return amount;
  } else {
    let amount = parseFloat(charge.amount);
    fraction = round2(0.0869 * amount);
    return fraction;
  }
}

function getProratedPremium(data, charge, unprorated_amount, increment, maxInstallments) {
  let nowTimestamp = new Date().getTime();

  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
    .map(m => dates.getTimestamp(m));

  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);
  let timestamps = [];
  for (let i = 0; i < installmentTimestamps.length; i++) {

    let it = installmentTimestamps[i];
    timestamps.push({
      startTimestamp: it,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp
    });
  }
  let total_change_amount = parseFloat(charge.amount);
  let prorated_amount;
  if (unprorated_amount < 0) {
    prorated_amount = (unprorated_amount) - (total_change_amount);
  } else {
    prorated_amount = (total_change_amount) - (unprorated_amount);
  }
  let endorsementStartTime = charge.coverageStartTimestamp;
  let endorsementEndTime = charge.coverageEndTimestamp;
  endorsementStartTime = new Date(+endorsementStartTime);
  endorsementStartTime = moment(endorsementStartTime).format(constantValues.dateFormat.year_month_date); //feb 25
  endorsementEndTime = new Date(+endorsementEndTime);
  endorsementEndTime = moment(endorsementEndTime).format(constantValues.dateFormat.year_month_date); //jan
  let endorsement_days = moment(new Date(endorsementEndTime)).diff(new Date(endorsementStartTime), 'days', true);
  let unearnedinstallemntdays;
  let down_payment;
  for (let i = 0; i < timestamps.length; i++) {
    if ((timestamps[i].startTimestamp <= charge.coverageStartTimestamp) &&
      (charge.coverageStartTimestamp < timestamps[i].endTimestamp)) {
      endors_length = i;
      let end = timestamps[i].endTimestamp;
      end = new Date(+end);
      end = moment(end).format(constantValues.dateFormat.year_month_date);
      unearnedinstallemntdays = moment(new Date(end)).diff(new Date(endorsementStartTime), 'days', true);
      break;
    }
  }
  let per_day_premium = prorated_amount / endorsement_days;
  down_payment = round2(per_day_premium * unearnedinstallemntdays);
  return down_payment;
}

function getEndorsementInstallment(down_payment, unprorated_amount, charge, length) {
  let rem_amount = 0;
  let total_change_amount = parseFloat(charge.amount);
  let prorated_amount;
  if (unprorated_amount < 0) {
    prorated_amount = (unprorated_amount) - (total_change_amount)
  } else {
    prorated_amount = (total_change_amount) - (unprorated_amount);
  }
  rem_amount = prorated_amount - down_payment;
  rem_amount = round2(rem_amount / (length - 1)); //
  return rem_amount;
}

function getinspectionFees(data) {
  let aerial_fee = 0;
  let interior_fee = 0;
  let exterior_fee = 0;
  let fee;
  let nb_exposureLocatorsArray;
  if(data.operation == installmentConstants.operationConstants.endorsement)
  {
    for (let exposure of data.policy.exposures) {
      let nb_exposureloc = exposure.characteristics[exposure.characteristics.length - 1].exposureLocator;
      for (let modification of data.policy.modifications) {
        aerial_fee = 0;
        interior_fee = 0;
        exterior_fee = 0;
        if (modification.name == constantValues.endorsementConstants.nb_endorsement) {
          for (let exposuremod of modification.exposureModifications) {
            nb_exposureLocatorsArray = [];
            nb_exposureLocatorsArray.push(exposuremod.exposureLocator);
          }
        }
        if (modification.name == constantValues.endorsementConstants.policy_endorsement) {
          for (let exposuremod of modification.exposureModifications) {
            let endors_exposureloc = exposuremod.exposureLocator;
            let exposure_efv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
            let exposure_efgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
            if (!((nb_exposureLocatorsArray.indexOf(endors_exposureloc)) > -1)) {
              if (nb_exposureloc == endors_exposureloc) {
                if ((exposure.name == constantValues.exposureNameConstants.landlord_occupied) || (exposure.name == constantValues.exposureNameConstants.vacant)) {
                  let unit_address_loc = exposure_efv.unit_address;
                  let unit_address_state = exposure_efgv[unit_address_loc].state;
                  let inspections_loc = exposure_efv.inspections;
                  let inspections_grp = exposure_efgv[inspections_loc];
                  if (unit_address_state == constantValues.stateConstants.michigan) {
                    if (inspections_grp.aerial == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.MI_Inspection_Fees, installmentConstants.tablekeyConstants.aerial));
                      aerial_fee = aerial_fee + fee;
                    }
                    if (inspections_grp.interior == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.MI_Inspection_Fees, installmentConstants.tablekeyConstants.interior));
                      interior_fee = interior_fee + fee;
                    }
                    if (inspections_grp.exterior == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.MI_Inspection_Fees, installmentConstants.tablekeyConstants.exterior));
                      exterior_fee = exterior_fee + fee;
                    }
                  }
                  if (unit_address_state != constantValues.stateConstants.michigan) {
                    if (inspections_grp.aerial == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.Inspection_Fees, installmentConstants.tablekeyConstants.aerial));
                      aerial_fee = aerial_fee + fee;
                    }
                    if (inspections_grp.interior == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.Inspection_Fees, installmentConstants.tablekeyConstants.interior));
                      interior_fee = interior_fee + fee;
                    }
                    if (inspections_grp.exterior == constantValues.binaryConstants.uw_yes) {
                      fee = parseInt(socotraApi.tableLookup(installmentConstants.tableNameConstants.Inspection_Fees, installmentConstants.tablekeyConstants.exterior));
                      exterior_fee = exterior_fee + fee;
                    }
                  }
                }
  
              }
            }
          }
        }
      }
    }
  }

  return {
    aerial_fee,
    interior_fee,
    exterior_fee
  }
}

function round2(amount) {
  return Math.round(amount * 100.0) / 100.0;
}

exports.createInstallments = createInstallments;