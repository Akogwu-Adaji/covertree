const lib = require("./moment-timezone-with-data.js");
const momTz = require("./moment-timezone-with-data.js");
require("./moment-with-locales.js");

const defaults = Object.freeze({
  //format: lib.defaultFormat, // ISO-8601 w/o milliseconds
  format: "YYYY-MM-DDTHH:mm:ss.SSSZ", // vs. + milliseconds
});

const settings = Object.assign({}, defaults);

function parseDate(string, format) {
  //return lib.parseZone(string, format).toDate();
  return lib(string, format);
}

function formatDate(ts, tz = "UTC") {
  return lib.tz(ts, tz).format(settings.format);
}

function fromTimestamp(ts, tz = "UTC") {
    return lib.tz(lib(new Date(parseInt(ts))), tz);
}
function getTimestamp(date) {
  return date.valueOf();
}

function span(start, end, increment)
{
  let cursor = start.clone();
  let baseDay = start.date();

  let ret = [];

  while (cursor < end)
  {
    ret.push(cursor);
    switch (increment)
    {
      case 'month':
        cursor = incrementMonth(cursor, baseDay);
        break;
      case 'quarter':
        cursor = incrementMonth(cursor, baseDay, 3);
        break;
      case 'semiannually':
        cursor = incrementMonth(cursor, baseDay, 6);
        break;
      case 'elevenpay':
        cursor = incrementMonth(cursor, baseDay, 11);
        break;
      case 'week':
        cursor = incrementWeek(cursor);
        break;
      case '2week':
        cursor = incrementWeek(cursor, 2);
        break;
      default:
        throw increment + "not supported!";
    }
  }
  return ret;
}
function incrementWeek(date, numWeeks = 1)
{
  let ret = date.clone();
  ret.add(numWeeks * 7, 'days');
  return ret;
}
function incrementMonth(date, baseDayOfMonth = null, numMonths = 1)
{
  baseDayOfMonth |= date.date();

  let nextMonth = date.clone();
  nextMonth.set('month', date.month() + numMonths);

  if (nextMonth.date() < baseDayOfMonth)
  {
     lastDayOfMonth = nextMonth.clone();
     lastDayOfMonth.endOf('month');
     if (lastDayOfMonth.date() < baseDayOfMonth)
       nextMonth.set('date', lastDayOfMonth.date());
     else
       nextMonth.set('date', baseDayOfMonth);
  }
  else if (nextMonth.date() > baseDayOfMonth)
  {
    nextMonth.set('date', baseDayOfMonth);
  }
  return nextMonth;
}
function monthCount(start, end) {
  let startDayOfMonth = start.date();

  var count = 0.0;
  while (start < end) {
      var next = incrementMonth(start, startDayOfMonth);
      if (next > end)
          count += end.diff(start, "millisecond", true) / next.diff(start, "millisecond", true);
      else
          count++;
      start = next;
  }
  return count;
}


// TODO: Consider caching

function momentFromTimestamp(timestamp, timeZone = 'UTC')
{
    console.log("Called momentFromTimestamp in dates.js with: " + timestamp +" :: "+ timeZone);
    console.log("Date: " + new Date(timestamp));
    console.log("momentFromDate:" + momentFromDate(new Date(timestamp), timeZone))
    return momentFromDate(new Date(timestamp), timeZone);
}
function momentFromDate(date, timeZone = 'UTC')
{
    console.log("Called momentFromDate in dates.js with: " + date +" :: "+ timeZone);
    console.log("momTz.tz:" + momTz.tz(date, timeZone))
    return momTz.tz(date, timeZone);
}
function spanByTimestamp(startTimestamp, endTimestamp, timeZone, increment = 'month', maxCount = 1000000)
{
     return spanByMoment(momentFromTimestamp(startTimestamp, timeZone),
                         momentFromTimestamp(endTimestamp, timeZone),
                         increment,
                         maxCount)
               .map(m => m.valueOf());
}
// return a series of dates from start to end
// incrementing using the increment key
function spanByMoment(startMoment, endMoment, increment = 'month', maxCount = 1000000)
{
    const baseDay = startMoment.date();
    const ret = [];
    
    let count = 0;
    let cursor = startMoment.clone();
    
    if (increment === 'eon')
        maxCount = 1;
    else
        maxCount = maxCount || 1000000;

    while (cursor < endMoment)
    {
        ret.push(cursor);
        switch (increment)
        {
            case 'eon':
                break;
            case '30day':
                cursor = cursor.clone();
                cursor.add(30, 'days');
                break;
            case 'month':
                cursor = incrementMomentByMonth(cursor, baseDay);
                break;
            case 'quarter':
                cursor = incrementMomentByMonth(cursor, baseDay, 3);
                break;
            case 'halfYear':
                cursor = incrementMomentByMonth(cursor, baseDay, 6);
                break;
            case 'year':
                cursor = cursor.clone();
                cursor.add(1, 'years');
                break;
            case 'week':
                cursor = cursor.clone();
                cursor.add(7, 'days');
                break;
            case '2week':
                cursor = cursor.clone();
                cursor.add(14, 'days');
                break;
            default:
                throw `Span increment '${increment}' not supported!`;
        }
        if (++count >= maxCount)
            break;
    } 
    return ret;
}
function incrementMomentByMonth(date, anchorToDayOfMonth = null, numMonths = 1)
{
    const nextMonth = date.clone().add(numMonths, 'months');

    if (anchorToDayOfMonth)
    {
        if (nextMonth.date() < anchorToDayOfMonth)
            nextMonth.set('date', Math.min(nextMonth.daysInMonth(), anchorToDayOfMonth));
        else if (nextMonth.date() > anchorToDayOfMonth)
            nextMonth.set('date', anchorToDayOfMonth);
    }
    return nextMonth;
}
function addToTimestamp(timestamp, count, increment = 'days', timeZone = 'UTC')
{
    return momentFromTimestamp(timestamp, timeZone).add(count, increment)
                                                   .valueOf();
}
function addToMomentInPlace(moment, count, increment = 'days')
{
    moment.add(count, increment);
}
function getEndOfDayTimestamp(timestamp, timeZone = 'UTC')
{
    return momentFromTimestamp(timestamp, timeZone).endOf('day')
                                                   .valueOf();
}
function socotraMonthCountByTimestamp(start, end, timeZone = 'UTC', base = null)
{
    if (!base)
        base = momentFromTimestamp(base, timeZone);
    return socotraMonthCountByMoment(momentFromTimestamp(start, timeZone),
                                     momentFromTimestamp(end, timeZone),
                                     base);
}
function monthCountByTimestamp(start, end, timeZone, base)
{
    if (!base)
        base = start;

    return monthCountByMoment(momentFromTimestamp(start, timeZone),
                              momentFromTimestamp(end, timeZone),
                              momentFromTimestamp(base, timeZone)); 
}
function monthCountByMoment(start, end, base)
{
    console.log(`${start.toString()} ${start.valueOf()}`)

    if (base)
        startDayOfMonth = base.date();
    else
        startDayOfMonth = start.date();

    if (startDayOfMonth < 29)
        startDayOfMonth = null;

    var count = 0.0;
    while (start < end)
    {
        var next = incrementMomentByMonth(start, startDayOfMonth, 1);

        if (next > end)
        {
            count += end.diff(start, 'millisecond', true) / next.diff(start, 'millisecond', true);
        }
        else
            count++;
        start = next;
    }
    return count;
}
function socotraMonthCountByTimestamp(start, end, timeZone, base)
{
    if (!base)
        base = start;

    return socotraMonthCountByMoment(momentFromTimestamp(start, timeZone),
                                     momentFromTimestamp(end, timeZone),
                                     momentFromTimestamp(base, timeZone)); 
}

function socotraMonthCountByMoment(start, end, base)
{
    if (!base)
        base = start;

    const startVal = start.valueOf();
    const endVal = end.valueOf();
    const baseVal = base.valueOf();

    const startDate = start.date();
    const endDate = end.date();

    // Simple case
    if ((baseVal <= startVal) && (startVal < endVal) && (startDate === endDate) && (start.hour() === end.hour()) && ((startVal % 3600000) === (endVal % 3600000)))
    {
        const differenceInYears = end.year() - start.year();
        const differenceInMonths = end.month() - start.month();
        return differenceInMonths + differenceInYears * 12;
    }
    
    const baseDate = base.date();
    let monthCount = 0;
    let prevMonth = start.clone();
    let monthCursor = _socotraDate_addMonth(start, baseDate);
    
    while (monthCursor.valueOf() < endVal)
    {
        prevMonth = monthCursor;
        monthCursor = _socotraDate_addMonth(monthCursor, baseDate);
        monthCount += 1;
        if (monthCursor.date() !== startDate)
        {
            const daysInMonth = monthCursor.daysInMonth();
            if (baseDate >= daysInMonth) // special case for policies that started on 29/30/31
            {
                monthCursor.set('date', daysInMonth);
            }
            else
            {
                monthCursor.set('date', Math.min(startDate, daysInMonth));
            }
        }
    }
    const prevMonthVal = prevMonth.valueOf();
    if (prevMonthVal === endVal)
    {
        return monthCount;
    }
    else
    {
        const remainder = endVal - prevMonthVal;
        const totalNextMonthMillis = monthCursor.valueOf() - prevMonthVal;
        const remainderInMonths = round7(remainder / totalNextMonthMillis);
        return monthCount + remainderInMonths;
    }
}

function _socotraDate_addMonth(start, baseDate)
{
    const nextMonth = start.clone().add(1, 'months');
    const startDate = start.date();
    const startDomBeforeBaseDom = startDate < baseDate;
    const nextMonthBeforeBaseDom = nextMonth.date() < baseDate;
    if (startDate === start.daysInMonth() && startDomBeforeBaseDom && nextMonthBeforeBaseDom)
    {
        return nextMonth.set('date', Math.min(nextMonth.daysInMonth(), baseDate));
    }
    else
    {
        return nextMonth;
    }
}

function round7(amount)
{
  return Math.round(amount * 10000000.0) / 10000000.0;
}
function monthCountRatioByTimestamp(start, split, end, timeZone = 'UTC', clampZeroToOne = true)
{
  if (start >= end)
    throw "Month Count Ratio: Denominator cannot be zero or negative.";
  
  if (split > end)
    throw "Month Count Ratio: Split cannot be after end.";
  
  if (split <= start)
    return 0;

    const startMoment = momentFromTimestamp(start, timeZone);
    const splitMoment = momentFromTimestamp(split, timeZone);
    const endMoment = momentFromTimestamp(end, timeZone);

    let result = socotraMonthCountByMoment(startMoment, splitMoment) /
                 socotraMonthCountByMoment(startMoment, endMoment);

  if (clampZeroToOne)
    result = Math.max(0, Math.min(1, result));

  return result;
}
function dayCountByTimestamp(start, end, timeZone)
{
    console.log("Called dayCountByTimestamp in dates.js with: " + start +" :: "+ end+" :: " + timeZone);
    console.log("dayCountByMoment: " + dayCountByMoment(momentFromTimestamp(start, timeZone),
                            momentFromTimestamp(end, timeZone)));
    return dayCountByMoment(momentFromTimestamp(start, timeZone),
                            momentFromTimestamp(end, timeZone));
}
function dayCountByMoment(start, end)
{
    console.log("Called dayCountByMoment in dates.js with: " + start +" :: "+ end);
    console.log("end.diff: " + end.diff(start, 'days', true));
    return end.diff(start, 'days', true);
}
function dayCountRatioByTimestamp(start, split, end, timeZone = 'UTC', clampZeroToOne = true)
{
    if (start >= end)
        throw "Day Count Ratio: Denominator cannot be zero or negative.";

    if (split > end)
        throw "Day Count Ratio: Split cannot be after end.";
    
    if (split <= start)
        return 0;

    const startMoment = momentFromTimestamp(start, timeZone);
    const splitMoment = momentFromTimestamp(split, timeZone);
    const endMoment = momentFromTimestamp(end, timeZone);

    let result = dayCountByMoment(startMoment, splitMoment) /
                 dayCountByMoment(startMoment, endMoment);

    if (clampZeroToOne)
        result = Math.max(0, Math.min(1, result));

    return result;
}
function linearRatioByTimestamp(start, split, end, clampZeroToOne = true)
{
    if (start >= end)
        throw "Linear Ratio: Denominator cannot be zero or negative.";
    
    if (split > end)
        throw "Linear Ratio: Split cannot be after end.";
    
    if (split <= start)
        return 0;

    let result = (split - start) / (end - start);

    if (clampZeroToOne)
        result = Math.max(0, Math.min(1, result));

    return result;
}
function copyMoment(d)
{
    return momTz(d);
}


function test()
{
  let x = lib(new Date(2021, 0, 31));
  let y = incrementMonth(x, 31);

  if (y.isSame(lib(new Date(2021, 1, 28))))
    console.log('incrementMonth 2021-01-31 => 2021-02-28 OK');
  else
    console.log('incrementMonth 2021-01-31 => 2021-02-28 FAIL');

  x = lib(new Date(2021, 0, 30));
  y = incrementMonth(x, 24);

  if (y.isSame(lib(new Date(2021, 1, 24))))
    console.log('incrementMonth 2021-01-31 => 2021-02-24 OK');
  else
    console.log('incrementMonth 2021-01-31 => 2021-02-24 FAIL');

  x = lib(new Date(2021, 4, 5));
  y = incrementMonth(x, 31);

  if (y.isSame(lib(new Date(2021, 5, 30))))
    console.log('incrementMonth 2021-05-05 => 2021-06-30 OK');
  else
    console.log('incrementMonth 2021-05-05 => 2021-06-30 FAIL');
}

function copy(d) {
  return lib(d);
}

module.exports = {
  formatDate,
  parseDate,
  fromTimestamp,
  getTimestamp,
  incrementMonth,
  monthCount,
  span,
  copy,
  test,
  settings,
  momentFromDate,
  momentFromTimestamp,
  addToTimestamp,
  addToMomentInPlace,
  getEndOfDayTimestamp,
  incrementMomentByMonth,
  monthCountByTimestampEx: monthCountByTimestamp,
  monthCountByTimestamp: socotraMonthCountByTimestamp,
  monthCountByMoment: socotraMonthCountByMoment,
  monthCountRatioByTimestamp,
  dayCountByTimestamp,
  dayCountByMoment,
  dayCountRatioByTimestamp,
  linearRatioByTimestamp,
  spanByTimestamp,
  spanByMoment,
  copyMoment
};