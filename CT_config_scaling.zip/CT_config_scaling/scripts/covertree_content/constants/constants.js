let operationConstants = {
   new_business : "newBusiness",
   endorsement : "endorsement",
   fee_assessment : "feeAssessment",
   renewal: "renewal",
   cancellation :"cancellation",
   reinstatement : "reinstatement"
}

let paymentScheduleConstants = {
   mortgage: "Mortgagee Bill",
   full_pay : "Full Pay",
   two_pay : "2-Pay",
   eleven_pay : "11-Pay"
}

let tableNameConstants ={
   policy_Minimum_Premium : "Policy_Minimum_Premium",
   MI_Inspection_Fees:"MI-Inspection_Fees",
   Inspection_Fees:"Inspection_Fees"
}

let tablekeyConstants = {
   policy_earned : "Policy - Earned",
   aerial:"Aerial",
   interior:"Interior",
   exterior:"Exterior"
}

let termConstants = {
   semiannually : "semiannually",
   month : "month",
   exception : "Payment schedule is not implemented!"
}

let numberConstants = {
   thousand : 1000,
   two: 2,
   eleven: 11,
   zero: 0
}

let feeConstants = {
   fee: "fee",
   tax: "tax",
   two_pay_fee : "two_pay_fee",
   eleven_pay_fee: "eleven_pay_fee",
   inspection_fee_interior:"inspection_fee_interior",
   inspection_fee_aerial:"inspection_fee_aerial",
   inspection_fee_exterior:"inspection_fee_exterior"
}

let perilNameConstants = {
   trip_collision: "Trip Collision",
   policy_minimum_premium :"Policy Minimum Premium Coverage"
}

exports.tablekeyConstants = tablekeyConstants;
exports.tableNameConstants = tableNameConstants;
exports.perilNameConstants = perilNameConstants;
exports.numberConstants = numberConstants;
exports.feeConstants = feeConstants;
exports.operationConstants = operationConstants;
exports.paymentScheduleConstants = paymentScheduleConstants;
exports.termConstants = termConstants;