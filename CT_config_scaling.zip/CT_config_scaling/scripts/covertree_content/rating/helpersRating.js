"use strict";

let ratingConstants = require("./ratingConstants.js");
let moment = require("../libraries/moment-timezone-with-data.js");

function getTableObject(tableName, tableKey)
{
  let valueFromTable;
  let valuesArray;
  valueFromTable = socotraApi.tableLookup(tableName, tableKey);
  valuesArray = valueFromTable.split(ratingConstants.getTableObjectConstants.pipe);
  let keyValuePairs = [];
  for (let prop of valuesArray)
  {
    let keyValue = prop.split(ratingConstants.getTableObjectConstants.hash);
    keyValuePairs.push(keyValue);
  }
  var obj = Object.assign(...keyValuePairs.map(([key, val]) => (
  {
    [key]: val
  })));
  return obj;
}

function getTableName(state, tableName)
{
if(state == ratingConstants.stateConstants.az)
{
return "AZ-" + tableName;
}
else if(state == ratingConstants.stateConstants.oh)
{
return "OH-" + tableName;
}
else if(state == ratingConstants.stateConstants.mi)
{
return "MI-" + tableName;
}
else if(state == ratingConstants.stateConstants.in)
{
return "IN-" + tableName;
}
else if(state == ratingConstants.stateConstants.nm)
{
return "NM-" + tableName;
}

}
function getTableNameForFlatpremiums(peril, exposures, tableName)
{
let exposureLocator = peril.exposureLocator;
let exposure = exposures.find((e) => e.locator == exposureLocator);
let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

let unit_address_group = exposure_fv.unit_address;
let state = exposure_fgv[unit_address_group].state;

if(state == ratingConstants.stateConstants.az)
{
return "AZ-" + tableName;
}
else if(state == ratingConstants.stateConstants.oh)
{
return "OH-" + tableName;
}
else if(state == ratingConstants.stateConstants.mi)
{
return "MI-" + tableName;
}
else if(state == ratingConstants.stateConstants.in)
{
return "IN-" + tableName;
}
else if(state == ratingConstants.stateConstants.nm)
{
return "NM-" + tableName;
}
}

function getDecimalFromPercentage(percent)
{
  return parseInt(percent) / 100.0;
}

function getCountOfChargeableClaims(policy_fgv)
{
  return policy_fgv[prior_claims].length;
}

function getRoofOrHomeAge(model_year, policy_start_timestamp)
{
  let effective_year = new Date(+policy_start_timestamp).getFullYear();
  let home_age = Math.abs(effective_year - model_year);
  return home_age;
}

function getInsuredAge(date_of_birth, policy_start_timestamp, state)
{
  let effective_date = new Date(+policy_start_timestamp);
  effective_date = moment(effective_date).format("YYYY-MM-DD");
  date_of_birth = new Date(date_of_birth);
  date_of_birth  = moment(date_of_birth).format("YYYY-MM-DD");
  
  let age = moment(new Date(effective_date)).diff(new Date(date_of_birth), 'year', true);
  age = Math.floor(age);


  if(state == ratingConstants.stateConstants.mi||state == ratingConstants.stateConstants.oh)
  {
     if (age >= "18" && age <= "22")
     {
       return "18";
     }
     if (age >= "23" && age <= "27")
     {
       return "23";
     }
     if (age >= "28" && age <= "34")
     {
       return "28";
     }
     if (age >= "35" && age <= "44")
     {
       return "35";
     }
     if (age >= "45" && age <= "49")
     {
       return "45";
     }
     if (age >= "50" && age <= "54")
     {
       return "50";
     }
     if (age >= "55" && age <= "59")
     {
       return "55";
     }
     if (age >= "60" && age <= "64")
     {
       return "60";
     }
     if (age >= "65" && age <= "74")
     {
       return "65";
     }
     if (age >= "75" && age <= "84")
     {
       return "75";
     }
     if (age >= "85")
     {
       return "85";
     }
  }
  if(state == ratingConstants.stateConstants.az || state == ratingConstants.stateConstants.in || state == ratingConstants.stateConstants.nm)
  {
     if (age >= "0" && age <= "22")
     {
       return "0";
     }
     if (age >= "23" && age <= "27")
     {
       return "23";
     }
     if (age >= "28" && age <= "34")
     {
       return "28";
     }
     if (age >= "35" && age <= "37")
     {
       return "35";
     }
     if (age >= "38" && age <= "42")
     {
       return "38";
     }
     if (age >= "43" && age <= "47")
     {
       return "43";
     }
     if (age >= "48" && age <= "53")
     {
       return "48";
     }
     if (age == "54") 
     {
       return "54";
     }
     if (age >= "55" && age <= "65")
     {
       return "55";
     }
     if (age >= "66")
     {
       return "66";
     }
  }
}

function getSchedule(exposures)
{
  let count_of_units = 0;
  for (let exposure of exposures)
  {
    if (exposure.name == ratingConstants.exposureNameConstants.vacant)
    {
      count_of_units++;
    }
  }
  if (count_of_units > ratingConstants.numberConstants.one)
  {
    return ratingConstants.binaryConstants.yes;
  }
  if (count_of_units == ratingConstants.numberConstants.one)
  {
    return ratingConstants.binaryConstants.no;
  }
}

function getDateOfLoss(claim_date, policy_start_timestamp)
{

  let effective_date = new Date(+policy_start_timestamp);
  effective_date = moment(effective_date).format("YYYY-MM-DD");
  let claim_date_calc = new Date(claim_date);
  claim_date_calc  = moment(claim_date_calc).format("YYYY-MM-DD");

  let year_diff = moment(new Date(effective_date)).diff(new Date(claim_date_calc), 'year', true);
  year_diff = Math.floor(year_diff);
  return year_diff;
}

function getNumberOfExposures(allExposures)
{
  let count_of_units = 0;
  let exposure;
  for (exposure of allExposures)
  {
    if (exposure.name != ratingConstants.exposureNameConstants.policy_level_coverages)
    {
      count_of_units++;
    }
  }
  return count_of_units;
}

function getNumberOfDaysUninsured(purchase_date, prior_insurance, prior_policy_expiration_date)
{
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.buying_process)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days || prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.never_insured)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.switching_carriers)
  {
    return ratingConstants.numberConstants.zero;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }

}

function getNumberOfDaysUninsuredForTenant(prior_insurance, prior_policy_expiration_date)
{
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days || prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.never_insured)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.switching_carriers)
  {
    return ratingConstants.numberConstants.zero;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }
}

function getPolicyTerm(data)
{
  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let policy_end_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyEndTimestamp;
  var start_time = new Date(+policy_start_timestamp);
  var end_time = new Date(+policy_end_timestamp);
  let years_difference = moment(new Date(end_time)).diff(new Date(start_time), 'years', true);
  return years_difference;
}

function getInsuranceScore(insurance_score)
{
  if (insurance_score >= 1 && insurance_score <= 390)
  {
    return "1";
  }
  if (insurance_score >= 391 && insurance_score <= 430)
  {
    return "391";
  }
  if (insurance_score >= 431 && insurance_score <= 450)
  {
    return "431";
  }
  if (insurance_score >= 451 && insurance_score <= 465)
  {
    return "451";
  }
  if (insurance_score >= 466 && insurance_score <= 480)
  {
    return "466";
  }
  if (insurance_score >= 481 && insurance_score <= 495)
  {
    return "481";
  }
  if (insurance_score >= 496 && insurance_score <= 510)
  {
    return "496";
  }
  if (insurance_score >= 511 && insurance_score <= 520)
  {
    return "511";
  }
  if (insurance_score >= 521 && insurance_score <= 530)
  {
    return "521";
  }
  if (insurance_score >= 531 && insurance_score <= 540)
  {
    return "531";
  }
  if (insurance_score >= 541 && insurance_score <= 550)
  {
    return "541";
  }
  if (insurance_score >= 551 && insurance_score <= 560)
  {
    return "551";
  }
  if (insurance_score >= 561 && insurance_score <= 570)
  {
    return "561";
  }
  if (insurance_score >= 571 && insurance_score <= 580)
  {
    return "571";
  }
  if (insurance_score >= 581 && insurance_score <= 590)
  {
    return "581";
  }
  if (insurance_score >= 591 && insurance_score <= 600)
  {
    return "591";
  }
  if (insurance_score >= 601 && insurance_score <= 610)
  {
    return "601";
  }
  if (insurance_score >= 611 && insurance_score <= 620)
  {
    return "611";
  }
  if (insurance_score >= 621 && insurance_score <= 630)
  {
    return "621";
  }
  if (insurance_score >= 631 && insurance_score <= 640)
  {
    return "631";
  }
  if (insurance_score >= 641 && insurance_score <= 650)
  {
    return "641";
  }
  if (insurance_score >= 651 && insurance_score <= 660)
  {
    return "651";
  }
  if (insurance_score >= 661 && insurance_score <= 670)
  {
    return "661";
  }
  if (insurance_score >= 671 && insurance_score <= 680)
  {
    return "671";
  }
  if (insurance_score >= 681 && insurance_score <= 690)
  {
    return "681";
  }

  if (insurance_score >= 691 && insurance_score <= 700)
  {
    return "691";
  }
  if (insurance_score >= 701 && insurance_score <= 710)
  {
    return "701";
  }
  if (insurance_score >= 711 && insurance_score <= 720)
  {
    return "711";
  }
  if (insurance_score >= 721 && insurance_score <= 730)
  {
    return "721";
  }
  if (insurance_score >= 731 && insurance_score <= 740)
  {
    return "731";
  }
  if (insurance_score >= 741 && insurance_score <= 750)
  {
    return "741";
  }
  if (insurance_score >= 751 && insurance_score <= 765)
  {
    return "751";
  }
  if (insurance_score >= 766 && insurance_score <= 780)
  {
    return "766";
  }
  if (insurance_score >= 781 && insurance_score <= 795)
  {
    return "781";
  }
  if (insurance_score >= 796 && insurance_score <= 810)
  {
    return "796";
  }
  if (insurance_score >= 811 && insurance_score <= 825)
  {
    return "811";
  }
  if (insurance_score >= 826 && insurance_score <= 840)
  {
    return "826";
  }
  if (insurance_score >= 841 && insurance_score <= 860)
  {
    return "841";
  }
  if (insurance_score >= 861 && insurance_score <= 997)
  {
    return "861";
  }
  if (insurance_score == 998)
  {
    return "998";
  }
  if (insurance_score == 999)
  {
    return "999";
  }
}

function getInterPolatedFactor(coverage_limit, lower_limit, upper_limit, policy_usage, type_constant, coverage_constant, state){

  let coverage_upper_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + upper_limit + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let coverageUpperLimitFactorTable = getTableObject(getTableName(state, ratingConstants.tableNameConstants.coverage_limit_factor), coverage_upper_limit_factor_key);
  let coverage_upper_limit_factor = parseFloat(coverageUpperLimitFactorTable[type_constant]);
  
  let coverage_lower_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + lower_limit + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let coverageLowerLimitFactorTable = getTableObject(getTableName(state, ratingConstants.tableNameConstants.coverage_limit_factor), coverage_lower_limit_factor_key);
  let coverage_lower_limit_factor = parseFloat(coverageLowerLimitFactorTable[type_constant]);
  
  let coverage_limit_factor =  coverage_lower_limit_factor + 
  (((coverage_upper_limit_factor - coverage_lower_limit_factor)/(upper_limit - lower_limit)) * (coverage_limit - lower_limit));
  
  return coverage_limit_factor;
}

function getUnitLocation(unit_location)
{
  if (unit_location == "In a large manufactured home community (equal to or more than 25 units)")
  {
    return ">25 Units";
  }
  if (unit_location == "In a small manufactured home community (less than 25 units)")
  {
    return "<25 Units";
  }
  if (unit_location == "On my own land")
  {
    return "Own Land";
  }
}

function getAOPDeductible(all_other_perils_deductible)
{
  if (all_other_perils_deductible == "$500")
  {
    return 500;
  }
  if (all_other_perils_deductible == "$1,000")
  {
    return 1000;
  }
  if (all_other_perils_deductible == "$2,500")
  {
    return 2500;
  }
  if (all_other_perils_deductible == "$5,000")
  {
    return 5000;
  }
  if (all_other_perils_deductible == "$10,000")
  {
    return 10000;
  }
}

function getWindHailDeductible(wind_hail_deductible)
{
  if (wind_hail_deductible == "$500")
  {
    return 500;
  }
  if (wind_hail_deductible == "$1,000")
  {
    return 1000;
  }
  if (wind_hail_deductible == "$2,500")
  {
    return 2500;
  }
  if (wind_hail_deductible == "$5,000")
  {
    return 5000;
  }
  if (wind_hail_deductible == "$10,000")
  {
    return 10000;
  }
}

function getAgeOfHomeForFactor(model_year, policy_start_timestamp)
{
  let effective_year = new Date(+policy_start_timestamp).getFullYear();
  let home_age = Math.abs(effective_year - model_year);
  if (home_age >= 0 && home_age <= 4)
  {
    return "0";
  }
  else if (home_age >= 5)
  {
    return "5";
  }
}

function getChannel(application_intiation)
{
  if (application_intiation == ratingConstants.applicationInitConstants.d2c || application_intiation == ratingConstants.applicationInitConstants.internal_agent)
  {
    return ratingConstants.applicationInitConstants.d2c;
  }
  else
  {
    return ratingConstants.applicationInitConstants.broker;
  }
}

function getRoofMaterial(roof_material)
{
  if (roof_material == ratingConstants.tableKeyConstants.metal_elastomeric_coated)
  {
    return "Metal - Elastomeric Coated";
  }
  else
  {
    return roof_material;
  }

}

function round(v)
{
  return Math.sign(v) * Math.round(Math.abs(v));
}

function getAgeForDiscount(date_of_birth, policy_start_timestamp)
{
  let effective_date = new Date(+policy_start_timestamp);
  effective_date = moment(effective_date).format("YYYY-MM-DD");
  date_of_birth = new Date(date_of_birth);
  date_of_birth  = moment(date_of_birth).format("YYYY-MM-DD");
  
  let age = moment(new Date(effective_date)).diff(new Date(date_of_birth), 'year', true);
  age = Math.floor(age);
  console.log("🚀 ~ file: helpersRating.js ~ line 766 ~ age of insured", age)
 return age;
}

function getRecipientName(agent_id_from_table)
{
  if(agent_id_from_table != "*")
   {
     return ratingConstants.commissionsConstants.agent_commission;
   }
   else
   {
    return ratingConstants.commissionsConstants.agency_commission;
   }
}

function getMineSubsidenceDwellingLimit(mine_subsidence_dwelling_limit)
{
  if(mine_subsidence_dwelling_limit >= 0 && mine_subsidence_dwelling_limit < 25001)
  {
     return "0"
  }
  else if(mine_subsidence_dwelling_limit >= 25001 && mine_subsidence_dwelling_limit < 40001)
  {
     return "25001"
  }
  else if(mine_subsidence_dwelling_limit >= 40001 && mine_subsidence_dwelling_limit < 60001)
  {
     return "40001"
  }
  else if(mine_subsidence_dwelling_limit >= 60001 && mine_subsidence_dwelling_limit < 75001)
  {
     return "60001"
  }
  else if(mine_subsidence_dwelling_limit >= 75001 && mine_subsidence_dwelling_limit < 100001)
  {
     return "75001"
  }
  else if(mine_subsidence_dwelling_limit >= 100001 && mine_subsidence_dwelling_limit < 125001)
  {
     return "100001"
  }
  else if(mine_subsidence_dwelling_limit >= 125001 && mine_subsidence_dwelling_limit < 150001)
  {
     return "125001"
  }
  else if(mine_subsidence_dwelling_limit >= 150001 && mine_subsidence_dwelling_limit < 175001)
  {
     return "150001"
  }
  else if(mine_subsidence_dwelling_limit >= 175001 && mine_subsidence_dwelling_limit < 200001)
  {
     return "175001"
  }
  else if(mine_subsidence_dwelling_limit >= 200001 && mine_subsidence_dwelling_limit < 225001)
  {
     return "200001"
  }
  else if(mine_subsidence_dwelling_limit >= 225001 && mine_subsidence_dwelling_limit < 250001)
  {
     return "225001"
  }
  else if(mine_subsidence_dwelling_limit >= 250001 && mine_subsidence_dwelling_limit < 275001)
  {
     return "250001"
  }
  else if(mine_subsidence_dwelling_limit >= 275001 && mine_subsidence_dwelling_limit < 300001)
  {
     return "275001"
  }
  else if(mine_subsidence_dwelling_limit >= 300001 && mine_subsidence_dwelling_limit < 325001)
  {
     return "300001"
  }
  else if(mine_subsidence_dwelling_limit >= 325001 && mine_subsidence_dwelling_limit < 350001)
  {
     return "325001"
  }
  else if(mine_subsidence_dwelling_limit >= 350001 && mine_subsidence_dwelling_limit < 375001)
  {
     return "350001"
  }
  else if(mine_subsidence_dwelling_limit >= 375001 && mine_subsidence_dwelling_limit < 400001)
  {
     return "375001"
  }
  else if(mine_subsidence_dwelling_limit >= 400001 && mine_subsidence_dwelling_limit < 425001)
  {
     return "400001"
  }
  else if(mine_subsidence_dwelling_limit >= 425001 && mine_subsidence_dwelling_limit < 450001)
  {
     return "425001"
  }
  else if(mine_subsidence_dwelling_limit >= 450001 && mine_subsidence_dwelling_limit < 475001)
  {
     return "450001"
  }
  else if(mine_subsidence_dwelling_limit >= 475001)
  {
    return "475001"
  }
}

function getMineSubsidenceOtherStructuresLimit(mine_subsidence_other_structures_limit)
{
  if(mine_subsidence_other_structures_limit >= 0 && mine_subsidence_other_structures_limit < 25001)
  {
     return "0"
  }
  else if(mine_subsidence_other_structures_limit >= 25001 && mine_subsidence_other_structures_limit < 35001)
  {
     return "25001"
  }
  else if(mine_subsidence_other_structures_limit >= 35001 && mine_subsidence_other_structures_limit < 45001)
  {
     return "35001"
  }
  else if(mine_subsidence_other_structures_limit >= 45001 && mine_subsidence_other_structures_limit < 55001)
  {
     return "45001"
  }
  else if(mine_subsidence_other_structures_limit >= 55001 && mine_subsidence_other_structures_limit < 65001)
  {
     return "55001"
  }
  else if(mine_subsidence_other_structures_limit >= 65001 && mine_subsidence_other_structures_limit < 75001)
  {
     return "65001"
  }
  else if(mine_subsidence_other_structures_limit >= 75001 && mine_subsidence_other_structures_limit < 85001)
  {
     return "75001"
  }
  else if(mine_subsidence_other_structures_limit >= 85001 && mine_subsidence_other_structures_limit < 100001)
  {
     return "85001"
  }
  else if(mine_subsidence_other_structures_limit >= 100001 && mine_subsidence_other_structures_limit < 125001)
  {
     return "100001"
  }
  else if(mine_subsidence_other_structures_limit >= 125001 && mine_subsidence_other_structures_limit < 150001)
  {
     return "125001"
  }
  else if(mine_subsidence_other_structures_limit >= 150001 && mine_subsidence_other_structures_limit < 175001)
  {
     return "150001"
  }
  else if(mine_subsidence_other_structures_limit >= 175001 && mine_subsidence_other_structures_limit < 200001)
  {
     return "175001"
  }
  else if(mine_subsidence_other_structures_limit >= 200001 && mine_subsidence_other_structures_limit < 225001)
  {
     return "200001"
  }
  else if(mine_subsidence_other_structures_limit >= 225001 && mine_subsidence_other_structures_limit < 250001)
  {
     return "225001"
  }
  else if(mine_subsidence_other_structures_limit >= 250001 && mine_subsidence_other_structures_limit < 275001)
  {
     return "250001"
  }
  else if(mine_subsidence_other_structures_limit >= 275001 && mine_subsidence_other_structures_limit < 300001)
  {
     return "275001"
  }
  else if(mine_subsidence_other_structures_limit >= 300001 && mine_subsidence_other_structures_limit < 325001)
  {
     return "300001"
  }
  else if(mine_subsidence_other_structures_limit >= 325001 && mine_subsidence_other_structures_limit < 350001)
  {
     return "325001"
  }
  else if(mine_subsidence_other_structures_limit >= 350001 && mine_subsidence_other_structures_limit < 375001)
  {
     return "350001"
  }
  else if(mine_subsidence_other_structures_limit >= 375001 && mine_subsidence_other_structures_limit < 400001)
  {
     return "375001"
  }
  else if(mine_subsidence_other_structures_limit >= 400001 && mine_subsidence_other_structures_limit < 425001)
  {
     return "400001"
  }
  else if(mine_subsidence_other_structures_limit >= 425001 && mine_subsidence_other_structures_limit < 450001)
  {
     return "425001"
  }
  else if(mine_subsidence_other_structures_limit >= 450001 && mine_subsidence_other_structures_limit < 475001)
  {
     return "450001"
  }
  else if(mine_subsidence_other_structures_limit >= 475001)
  {
    return "475001"
  }
}

function removeSpecialCharacters(limit)
{ 
  return limit.toString().replace(/[$,]/g, '');
}

exports.removeSpecialCharacters = removeSpecialCharacters;
exports.getMineSubsidenceOtherStructuresLimit = getMineSubsidenceOtherStructuresLimit;
exports.getMineSubsidenceDwellingLimit = getMineSubsidenceDwellingLimit;
exports.getRecipientName = getRecipientName;
exports.getAgeForDiscount = getAgeForDiscount;
exports.round = round;
exports.getInterPolatedFactor = getInterPolatedFactor;
exports.getTableNameForFlatpremiums = getTableNameForFlatpremiums;
exports.getTableName = getTableName;
exports.getRoofMaterial = getRoofMaterial;
exports.getChannel = getChannel;
exports.getAgeOfHomeForFactor = getAgeOfHomeForFactor;
exports.getWindHailDeductible = getWindHailDeductible;
exports.getAOPDeductible = getAOPDeductible;
exports.getUnitLocation = getUnitLocation;
exports.getPolicyTerm = getPolicyTerm;
exports.getInsuranceScore = getInsuranceScore;
exports.getNumberOfExposures = getNumberOfExposures;
exports.getDateOfLoss = getDateOfLoss;
exports.getInsuredAge = getInsuredAge;
exports.getRoofOrHomeAge = getRoofOrHomeAge;
exports.getCountOfChargeableClaims = getCountOfChargeableClaims;
exports.getTableObject = getTableObject;
exports.getDecimalFromPercentage = getDecimalFromPercentage;
exports.getSchedule = getSchedule;
exports.getNumberOfDaysUninsured = getNumberOfDaysUninsured;
exports.getNumberOfDaysUninsuredForTenant = getNumberOfDaysUninsuredForTenant;