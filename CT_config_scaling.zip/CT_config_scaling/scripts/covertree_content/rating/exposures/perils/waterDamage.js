let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let coverageA = require('./coverageA.js');
let coverageB = require('./coverageB.js');
let coverageC = require('./coverageC.js');

function getPremiumForWaterDamageCoverage(peril, data)
{
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);

  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let unit_address_group = exposure_fv.unit_address;
  let state = exposure_fgv[unit_address_group].state;

  let water_damage_reduced_limit = peril.characteristics[peril.characteristics.length - 1].fieldValues.water_damage_reduced_limit;
  let water_damage_premium = getWaterDamagePremium(water_damage_reduced_limit, data, state);
  return Math.round(water_damage_premium);
}

function getWaterDamagePremium(water_damage_reduced_limit, data, state)
{
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);
  let cov_a_aop;
  let cov_b_aop;
  let cov_c_aop;
  let cov_a_wind;
  let cov_b_wind;
  let cov_c_wind;

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      let coverage_a_aop = coverageA.getAOPCoverageAPremium(otherPeril, data);
      let coverage_a_windhail = coverageA.getWindstormOrHailCoverageAPremium(otherPeril, data);
      cov_a_aop = coverage_a_aop.AOP_coverage_a_premium;
      cov_a_wind = coverage_a_windhail.wind_hail_coverage_a_premium;
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_b)
    {
      let coverage_b_aop = coverageB.getAOPCoverageBPremium(otherPeril, data);
      let coverage_b_windhail = coverageB.getWindstormOrHailCoverageBPremium(otherPeril, data);
      cov_b_aop = coverage_b_aop.AOP_coverage_b_premium;
      cov_b_wind = coverage_b_windhail.wind_hail_coverage_b_premium;
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      let coverage_c_aop = coverageC.getAOPCoverageCPremium(otherPeril, data);
      let coverage_c_windhail = coverageC.getWindstormOrHailCoverageCPremium(otherPeril, data);
      cov_c_aop = coverage_c_aop.AOP_coverage_c_premium;
      cov_c_wind = coverage_c_windhail.wind_hail_coverage_c_premium;
    }
  }

  let water_damage_premium =
    WaterDamageCoveragePremium(cov_a_aop, water_damage_reduced_limit, ratingConstants.valueConstants.all_other_perils, ratingConstants.coverageConstants.coverage_a, state) +
    WaterDamageCoveragePremium(cov_b_aop, water_damage_reduced_limit, ratingConstants.valueConstants.all_other_perils, ratingConstants.coverageConstants.coverage_b, state) +
    WaterDamageCoveragePremium(cov_c_aop, water_damage_reduced_limit, ratingConstants.valueConstants.all_other_perils, ratingConstants.coverageConstants.coverage_c, state) +
    WaterDamageCoveragePremium(cov_a_wind, water_damage_reduced_limit, ratingConstants.valueConstants.windstorm_or_hail, ratingConstants.coverageConstants.coverage_a, state) +
    WaterDamageCoveragePremium(cov_b_wind, water_damage_reduced_limit, ratingConstants.valueConstants.windstorm_or_hail, ratingConstants.coverageConstants.coverage_b, state) +
    WaterDamageCoveragePremium(cov_c_wind, water_damage_reduced_limit, ratingConstants.valueConstants.windstorm_or_hail, ratingConstants.coverageConstants.coverage_c, state);
  return water_damage_premium;
}

function WaterDamageCoveragePremium(peril_total, water_damage_reduced_limit, type_constant, coverage_constant, state)
{
  let waterDamageScalingFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.water_damage_scaling_factor), coverage_constant);
  let water_damage_scaling_factor = parseFloat(waterDamageScalingFactorTable[type_constant]);
 
  let water_damage_reduced_limit_key;
  if(water_damage_reduced_limit == ratingConstants.waterDamageConstants.full_coverage)
  {
    water_damage_reduced_limit_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  }
  else
  {
     water_damage_reduced_limit_key = ratingHelpers.getDecimalFromPercentage(water_damage_reduced_limit) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  }
  let waterDamageReducedLimitFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.water_damage_reduced_limit_factor), water_damage_reduced_limit_key);
  let water_damage_reduced_limit_factor = parseFloat(waterDamageReducedLimitFactorTable[type_constant]);

  let water_damage_premium_total = ratingHelpers.round(water_damage_scaling_factor * water_damage_reduced_limit_factor * peril_total);
  
  if (!isNaN(water_damage_premium_total))
  {
    return water_damage_premium_total;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }
}

exports.getPremiumForWaterDamageCoverage = getPremiumForWaterDamageCoverage;