"use strict";

let perilNameConstants = {
  vacation_rental_coverage: "Vacation Rental Coverage",
  identity_fraud_coverage: "Identity Fraud Expense",
  hobby_farming: "Hobby - Incidental Farming",
  equipment_breakdown: "Equipment Breakdown",
  roof_exclusion: "Roof Exclusion",
  enhanced_coverage: "Enhanced Coverage",
  golf_cart: "Golf Cart",
  animal_liability: "Animal Liability",
  debris_removal: "Increased Debris Removal",
  landlord_personal_injury: "Landlord Personal Injury",
  trip_collision: "Trip Collision",
  water_backup_and_sump_overflow: "Water Backup and Sump Overflow",
  loss_assessment: "Loss Assessment",
  specific_structure_exclusion: "Specific Building - Structure Exclusion",
  trampoline_liability_extension: "Trampoline Liability Extension",
  diving_board_slide_liability_extension: "Diving Board - Slide Liability Extension",
  coverage_f: "Coverage F - Medical Payment to Others",
  coverage_e_premises_liability: "Coverage E - Premises Liability",
  scheduled_personal_property: "Scheduled Personal Property",
  coverage_e_personal_liability: "Coverage E - Personal Liability",
  coverage_a: "Coverage A - Dwelling",
  theft_limitation: "Theft Limitation",
  water_damage_coverage: "Water Damage",
  coverage_d: "Coverage D - Loss of Use",
  policy_min_coverage: "Policy Minimum Premium Coverage",
  deductibles: "Deductibles",
  coverage_b: "Coverage B - Other Structures",
  coverage_c: "Coverage C - Personal Property",
  earthquake: "Earthquake Coverage",
  mine_subsidence:"Mine Subsidence",
  mine_subsidence_dwelling: "Mine Subsidence - Dwelling",
  mine_subsidence_other_structures: "Mine Subsidence - Other Structures",
  mine_subsidence_ale:"Mine Subsidence - Additional Living Expense"
  
};

let exposureNameConstants = {
  policy_level_coverages: "Policy Level Coverages",
  owner_occupied: "Owner Occupied",
  seasonal_occupied: "Seasonal Occupied",
  landlord_occupied: "Landlord Occupied",
  vacant: "Vacant",
  tenant_occupied: "Tenant Occupied"
};

let tableNameConstants = {
  earthquake_minimum_premium: "Earthquake_Minimum_Premium",
  aop_variable_factor: "AOP_Variable_Factor",
  flat_premium: "Flat_Premium",
  animal_liability: "Animal_Liability",
  debris_removal: "Debris_Removal",
  landlord_personal_injury: "Landlord_Personal_Injury",
  trip_collison_coverage: "Trip_Collison_Coverage",
  water_backup_and_sump_overflow: "Water_Backup_and_Sump_Overflow",
  loss_assessment: "Loss_Assessment",
  trampoline_liability_extension_factor_table: "Trampoline_Liability_Extension_Factor",
  diving_board_slide_liability_extension_table: "Diving_Board_Slide_Liability_Extension",
  coverage_f_base_rates: "Coverage_F_Base_Rates",
  premises_liability_table: "Premises_Liability_Table",
  scheduled_personal_property: "Scheduled_Personal_Property",
  personal_liability_table: "Personal_Liability_Table",
  form_factor: "Form_Factor",
  age_of_home_factor: "Age_of_Home_Factor",
  age_of_insured_factor: "Age_of_Insured_Factor",
  insurance_score_factor: "Insurance_Score_Factor",
  water_damage_scaling_factor: "Water_Damage_Scaling_Factor",
  water_damage_reduced_limit_factor: "Water_Damage_Reduced_Limit_Factor",
  coverage_limit_factor: "Coverage_Limit_Factor",
  distribution_channel_factor: "Distribution_Channel_Factor",
  coverage_base_rates: "Coverage_Base_Rates",
  home_type_factor: "Home_Type_Factor",
  occasional_vacation_rental_coverage_factor: "Occasional_Vacation_Rental_Coverage_Factor",
  occupancy_factor: "Occupancy_Factor",
  roof_conditon_factor_table: "Roof_Conditon_Factor_Table",
  roof_age_factor: "Roof_Age_Factor",
  roof_material_factor: "Roof_Material_Factor",
  settlement_option_factor: "Settlement_Option_Factor",
  association_discount_factor: "Association_Discount_Factor",
  community_policy_discount_factor: "Community_Policy_Discount_Factor",
  paperless_discount_factor: "Paperless_Discount_Factor",
  supplemental_heating_surcharge_factor: "Supplemental_Heating_Surcharge_Factor",
  loss_chargeable_matrix: "Loss_Chargeable_Matrix",
  paid_in_full_discount_factor: "Paid_In_Full_Discount_Factor",
  calendar_year_modifier: "Calendar_Year_Modifier",
  community_status_factor: "Community_Status_Factor",
  claims_free_discount_factor: "Claims_Free_Discount_Factor",
  multi_policy_discount_factor: "Multi_Policy_Discount_Factor",
  short_term_rental_surcharge_factor: "Short-Term_Rental_Surcharge_Factor",
  earthquake_deductible_factor: "Earthquake_Deductible_Factor",
  inspection_fees: "Inspection_Fees",
  policy_minimum_premium: "Policy_Minimum_Premium",
  price_protection_table: "Price_Protection_Table",
  claims_surcharge_factor: "Claims_Surcharge_Factor",
  multi_unit_discount_factor: "Multi_Unit_Discount_Factor",
  prior_lapse_surcharge_factor: "Prior_Lapse_Surcharge_Factor",
  windstorm_or_hail_variable_factor: "Windstorm_and_Hail_Variable_Factor",
  theft_limitation: "Theft_Limitation",
  territory_factor: "Territory_Factor",
  mine_subsidence:"Mine_Subsidence",
  mine_subsidence_county:"Mine_Subsidence_County",
  private_fire_company_tax_credit_factor:"Private_Fire_Company_Tax_Credit_Factor",
  private_fire_company_tax_credit_zip_codes:"Private_Fire_Company_Tax_Credit_Zip_Codes",
  home_discount_factor: "Home_Discount_Factor",
  maximum_effective_calender_year_table:"Maximum_Effective_Calender_Year_Table",
  commission_table: "Commission_Table",
  agent_commission_table: "Agent_Commission_Table",
  mine_subsidence_dwelling: "Mine_Subsidence_Dwelling",
  mine_subsidence_other_structures:"Mine_Subsidence_Other_Structures",
  mine_subsidence_ale:"Mine_Subsidence_Additional_Living_Expense",
  wrought_iron_bar_discount_factor:"Wrought_Iron_Bar_Discount_Factor",
  burglar_alarm_discount_factor:"Burglar_Alarm_Discount_Factor",
  aop_greater_deductible:"AOP_Greater_Deductible",
  wind_hail_greater_deductible:"Wind_Hail_Greater_Deductible"
};

let flatPremiumKeys = {
  enhanced_coverage: "Enhanced Coverage",
  golf_cart: "Golf Cart Physical Damage and Liability Extension",
  hobby_farming: "Hobby Farming",
  identity_fraud_expense: "Identity Fraud Expense",
  roof_exclusion: "Roof Exclusion",
  specific_structure_exclusion: "Specific Structure Exclusion"
};

let tableKeyConstants = {
  rate: "Rate",
  theft_limitation: "Theft Limitation",
  metal_elastomeric_coated: "Metal - Elastomeric Coated (e.g. Kool Seal, Henry)"
};

let numberConstants = {
  zero: 0,
  zero_point_one: 0.1,
  one_point_five: 1.5,
  one_point_two: 1.2,
  one: 1,
  two: 2,
  three: 3,
  five: 5,
  eight: 8,
  ten: 10,
  twenty: 20,
  twenty_two_point_five: 22.5,
  thirty_one: 31,
  fifty: 50,
  fifty_five: 55,
  ninty_one: 91,
  hundred: 100,
  five_hundred: 500,
  twenty_twenty_two: 2022,
  twenty_twenty_seven: 2027,
  one_lakh_fifty_thousand: 150000,
  five_lakh: 500000,
  fifty_lakh: 5000000
};

let applicationInitConstants = {
  d2c: "Direct to Consumer",
  internal_agent:"Internal Agent",
  broker: "Brokered"
};

let schedulePropertyConstants = {
  stamps: "Stamps/Books",
  cameras: "Camera/Recorder/Media",
  rare_and_current_coins: "Rare and Current Coins",
  fine_arts: "Fine Arts",
  furs: "Furs",
  golf_equipment: "Golfer's Equipment",
  guns_and_ammunition: "Guns and Ammunition",
  jewelry: "Jewelry",
  musical_instruments: "Musical Instruments",
  silverware: "Silverware",
  all_other: "All Other",
  tools: "Tools",
  bikes: "Bikes",
  computer_equipment: "Computer Equipment"
};

let schedulePropertyKeyConstants = {
  tools: "Tools Rate",
  bikes: "Bikes Rate"
}

let binaryConstants = {
  yes: "Yes",
  no: "No"
};

let tableToObjectConstants = {
  pipe: " | ",
  hash: " # "
};

let getTableObjectConstants = {
  pipe: "|",
  hash: "#"
};

let personalLiabilityConstants = {
  Package: "Package",
  liability_only: "Liability Only"
};

let valueConstants = {
  all_other_perils: "All Other Perils",
  windstorm_or_hail: "Windstorm Or Hail",
  earthquake: "Earthquake"
};

let usageConstants = {
  tenant: "Tenant",
  non_tenant: "Non-Tenant"
};

let coverageConstants = {
  coverage_a: "A",
  coverage_b: "B",
  coverage_c: "C",
  coverage_d: "D"
};

let alphabetConstants = {
  a: "A",
  b: "B",
  c: "C",
  na: "N/A"
};

let policyMinPremiumKeys = {
  policy_written: "Policy - Written",
  policy_earned: "Policy - Earned",
  earthquake_written: "Earthquake - Written"
};

let numberOfDaysUninsuredConstants = {
  buying_process: "I am currently in the buying process",
  one_to_seven_days_ago: "1-7 days ago",
  eight_to_thirty_days_ago: "8-30 days ago",
  thirtyone_to_ninty_days_ago: "31-90 days ago",
  more_than_ninty_days: "More than 90 days ago",
  never_insured: "My home has never been insured",
  buying_new_home: "No, I'm buying a new home",
  no_insurance: "No, I don't have insurance today",
  switching_carriers: "Yes, I am thinking about switching carriers"
};

let paymentConstants = {
  full_pay: "Full Pay",
  lienholder_billed: "Lienholder/Mortgage Billed",
  payment_plan: "Payment Plan",
  mortgage_bill: "Mortgagee Bill",
  two_pay: "2-Pay",
  eleven_pay: "11-Pay"
};

let discountConstants = {
  association_discount: "Affinity/Association Discount",
  multi_policy_discount: "Multi Policy Discount",
  multi_unit_discount: "Multi Unit Discount",
  paperless_discount: "Paperless Discount",
  claims_free_discount: "Claims Free Discount",
  paid_in_full_discount: "Paid in Full Discount",
  community_policy_discount: "Community Policy Discount",
  private_fire_company_tax_credit_discount: "Private Fire Company Tax Credit Discount",
  home_discount: "Auto/Home Discount",
  age_of_home_discount: "Age of Home Discount",
  mature_discount: "Mature Discount",
  community_discount: "Community Discount",
  roof_condition_discount: "Roof Condition Discount",
  new_roof_discount: "New Roof Discount",
  burglar_alarm_discount: "Burglar Alarm Discount",
  wrought_iron_bar_discount: "Wrought Iron Bar Discount"
};

let stateConstants = {
  oh : "OH",
  az : "AZ",
  mi : "MI",
  nm : "NM",
  in : "IN"
};
let mineSubsidenceConstants = {
   not_applied : "Not Applied",
   mandatory : "Mandatory",
   Optional : "Optional"
};
let maxValue = {
   roof_age : 20,
   home_age : 50,
   claims_surcharge : 4,
   multi_unit_discount : 5
};
let waterDamageConstants = {
  full_coverage: "Full Coverage"
};

let roofConditionConstants = {
  excellent: "Excellent",
  good: "Good",
  unknown: "Unknown"
};

let operationConstants = {

  new_business : "new_business"

};

let commissionsConstants = {
  d2c_commission : "Direct to Consumer Commission",
  ct_commission_from_agent_commission: "CT Commission",
  independent_agent_commission: "Agent Commission",
  ct_commission: "CT Commission",
  agent_commission: "Independent Agent Commission",
  agency_commission: "Independent Agency Commission",
  agent_id: "Agent ID"
};

let deductibleInterpolateConstants = {
    deductible_interpolate : "100%"
};
exports.deductibleInterpolateConstants = deductibleInterpolateConstants;
exports.commissionsConstants = commissionsConstants;
exports.operationConstants = operationConstants;
exports.roofConditionConstants = roofConditionConstants;
exports.waterDamageConstants = waterDamageConstants;
exports.maxValue = maxValue;
exports.mineSubsidenceConstants = mineSubsidenceConstants;
exports.stateConstants = stateConstants;
exports.discountConstants = discountConstants;
exports.paymentConstants = paymentConstants;
exports.numberOfDaysUninsuredConstants = numberOfDaysUninsuredConstants;
exports.getTableObjectConstants = getTableObjectConstants;
exports.policyMinPremiumKeys = policyMinPremiumKeys;
exports.coverageConstants = coverageConstants;
exports.alphabetConstants = alphabetConstants;
exports.usageConstants = usageConstants;
exports.valueConstants = valueConstants;
exports.personalLiabilityConstants = personalLiabilityConstants;
exports.schedulePropertyConstants = schedulePropertyConstants;
exports.numberConstants = numberConstants;
exports.tableKeyConstants = tableKeyConstants;
exports.exposureNameConstants = exposureNameConstants;
exports.perilNameConstants = perilNameConstants;
exports.tableNameConstants = tableNameConstants;
exports.flatPremiumKeys = flatPremiumKeys;
exports.binaryConstants = binaryConstants;
exports.tableToObjectConstants = tableToObjectConstants;
exports.applicationInitConstants = applicationInitConstants;
exports.schedulePropertyKeyConstants = schedulePropertyKeyConstants;