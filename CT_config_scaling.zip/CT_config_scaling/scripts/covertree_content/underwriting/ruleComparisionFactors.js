const exposureNameConstants = {
    owner_occupied: "Owner Occupied",
    seasonal_occupied: "Seasonal Occupied",
    landlord_occupied: "Landlord Occupied",
    tenant_occupied: "Tenant Occupied",
    vacant: "Vacant",
    policy_level_coverages: "Policy Level Coverages"
};

const dateFormat = {
    year_month_date: "YYYY-MM-DD"
};

const endorsementConstants = {
    nb_endorsement:"modification.policy.create",
    policy_endorsement : "policy_endorsement"
}

const numberConstants = {
    thirty: 30,
    five_hundred: 500,
    one_thousand: 1000,
    ten_thousand: 10000,
    five_thousand: 5000,
    five_lakh: 500000,
    three_lakh: 300000,
    one_lakh: 100000,
    twenty_five_hundred: 2500,
    hundred: 100,
    nine_nine_nine_nine: 9999,
    five: 5,
    eighteen: 18,
    twenty_five_thousand: 25000,
    thirty_five_thousand: 35000,
    fifty_thousand: 50000,
    fifteen:15,
    zero: 0,
    two: 2,
    three: 3,
    six: 6,
    twelve: 12,
    thirty_one: 31,
    one: 1,
    uw_nine: 0.9,
    uw_one: 1,
    uw_ones: 1.3,
    uw_seven: 0.7,
    six_twenty_one: 621,
    nine_nine_nine: 999,
    twenty_thousand: 20000,
    six_seventy_five: 675,
    zero_to_seven: 0 - 7,
    eight_to_thirty: 8 - 30,
    ninty_one: 91,
    empty: "",
    two_fifty : 250
};
const policy = {
    uw_trust: "Trust",
    nod: "Number of Day Uninsured",
    one_seven: "1-7 days ago",
    eight_thirty: "8-30 days ago",
    more_than_ninty: "More than 90 days ago",
    my_home: "My home has never been insured"
}
const uwDetails = {
    uw_reject: "Reject(X)",
    uw_refer: "Referral(R)"
}

const perilNameConstants = {
    mine_subsidence_dwelling : "Mine Subsidence - Dwelling",
    mine_subsidence_other_structures: "Mine Subsidence - Other Structures",
    mine_subsidence_additional_living_expense: "Mine Subsidence - Additional Living Expense",
    mine_subsidence: "Mine Subsidence",
    dwelling: "Coverage A - Dwelling",
    other_structures: "Coverage B - Other Structures",
    personal_property: "Coverage C - Personal Property",
    loss_of_use: "Coverage D - Loss of Use",
    personal_liability: "Coverage E - Personal Liability",
    premises_liability: "Coverage E - Premises Liability",
    medical_payments: "Coverage F - Medical Payment to Others",
    damage_to_property_others: "Damage to Property of Others",
    animal_liability: "Animal Liability",
    golf_cart: "Golf Cart",
    deductibles: "Deductibles",
    water_damage: "Water Damage",
    fungi_wet: "Fungi, Wet or Dry Rot, or Bacteria Property",
    hobby_incidental_farming: "Hobby - Incidental Farming",
    inflation_guard: "Inflation Guard",
    schedule_personal_property: "Scheduled Personal Property",
    landlord_personal_injury: "Landlord Personal Injury",
    minimum_premium_coverage: "Policy Minimum Premium Coverage",
    inspection_fees_coverage: "Inspection Fees Coverage",
    price_protection_coverage: "Price Protection Coverage",
    roof_exclusion: "Roof Exclusion",
    builders_risk: "Builder's Risk",
    trampoline_liability_extension: "Trampoline Liability Extension",
    diving_board: "Diving Board - Slide Liability Extension",
    specific_structure_exclusion: "Specific Building - Structure Exclusion",
};

const perilValueConstants = {
    actual_cash_value: "Actual Cash Value",
    replacement_cost: "Replacement Cost",
    extended_replacement_cost: "Extended Replacement Cost",
    jewelry: "Jewelry",
    guns_and_amminition: "Guns and Ammunition",
    fine_arts: "Fine Arts",
    stamps_books: "Stamps/Books",
    camera_recorder_media: "Camera/Recorder/Media",
    rare_and_current_coins: "Rare and Current Coins",
    computer_equipment: "Computer Equipment",
    furs: "Furs",
    golf_equipment: "Golfer's Equipment",
    musical_instruments: "Musical Instruments",
    silverware: "Silverware",
    tools: "Tools",
    bikes: "Bikes",
    all_other: "All Other",
    excluded: "Excluded"
};

const decisions = {
    manual_accept: "Accept",
    manual_reject: "Reject",
    uw_accept: "accept",
    uw_reject: "reject",
    uw_none: "none"
};

const binaryConstants = {
    uw_yes: "Yes",
    uw_no: "No",
    uw_open: "Open",
    uw_three: "3%"
};

const operationConstants = {
    new_business: "new_business",
    endorsement: "endorsement",
    renewal: "renewal"
}
const messageConstants = {
    wrought_iron: "Please answer \"Does the home have wrought iron bars on all the windows and doors?\".",
    burglar_alarm: "Please answer \"Does the home have a burglar alarm?\".",
    in_mine_cov_b: "Mine Subsidence - Other Structures cannot be selected without Coverage B - Other Structures.",
    nm_cov_c: "Actual Cash Value cannot be selected as Personal Property Settlement Option for New Mexico State.",
    nm_dwelling: "Actual Cash Value cannot be selected as Dwelling Settlement Option for New Mexico State.",
    wind_hail_five_hundred: "The value for Wind/Hail Deductible cannot be $500 for ",
    mine_subsidence_dwelling : "Mine Subsidence - Dwelling cannot be selected for ",
    mine_subsidence_other_structures: "Mine Subsidence - Other Structures cannot be selected for ",
    mine_subsidence_additional_living_expense: "Mine Subsidence - Additional Living Expense cannot be selected for ",
    mine_subsidence:"A 15 day waiting preiod is required before adding Mine Subsidence. Please change your effective date.",
    claim_date_current_year: "Date of Loss cannot be in the future.",
    endorsement:"Based on changes in liability please contact us to review your insurance.",
    premises_liability_limit: "Due to the amount of liability requested please contact us to review your insurance.",
    roof_exclusion_1: "Verify Roof will be replaced.",
    roof_exlusion_2 : "Verify Roof has been replaced and remove exclusion. If not replaced set policy for non-renewal.",
    new_business_specific: "Specific Building/Structure Exclusion coverage cannot be selected for New Business.",
    vacant_nm_cov_a: "For Vacant Exposure Replacement Cost cannot be selected as Dwelling Settlement Option  for ",
    vacant_nm: "For Vacant Exposure Replacement Cost cannot be selected as Personal Property Settlement Option for  ",
    property_address: "Policy cannot be offered for this Unit location.",
    unit_id: " Please contact us to review your insurance. ",
    home_owenership: "Please specify when the ownership of the home was taken.",
    inflation: "Inflation Guard Coverage can be selected only if Dwelling Settlement type is Replacement Cost or Extended Replacement Cost.",
    coverage_a: "Coverage A - Dwelling should be selected.",
    coverage_d_mandotory: "Coverage D - Loss of Use should be selected.",
    wind_aop_deductible: "Wind/Hail Deductible should be greater than or equal to AOP Deductible.",
    trampoline_safety_net: "Trampoline Liability Extension cannot be selected.",
    diving: "Diving Board/ Slide Liability Extension cannot be selected.",
    fungi: "For Fungi, Wet or Dry Rot, or Bacteria Property Coverage, Water Damage Coverage should be selected.",
    water: "Water Damage coverage is not applicable for Basic form.",
    days_lapsed: "Due to the number of days the home has gone uninsured please contact us to review your insurance.",
    cov_b_cov_a: "Dwelling Settlement Option should be equal to Other Structures Settlement Option.",
    uw_ref: "Due to the location of this home please contact us to review your insurance.",
    uw_rjct: "Due to the location of this home we are unable to offer a policy at this time.",
    relationship_organization: "Due to a relationship of Other please contact us to review your insurance.",
    status_open: "Due to an open claim please contact us to review your insurance.",
    accept_notes: "Accepted",
    model_year_nm: "Extended Replacement Cost cannot be selected for homes older than 30 years.",
    model_year: "Replacement or Extended Replacement Cost cannot be selected for homes older than 30 years.",
    processing_rule_medical_payments: "Medical Payment coverage cannot be offered without Personal/Premises Liability.",
    processing_rule_landlord: "Landlord Personal Injury cannot be offered without Premises Liability.",
    processing_rule_animal_liability: "Animal Liability cannot be offered without Personal Liability.",
    processing_rule_without_personal: "Damage to Property coverage cannot be offered without Personal Liability.",
    processing_rule_with_personal: "Damage to Property coverage should be selected with Personal Liability.",
    processing_rule_isolation: " Exposures can be offered only in isolation.",
    processing_rule_minimum_premium: "Policy Minimum Premium Coverage should be selected.",
    processing_rule_inspection_fee: "Selecting Inspection Fees Coverage is Mandatory.",
    processing_rule_price_protection: "Selecting Price Protection Coverage is Mandatory.",
    processing_rule_schedule_personal: "Schedule Personal Property cannot be offered for the given Occupancy Exposure.",
    processing_rule_policy_level_coverage: "Policy Level Coverages exposure should be added only once.",
    home_coverage: "Home Coverage must be at least $5,000.",
    deductible: "Please select Deductible for ",
    deductible_part_two: " Exposure.",
    home_type: "Based on the Home value please call us to review your insurance.",
    unscheduled_personal_property: "Based on Your Belongings value please call us to review your insurance.",
    all_other_perils: "Your Standard Deductible (AOP) must be at least $500.",
    wind_hail_deductible: "Your Wind,Hail Deductible must be at least $1,000.",
    inflation_guard: "Inflation Guard can only be added to policies with Replacement or Extended Replacement Cost as the Dwelling Settlement Option.",
    mortgage: "Due to past due mortgage payments or a pending foreclosure we are unable to offer a policy at this time.",
    four_feet_fence: "Due to an unfenced pool we are unable to offer a policy with liability at this time.",
    secure_rails: "Due to missing handrails we are unable to offer a policy with liability at this time.",
    unrepaired_damages: "Due to unrepaired damage we are unable to offer a policy at this time.",
    unit_is_tied: "Due to missing tie downs we are unable to offer a policy at this time.",
    total_square_footage: "Due to the size of the home we are unable to offer a policy at this time.",
    source_of_heat_installation: "Due to the supplemental heating device not being professionally installed we are unable to offer a policy at this time.",
    utility_services: "Due to missing utilities we are unable to offer a policy at this time.",
    property_with_fire_protection: "Due to missing fire protection or road access we are unable to offer a policy at this time.",
    shipping_containers: "We are unable to offer a policy for Shipping Container Homes at this time.",
    business_day_care: "Due to a day care we are unable to offer a policy at this time.",
    jewelry_message: "For the given Jewelry description , we are unable to offer the policy.",
    furs_message: "For the given Furs description , we are unable to offer the policy.",
    camera_recorder_media_message: "For the given Camera,Recorder,Media description , we are unable to offer the policy.",
    golf_equipment_message: "For the given Golfer’s Equipment description , we are unable to offer the policy.",
    stamps_and_coins_message: "For the given Postage Stamps and Coins description , we are unable to offer the policy.",
    guns_and_amminition_message: "For the Guns and AmmunitionJewlery description , we are unable to offer the policy.",
    fine_arts_message: "For the given Fine Artsdescription , we are unable to offer the policy.",
    musical_instruments_message: "For the given Musical Instruments description , we are unable to offer the policy.",
    silverware_message: "For the given Silverware description , we are unable to offer the policy.",
    hobby_farming: "Please select Animal Liability for the risk to be eligible",
    property_address_message: "Property cannot be located at a PO Box. Please update your property address to reflect the physical location of the home.",
    underwriting_details_message: "Due to the location of this home we are unable to offer a policy at this time.",
    conviction_message: "Due to previous arson, fraud, or other insurance related offenses we are unable to offer a policy at this time.",
    date_of_birth_message: "We are unable to offer a policy to minors at this time.",
    dwelling_settlement_option: "Based on the Home value Replacement or Extended Replacement Cost cannot be selected as the Dwelling Settlement Option.",
    home_type_stationary_nm: "For Stationary Travel Trailers Extended Replacement Cost cannot be selected as the Dwelling Settlement Option.",
    home_type_stationary: "For Stationary Travel Trailers Replacement or Extended Replacement Cost cannot be selected as the Dwelling Settlement Option.",
    policyholder_message: "Policy cannot be offered for the given risk.",
    purchase_price: "Based on the homes purchase price please contact us to review your insurance.",
    roof_condition: "Due to the reported condition of your roof an intent to repair or replace your roof and a temporary exclusion for the roof is required unless already completed. Please contact us to review your insurance.",
    type_of_fuel: "Due to a heating device of Not Listed please contact us to review your insurance.",
    vacancy_reason: "Due to a vacancy reason of \"Other\" please contact us to review your insurance.",
    thermo_static_control_reject: "Due to missing thermostatically controlled heat source we are unable to offer a policy at this time.",
    thermo_static_control: "Due to missing thermostatically controlled heat please contact us to review your insurance.",
    skirting_type: "Based on skirting please contact us to review your insurance.",
    business_on_premises: "Due to a business on the premises please contact us to review your insurance.",
    relationship_to_policyholder: "Due to a relationship of Other please contact us to review your insurance.",
    builders_risk: "Verify if building is still under renovation. If not remove coverage. If it is determine if risk should be non-renewed.",
    cancellation_renew: "Based on prior cancels/non-renewals please contact us to review your insurance.",
    rce: "Home Coverage cannot exceed the Replacement Cost of ",
    full_stop: ".",
    rce_acv: "Your Home Coverage appears to be low based on the Replacement Cost Estimate. If you believe your selection is correct please contact us to review your insurance.",
    rce_seven: "Your Home Coverage appears to be low based on the Actual Cash Value Estimate. If you believe your selection is correct please contact us to review your insurance.",
    rce_high: "Your Home Coverage appears to be high based on the Replacement Cost Estimate. If you believe your selection is correct please contact us to review your insurance.",
    animal_bite: "Based on the type of animals you have please contact us to review your insurance.",
    schedule_part_one: "Based on the value of Scheduled Personal Property ",
    spp_type_part_two: " please contact us to review your insurance.",
    stamps_books_coins: "Based on the amount of Scheduled Stamps/Books and Coins please contact us to review your insurance.",
    guns_and_amminition_msg: "Based on the amount of Scheduled Guns and Ammunition please contact us to review your insurance.",
    scheduled_personal_property: "Based on the amount of Scheduled Personal Property please contact us to review your insurance.",
    total_schedule_personal: "Based on the amount of Scheduled Personal Property please contact us to review your insurance.",
    category: "Based on Scheduled Personal Property and your claims history please contact us to review your insurance.",
    modular: "Based on the Home value please call us to review your insurance.",
    coverage_b: "Other Structures must be at least $0.",
    coverage_c: "Your Belongings must be at least $0.",
    replacement_cost: "Based on the number of claims and the selection of Replacement Cost for Personal Property Settlement Option please contact us to review your insurance.",
    fire_smoke: "Based on previous fire losses please contact us to review your insurance.",
    property_manager: "You have indicated there is more than two Property Managers/Park Owners on unit ",
    additional_interest_part_two: ". Please contact us to review your insurance.",
    chargeable_claims: "Based on the number of claims we are unable to offer a policy to you at this time. If you believe the claims on your application are incorrect please contact us.",
    number_of_claims: "Based on the number of claims please contact us to review your insurance.",
    Backdated_transactions: "Backdated transactions must be approved. Confirm your effective date is correct. If it is please contact us to review your insurance.",
    number_of_days: "Due to the number of days the home has gone uninsured please contact us to review your insurance.",
    additional_insurance: "Due to the number of people on the policy please contact us to review your insurance.",
    occupancy: "Only one unit is allowed per policy when occupancy is not Rental or Vacant. Please verify your occupancy or start a new quote.",
    annual_term: "Only annual terms are available. Please update your expiration date.",
    rate_for_thirty_days: "Rate are only honored for 30 days. Effective dates further than that are subject to change.",
    interior_water_message: "Based on previous water losses please contact us to review your insurance.",
    park_owner: "You have indicated there is more than one Park Owner on unit ",
    homeowners_association_message: "You have indicated there is more than one Homeowner's Association on unit ",
    lienholder_message: "You have indicated there are more than two Lienholders on unit ",
    MI_other_none: "Based on the Other Structures value please contact us to review your insurance.",
    golf_cart_damage: "You must purchase liability if you would like to purchase Golf Cart Physical Damage and Liability Extension coverage.",
    liability: "Based on previous liability losses please contact us to review your insurance.",
    theft_burglary: "Based on previous theft/burglary losses please contact us to review your insurance.",
    vacancy_condemned: "Due to being condemned we are unable to offer a policy at this time.",
    business_description: "For the given business description , we are unable to offer the policy.",
    third_party_consumer: "Please agree to the Disclosure.",
    scheduled_personal: "Cannot add the same Group multiple times.",
    insurance_score: "Please add \"Adverse Action\" as Insurance Score is below the Insurance threshold.",
    processing_rule_model_year: "Roof Year cannot be prior to Year Built.",
    processing_rule_current_year: "Please input model year less than or equal to current year.",
    processing_rule_roof_year: "Please input roof construction or replacement year less than or equal to current year.",
    processing_rule_trampoline: "Please select \"Would you like liability coverage extended to cover the trampoline?\" as \"Yes\"",
    community_policy_Discount: "Please provide the community policy discount.",
    additional_interest: "Please specify Type of Additional Interest.",
    daycare_on_premises: "Please specify if there is a daycare on premises.",
    business_empolyess: "Please specify if there are Business employees on premises.",
    number_of_visitors: "Please specify the number of visitors on premises in a month.",
    trampoline: "Please fill \"Would you like liability coverage extended to cover the trampoline?\".",
    diving_board: "Please fill \"Would you like liability coverage extended to cover the slide or diving board?\".",
    policy_with_liability: "Due to the number of days the home has gone uninsured we are unable to offer a policy at this time.",
    uninsured: "Due to the number of days the home has gone uninsured please contact us to review your insurance.",
    reported_condition: "Due to the reported condition of your roof an intent to repair or replace your roof and a temporary exclusion for the roof is required unless already completed. Please contact us to review your insurance.",
    multi_state_rule: "All units on a policy need to be from the same state.",
    county_in: "Mine Subsidence should be selected for the given county.",
    county_not_in: "Mine Subsidence cannot be selected for the given county.",
    county_not_in_dwelling: "Mine Subsidence - Dwelling cannot be selected for the given county.",
    county_not_in_other_structures: "Mine Subsidence - Other Structures cannot be selected for the given county.",
    county_not_in_additional_living: "Mine Subsidence - Additional Living Expense cannot be selected for the given county.",
    mine_subsidence_part_one: "Mine Subsidence cannot be selected for ",
    state_part_two: " State."
};

const descriptionConstantsreject = {
    property_address: ["PO Box", "P O Box", "P.O. Box", "Post Office Box", "PO. Box", "P. O. Box"],
};
const tableNameConstants = {
    loss_chargeable_matrix: "Loss_Chargeable_Matrix",
    all_states: "ALLStatesList_DL",
    available_State_table: "AvailableStateTable",
    mandatory_counties: "OHMandatoryCounties",
    applicable_counties: "OHApplicableCounties",
    applicable_counties_in: "INApplicableCounties",
};
const stateConstants = {
    michigan: "MI",
    california: "CA",
    washington: "WA",
    new_mexico: "NM",
    ohio: "OH",
    arizona: "AZ",
    indiana: "IN"
};


const policyValueConstants = {
    thirty_one_ninty: "31-90 days ago",
    modular: "Modular",
    fire_smoke: "Fire/Smoke",
    thirty_one_to_ninty: "31-90 days ago",
    more_than_ninty_days: "More than 90 days ago",
    theft_burglary: "Theft/Burglary",
    interior_water: "Interior Water",
    liability: "Liability",
    special: "Special",
    comprehensive: "Comprehensive",
    broad: "Broad",
    other: "Other",
    basic: "Basic",
    person: "Person",
    buying_new_home: "No, I'm buying a new home",
    no_insurance: "No, I don't have insurance today",
    switching_carriers: "Yes, I am thinking about switching carriers"
};

const exposureValueConstants = {
    stationary_travel_trailer: "Stationary Travel Trailer",
    condemned: "Condemned",
    shipping_container_home: "Shipping Container Home",
    severe: "Severe",
    uw_notlisted: "Not Listed",
    uw_notfully: "Not Fully Enclosed",
    uw_basic: "Basic",
    property_manager_park_owner: "Property Manager/Park Owner",
    lienholder: "Lienholder",
    homeowners_association: "Homeowner's Association",
    other: "Other",
    purchase_date: "I am currently in the buying process",
    one_to_seven_days_ago: "1-7 days ago",
    eight_to_thirty_days_ago: "8-30 days ago",
    thirtyone_to_ninty_days_ago: "31-90 days ago",
    more_than_ninty_day: "More than 90 days ago",
    never_insured: "My home has never been insured"

};

const fieldGroupConstants = {
    additional_interest_group: "Additional Interest"
}

exports.dateFormat = dateFormat;
exports.fieldGroupConstants = fieldGroupConstants;
exports.exposureValueConstants = exposureValueConstants
exports.policyValueConstants = policyValueConstants;
exports.tableNameConstants = tableNameConstants;
exports.stateConstants = stateConstants;
exports.endorsementConstants = endorsementConstants;
exports.messageConstants = messageConstants;
exports.binaryConstants = binaryConstants;
exports.perilValueConstants = perilValueConstants;
exports.perilNameConstants = perilNameConstants;
exports.numberConstants = numberConstants;
exports.exposureNameConstants = exposureNameConstants;
exports.decisions = decisions;
exports.descriptionConstantsreject = descriptionConstantsreject;
exports.uwDetails = uwDetails;
exports.policy = policy;
exports.operationConstants = operationConstants;