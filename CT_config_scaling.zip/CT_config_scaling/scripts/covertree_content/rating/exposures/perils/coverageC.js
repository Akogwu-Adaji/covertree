"use strict";

let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let coverageSupportFuntions = require("../coverageSupportingFunctions.js");

function getPremiumForCoverageC(peril, data)
{
  let coverage_c_aop_premium = getAOPCoverageCPremium(peril, data);
  let coverage_c_windhail_premium = getWindstormOrHailCoverageCPremium(peril, data);

  let coverage_c_premium = coverage_c_aop_premium.AOP_coverage_c_premium + coverage_c_windhail_premium.wind_hail_coverage_c_premium;
  let coverage_c_association_discount_amount = coverage_c_aop_premium.aop_association_discount_amount + coverage_c_windhail_premium.wind_hail_association_discount_amount;
  let coverage_c_multi_policy_discount_amount = coverage_c_aop_premium.aop_multi_policy_discount_amount + coverage_c_windhail_premium.wind_hail_multi_policy_discount_amount;
  let coverage_c_paperless_discount_amount = coverage_c_aop_premium.aop_paperless_discount_amount;
  let coverage_c_multi_unit_discount_amount = coverage_c_aop_premium.aop_multi_unit_discount_amount + coverage_c_windhail_premium.wind_hail_multi_unit_discount_amount;
  let coverage_c_claims_free_discount_amount = coverage_c_aop_premium.aop_claims_free_discount_amount + coverage_c_windhail_premium.wind_hail_claims_free_discount_amount;
  let coverage_c_paid_in_full_discount_amount = coverage_c_aop_premium.aop_paid_in_full_discount_amount + coverage_c_windhail_premium.wind_hail_paid_in_full_discount_amount;
  let coverage_c_community_discount_amount = coverage_c_aop_premium.aop_community_policy_discount_amount + coverage_c_windhail_premium.wind_hail_community_policy_discount_amount;
  let coverage_c_private_fire_company_tax_credit_discount_amount = coverage_c_aop_premium.aop_private_fire_company_tax_credit_discount_amount + coverage_c_windhail_premium.wind_hail_private_fire_company_tax_credit_discount_amount;
  let coverage_c_home_discount_amount = coverage_c_aop_premium.aop_home_discount_amount + coverage_c_windhail_premium.wind_hail_home_discount_amount;
  let coverage_c_age_of_home_discount_amount = coverage_c_aop_premium.aop_age_of_home_discount_amount + coverage_c_windhail_premium.wind_hail_age_of_home_discount_amount;
  let coverage_c_mature_discount_amount = coverage_c_aop_premium.aop_mature_discount_amount + coverage_c_windhail_premium.wind_hail_mature_discount_amount;
  let coverage_c_community_status_discount_amount = coverage_c_aop_premium.aop_community_discount_amount + coverage_c_windhail_premium.wind_hail_community_discount_amount;
  let coverage_c_roof_condition_discount_amount = coverage_c_aop_premium.aop_roof_condition_discount_amount + coverage_c_windhail_premium.wind_hail_roof_condition_discount_amount;
  let coverage_c_new_roof_discount_amount = coverage_c_aop_premium.aop_new_roof_discount_amount + coverage_c_windhail_premium.wind_hail_new_roof_discount_amount;
  let coverage_c_burglar_alarm_discount_amount = coverage_c_aop_premium.aop_burglar_alarm_discount_amount + coverage_c_windhail_premium.wind_hail_burglar_alarm_discount_amount;
  let coverage_c_wrought_iron_bar_discount_amount = coverage_c_aop_premium.aop_wrought_iron_bar_discount_amount + coverage_c_windhail_premium.wind_hail_wrought_iron_bar_discount_amount;


  return {
    coverage_c_premium,
    coverage_c_paperless_discount_amount,
    coverage_c_association_discount_amount,
    coverage_c_multi_policy_discount_amount,
    coverage_c_multi_unit_discount_amount,
    coverage_c_claims_free_discount_amount,
    coverage_c_paid_in_full_discount_amount,
    coverage_c_community_discount_amount,
    coverage_c_private_fire_company_tax_credit_discount_amount,
    coverage_c_home_discount_amount,
    coverage_c_age_of_home_discount_amount,
    coverage_c_mature_discount_amount,
    coverage_c_community_status_discount_amount,
    coverage_c_roof_condition_discount_amount,
    coverage_c_new_roof_discount_amount,
    coverage_c_burglar_alarm_discount_amount,
    coverage_c_wrought_iron_bar_discount_amount
  };
}

function getAOPCoverageCPremium(peril, data)
{

  let type_constant = ratingConstants.valueConstants.all_other_perils;
  let coverage_constant = ratingConstants.coverageConstants.coverage_c;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);

  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;


  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;

  let unit_address_group = exposure_fv.unit_address;
  let state = exposure_fgv[unit_address_group].state;

  let private_fire_company_tax_credit_discount_factor = ratingConstants.numberConstants.one;
  if(state == ratingConstants.stateConstants.az)
  {
    private_fire_company_tax_credit_discount_factor = coverageSupportFuntions.getPvtFireTaxCreditRetableFactor(exposure_fv,exposure_fgv,coverage_constant,type_constant);
  }

  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_aop;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant, state);

  let home_discount = policy_fgv[policy_fv.policy_basic_info].auto_policy_with_agency;
  let home_discount_factor = coverageSupportFuntions.getHomeDiscountFactor(home_discount, type_constant, coverage_constant, state);

  let home_type;
  let roof_condition;
  let roof_material;
  let age_of_roof;
  let age_of_home;
  let age_of_home_factor = ratingConstants.numberConstants.one;
  let roof_age_factor = ratingConstants.numberConstants.one;
  let roof_material_factor = ratingConstants.numberConstants.one;

  if (exposure.name != ratingConstants.exposureNameConstants.tenant_occupied)
  {
    home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
    roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
    roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
    age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy, policy_start_timestamp);
    console.log("🚀 ~ file: coverageC.js ~ line 97 ~ age_of_roof", age_of_roof)
    age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp);
    console.log("🚀 ~ file: coverageC.js ~ line 99 ~ age_of_home", age_of_home)
  }

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant, state);

  let baseRateTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.coverage_base_rates), coverage_constant);
  let AOP_coverage_c_base_rate = parseFloat(baseRateTable[type_constant]);

  if (policy_usage != ratingConstants.usageConstants.tenant)
  {
    if(age_of_home > ratingConstants.maxValue.home_age)
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.home_age + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
    else
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
  


    if (age_of_roof != null && roof_condition != null && roof_material != undefined)
    {
      if(age_of_roof > ratingConstants.maxValue.roof_age)
      {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.roof_age + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
      }
      else
      {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
      }

    }
    if (roof_material != null && roof_material != undefined)
    {
      let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_material_factor), roof_material_factor_key);
      roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
    }
  }

  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;

  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, policy_start_timestamp, type_constant, coverage_constant, state);

  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant, state);

  let coverage_limit = peril_fv.unscheduled_personal_property_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant, state);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let aop_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor;

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant, state);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant, state)

  let wrought_iron = exposure_fgv[exposure_fv.unit_level_suppl_uw].wrought_iron;
  let burglar_alarm = exposure_fgv[exposure_fv.unit_level_suppl_uw].burglar_alarm;
  let wrought_iron_bar_discount_factor = ratingConstants.numberConstants.one;
  let burglar_alarm_discount_factor = ratingConstants.numberConstants.one;
  if(state == ratingConstants.stateConstants.nm)
  {
    wrought_iron_bar_discount_factor = coverageSupportFuntions.getWroughtIronBarDiscountFactor(wrought_iron, form, coverage_constant, type_constant, state);
    burglar_alarm_discount_factor =  coverageSupportFuntions.getBurglarAlarmDiscountFactor(burglar_alarm, form, coverage_constant, type_constant, state);
  }

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant, policy_usage, state);

  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant, state);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant, state);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant, state);

  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant, state);

  let settlement_option = peril_fv.cov_c_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant, state);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant, state);


  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant, state);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_start_timestamp, policy_fv, policy_fgv, state);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant, state);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant, state);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant, state);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant, state);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant, state);

  let paperless_discount = policy_fv.paperless_discount;
  let paperless_discount_factor = coverageSupportFuntions.getPaperlessDiscountFactor(paperless_discount, policy_usage, coverage_constant, state);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant, state);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant, state);


  let aop_coverage_c_premium_with_base_rate = AOP_coverage_c_base_rate;
  
  let aop_coverage_c_premium_with_age_of_home;
  let aop_age_of_home_discount_amount;
  if(age_of_home <= ratingConstants.numberConstants.ten)
  {
    let aop_with_home_age_discount = aop_coverage_c_premium_with_base_rate * age_of_home_factor;
    aop_age_of_home_discount_amount = aop_coverage_c_premium_with_base_rate - aop_with_home_age_discount;
    aop_coverage_c_premium_with_age_of_home = aop_coverage_c_premium_with_base_rate * age_of_home_factor;
  }
  else
  {
    aop_coverage_c_premium_with_age_of_home = aop_coverage_c_premium_with_base_rate * age_of_home_factor;
  }
     
  let aop_coverage_c_premium_with_age_of_insured;
  let age = ratingHelpers.getAgeForDiscount(date_of_birth, policy_start_timestamp); 
  let aop_mature_discount_amount = ratingConstants.numberConstants.zero;
  if(age >= ratingConstants.numberConstants.fifty_five)
  {
    let aop_with_mature_discount = aop_coverage_c_premium_with_age_of_home * age_of_insured_factor;
    aop_mature_discount_amount = aop_coverage_c_premium_with_age_of_home - aop_with_mature_discount;
    aop_coverage_c_premium_with_age_of_insured = aop_coverage_c_premium_with_age_of_home * age_of_insured_factor;
  }
  else
  {
    aop_coverage_c_premium_with_age_of_insured = aop_coverage_c_premium_with_age_of_home * age_of_insured_factor;
  }

  let aop_coverage_c_premium_with_calender_year_modifier = aop_coverage_c_premium_with_age_of_insured * calendar_year_modifier_factor;
  let aop_coverage_c_premium_with_distribution_channel = aop_coverage_c_premium_with_calender_year_modifier * distribution_channel_factor;
  let aop_coverage_c_premium_with_aop_deductible =  aop_coverage_c_premium_with_distribution_channel * aop_deductible_factor;
  let aop_coverage_c_premium_with_form = aop_coverage_c_premium_with_aop_deductible * form_factor;
  let aop_coverage_c_premium_with_insurance_score = aop_coverage_c_premium_with_form * insurance_score_factor;
  let aop_coverage_c_premium_with_home_type = aop_coverage_c_premium_with_insurance_score * home_type_factor;
  let aop_coverage_c_premium_with_occasional_vacation = aop_coverage_c_premium_with_home_type * occasional_vacation_rental_factor;
  let aop_coverage_c_premium_with_occupancy = aop_coverage_c_premium_with_occasional_vacation * occupancy_factor;

  let aop_coverage_c_premium_with_community_status;
  let aop_community_discount_amount = ratingConstants.numberConstants.zero;
  if(ratingHelpers.getUnitLocation(unit_location) == ">25 Units")
  {
    let aop_with_community_discount = aop_coverage_c_premium_with_occupancy * community_status_factor;
    aop_community_discount_amount = aop_coverage_c_premium_with_occupancy - aop_with_community_discount;
    aop_coverage_c_premium_with_community_status = aop_coverage_c_premium_with_occupancy * community_status_factor;
  }
  else
  {
    aop_coverage_c_premium_with_community_status = aop_coverage_c_premium_with_occupancy * community_status_factor;
  }

  let aop_coverage_c_premium_with_roof_age;
  let aop_new_roof_discount_amount = ratingConstants.numberConstants.zero;
  if(age_of_roof < ratingConstants.numberConstants.five && roof_condition == ratingConstants.roofConditionConstants.unknown)
  {
    let aop_with_new_roof_discount = aop_coverage_c_premium_with_community_status * roof_age_factor;
    aop_new_roof_discount_amount = aop_coverage_c_premium_with_community_status - aop_with_new_roof_discount;
    aop_coverage_c_premium_with_roof_age = aop_coverage_c_premium_with_community_status * roof_age_factor;
  }
  else
  {
    aop_coverage_c_premium_with_roof_age = aop_coverage_c_premium_with_community_status * roof_age_factor;
  }
    
  let aop_coverage_c_premium_with_roof_condition;
  let aop_roof_condition_discount_amount = ratingConstants.numberConstants.zero;
  if(roof_condition == ratingConstants.roofConditionConstants.excellent || roof_condition == ratingConstants.roofConditionConstants.good)
  {
    let aop_with_roof_condition_discount = aop_coverage_c_premium_with_roof_age * roof_condition_factor;
    aop_roof_condition_discount_amount = aop_coverage_c_premium_with_roof_age - aop_with_roof_condition_discount;
    aop_coverage_c_premium_with_roof_condition = aop_coverage_c_premium_with_roof_age * roof_condition_factor;
  }
  else
  {
    aop_coverage_c_premium_with_roof_condition = aop_coverage_c_premium_with_roof_age * roof_condition_factor;
  }

  let aop_coverage_c_premium_with_roof_material = aop_coverage_c_premium_with_roof_condition * roof_material_factor;
  let aop_coverage_c_premium_with_settlement_option = aop_coverage_c_premium_with_roof_material * settlement_option_factor;
  let aop_coverage_c_premium_with_territory_factor = aop_coverage_c_premium_with_settlement_option * territory_factor;
  let aop_coverage_c_premium_with_coverage_limit = aop_coverage_c_premium_with_territory_factor * coverage_limit_factor;
  
  let aop_cov_c_premium_with_association_discount = aop_coverage_c_premium_with_coverage_limit * association_discount_factor;
  let aop_association_discount_amount = aop_coverage_c_premium_with_coverage_limit - aop_cov_c_premium_with_association_discount;

  let aop_cov_c_premium_with_home_discount = aop_cov_c_premium_with_association_discount * home_discount_factor;
  let aop_home_discount_amount = aop_cov_c_premium_with_association_discount - aop_cov_c_premium_with_home_discount;

  let aop_cov_c_premium_with_claims_free_discount = aop_cov_c_premium_with_home_discount * claims_free_discount_factor;
  let aop_claims_free_discount_amount = aop_cov_c_premium_with_home_discount - aop_cov_c_premium_with_claims_free_discount;

  let aop_cov_c_premium_with_burglar_alarm_discount = aop_cov_c_premium_with_claims_free_discount * burglar_alarm_discount_factor;
  let aop_burglar_alarm_discount_amount = aop_cov_c_premium_with_claims_free_discount - aop_cov_c_premium_with_burglar_alarm_discount;

  let aop_cov_c_premium_with_community_policy_dicount = aop_cov_c_premium_with_burglar_alarm_discount * community_policy_discount_factor;
  let aop_community_policy_discount_amount = aop_cov_c_premium_with_burglar_alarm_discount - aop_cov_c_premium_with_community_policy_dicount;

  let aop_cov_c_premium_with_multi_policy_discount = aop_cov_c_premium_with_community_policy_dicount * multi_policy_discount_factor;
  let aop_multi_policy_discount_amount = aop_cov_c_premium_with_community_policy_dicount - aop_cov_c_premium_with_multi_policy_discount;

  let aop_cov_c_premium_with_multi_unit_discount = aop_cov_c_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let aop_multi_unit_discount_amount = aop_cov_c_premium_with_multi_policy_discount - aop_cov_c_premium_with_multi_unit_discount;

  let aop_cov_c_premium_with_paid_in_full_discount = aop_cov_c_premium_with_multi_unit_discount * paid_in_full_discount_factor;
  let aop_paid_in_full_discount_amount = aop_cov_c_premium_with_multi_unit_discount - aop_cov_c_premium_with_paid_in_full_discount;

  let aop_cov_c_premium_with_wrought_iron_bar_discount = aop_cov_c_premium_with_paid_in_full_discount * wrought_iron_bar_discount_factor;
  let aop_wrought_iron_bar_discount_amount = aop_cov_c_premium_with_paid_in_full_discount - aop_cov_c_premium_with_wrought_iron_bar_discount;
 
  let aop_cov_c_premium_with_private_fire_company_tax_credit_discount = aop_cov_c_premium_with_wrought_iron_bar_discount * private_fire_company_tax_credit_discount_factor;
  let aop_private_fire_company_tax_credit_discount_amount = aop_cov_c_premium_with_wrought_iron_bar_discount - aop_cov_c_premium_with_private_fire_company_tax_credit_discount;

  let aop_cov_c_premium_with_claims_surcharge = aop_cov_c_premium_with_private_fire_company_tax_credit_discount * claims_surcharge_factor;
  let aop_cov_c_premium_with_prior_lapse_surcharge = aop_cov_c_premium_with_claims_surcharge * prior_lapse_surcharge_factor;
  let aop_cov_c_premium_with_short_term_rental_surcharge = aop_cov_c_premium_with_prior_lapse_surcharge * short_term_rental_surcharge_factor;
  

  let aop_cov_c_premium_with_paperless_discount = aop_cov_c_premium_with_short_term_rental_surcharge + paperless_discount_factor;
  let aop_paperless_discount_amount = aop_cov_c_premium_with_short_term_rental_surcharge - aop_cov_c_premium_with_paperless_discount;

  let AOP_coverage_c_premium = Math.round(aop_cov_c_premium_with_paperless_discount)
    
    let consoleLogArray = [
                         "AOP Coverage C Base Rate:" +AOP_coverage_c_base_rate,
                         "Age Of Insured Factor:" +age_of_insured_factor,
                         "distribution_channel_factor:" +distribution_channel_factor,
                         "Form Factor:" +form_factor,
                         "Insurance Score Factor:" +insurance_score_factor,
                         "Home Type Factor:" +home_type_factor,
                         "Occupancy Factor:" +occupancy_factor,
                         "Roof Condition Factor:" +roof_condition_factor,
                         "Settlement Option Factor:" +settlement_option_factor,
                         "Occasional Vacation Rental Factor:" +occasional_vacation_rental_factor,
                         "Coverage Limit Factor:" +coverage_limit_factor,
                         "Territory Factor:" +territory_factor,
                         "Calendar Year Modifier Factor:" +calendar_year_modifier_factor,
                         "Roof Material Factor:" +roof_material_factor,
                         "Community Status Factor:" +community_status_factor,
                         "Prior Lapse Surcharge Factor:" +prior_lapse_surcharge_factor,
                         "Short Term Rental Surcharge Factor:" +short_term_rental_surcharge_factor,
                         "Claims Surcharge Factor:" +claims_surcharge_factor,
                         "AOP Deductible Factor:" +aop_deductible_factor,
                         "Roof Age Factor:" +roof_age_factor,
                         "Age Of Home Factor:" +age_of_home_factor,
                         "Association Discount Factor:" +association_discount_factor,
                         "Multi Policy Discount Factor:" +multi_policy_discount_factor,
                         "Multi Unit Discount Factor:" +multi_unit_discount_factor,
                         "Claims Free Discount Factor:" +claims_free_discount_factor,
                         "Paid In Full Discount Factor:" +paid_in_full_discount_factor,
                         "Community Policy Discount Factor:" +community_policy_discount_factor,
                         "AOP Paperless Discount Amount:" +aop_paperless_discount_amount,
                         "Home discount Factor:" +home_discount_factor,
                         "Private Fire Company Tax Credit Discount Factor:" +private_fire_company_tax_credit_discount_factor
                        ]
  console.log("Coverage C All Other Peril Factors", JSON.stringify(consoleLogArray));

  return {
    AOP_coverage_c_premium,
    aop_paperless_discount_amount,
    aop_association_discount_amount,
    aop_multi_policy_discount_amount,
    aop_multi_unit_discount_amount,
    aop_claims_free_discount_amount,
    aop_paid_in_full_discount_amount,
    aop_community_policy_discount_amount,
    aop_private_fire_company_tax_credit_discount_amount,
    aop_home_discount_amount,
    aop_age_of_home_discount_amount,
    aop_mature_discount_amount,
    aop_community_discount_amount,
    aop_roof_condition_discount_amount,
    aop_new_roof_discount_amount,
    aop_burglar_alarm_discount_amount,
    aop_wrought_iron_bar_discount_amount
  }
}   
    
    

function getWindstormOrHailCoverageCPremium(peril, data)
{
  let type_constant = ratingConstants.valueConstants.windstorm_or_hail;
  let coverage_constant = ratingConstants.coverageConstants.coverage_c;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;

  let home_type;
  let roof_material;
  let roof_condition;
  let age_of_roof;
  let age_of_home;
  let age_of_home_factor = ratingConstants.numberConstants.one;
  let roof_age_factor = ratingConstants.numberConstants.one;
  let roof_material_factor = ratingConstants.numberConstants.one;

  if (exposure.name != ratingConstants.exposureNameConstants.tenant_occupied)
  {
    home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
    roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
    roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
    age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy, policy_start_timestamp);
    console.log("🚀 ~ file: coverageC.js ~ line 415 ~ age_of_roof", age_of_roof)
    age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp)
    console.log("🚀 ~ file: coverageC.js ~ line 417 ~ age_of_home", age_of_home)
  }

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;

  let unit_address_group = exposure_fv.unit_address;
  let state = exposure_fgv[unit_address_group].state;

  let private_fire_company_tax_credit_discount_factor = ratingConstants.numberConstants.one;
  if(state == ratingConstants.stateConstants.az)
  {
    private_fire_company_tax_credit_discount_factor = coverageSupportFuntions.getPvtFireTaxCreditRetableFactor(exposure_fv,exposure_fgv,coverage_constant,type_constant);
  }

  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_windhail;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant, state);
  
  let home_discount = policy_fgv[policy_fv.policy_basic_info].auto_policy_with_agency;
  let home_discount_factor = coverageSupportFuntions.getHomeDiscountFactor(home_discount, type_constant, coverage_constant, state);

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant, state);

  let baseRateTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.coverage_base_rates), coverage_constant);
  let wind_hail_coverage_c_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.windstorm_or_hail]);

  if (policy_usage != ratingConstants.usageConstants.tenant)
  {
    if(age_of_home > ratingConstants.maxValue.home_age)
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.home_age + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
    else
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.age_of_home_factor), age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }

    if (age_of_roof != null && roof_condition != null && roof_material != undefined)
    {
      if(age_of_roof > ratingConstants.maxValue.roof_age)
      {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + ratingConstants.maxValue.roof_age + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
      }
      else
      {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year, policy_start_timestamp) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_age_factor), roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
      }
    }

    if (roof_material != null && roof_material != undefined)
    {
      let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.roof_material_factor), roof_material_factor_key);
      roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
    }
  }

  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;

  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, policy_start_timestamp, type_constant, coverage_constant, state);

  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant, state);

  let coverage_limit = peril_fv.unscheduled_personal_property_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant, state);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let wind_hail_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant, state);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant, state);

  let wrought_iron = exposure_fgv[exposure_fv.unit_level_suppl_uw].wrought_iron;
  let burglar_alarm = exposure_fgv[exposure_fv.unit_level_suppl_uw].burglar_alarm;
  let wrought_iron_bar_discount_factor = ratingConstants.numberConstants.one;
  let burglar_alarm_discount_factor = ratingConstants.numberConstants.one;
  if(state == ratingConstants.stateConstants.nm)
  {
    wrought_iron_bar_discount_factor = coverageSupportFuntions.getWroughtIronBarDiscountFactor(wrought_iron, form, coverage_constant, type_constant, state);
    burglar_alarm_discount_factor =  coverageSupportFuntions.getBurglarAlarmDiscountFactor(burglar_alarm, form, coverage_constant, type_constant, state);
  }

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant, policy_usage, state);

  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant, state);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant, state);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant, state);

  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant, state);

  let settlement_option = peril_fv.cov_c_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant, state);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant, state);


  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant, state);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_start_timestamp, policy_fv, policy_fgv, state);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant, state);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant, state);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant, state);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant, state);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant, state);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant, state);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant, state);

  let wind_hail_coverage_c_premium_with_base_rate = wind_hail_coverage_c_base_rate ;
  
  let wind_hail_coverage_c_premium_with_age_of_home;
  let wind_hail_age_of_home_discount_amount = ratingConstants.numberConstants.zero;
  if(age_of_home <= ratingConstants.numberConstants.ten)
  {
    let wind_hail_with_home_age_discount = wind_hail_coverage_c_premium_with_base_rate * age_of_home_factor;
    wind_hail_age_of_home_discount_amount = wind_hail_coverage_c_premium_with_base_rate - wind_hail_with_home_age_discount;
    wind_hail_coverage_c_premium_with_age_of_home = wind_hail_coverage_c_premium_with_base_rate * age_of_home_factor;
  }
  else
  {
    wind_hail_coverage_c_premium_with_age_of_home = wind_hail_coverage_c_premium_with_base_rate * age_of_home_factor;
  }
     
  let wind_hail_coverage_c_premium_with_age_of_insured;
  let age = ratingHelpers.getAgeForDiscount(date_of_birth, policy_start_timestamp); 
  let wind_hail_mature_discount_amount = ratingConstants.numberConstants.zero;
  if(age >= ratingConstants.numberConstants.fifty_five)
  {
    let wind_hail_with_mature_discount = wind_hail_coverage_c_premium_with_age_of_home * age_of_insured_factor;
    wind_hail_mature_discount_amount = wind_hail_coverage_c_premium_with_age_of_home - wind_hail_with_mature_discount;
    wind_hail_coverage_c_premium_with_age_of_insured = wind_hail_coverage_c_premium_with_age_of_home * age_of_insured_factor;
  }
  else
  {
    wind_hail_coverage_c_premium_with_age_of_insured = wind_hail_coverage_c_premium_with_age_of_home * age_of_insured_factor;
  }

  let wind_hail_coverage_c_premium_with_calender_year_modifier = wind_hail_coverage_c_premium_with_age_of_insured * calendar_year_modifier_factor;
  let wind_hail_coverage_c_premium_with_distribution_channel = wind_hail_coverage_c_premium_with_calender_year_modifier * distribution_channel_factor;
  let wind_hail_coverage_c_premium_with_wind_hail_deductible =  wind_hail_coverage_c_premium_with_distribution_channel * wind_hail_deductible_factor;
  let wind_hail_coverage_c_premium_with_form = wind_hail_coverage_c_premium_with_wind_hail_deductible * form_factor;
  let wind_hail_coverage_c_premium_with_insurance_score = wind_hail_coverage_c_premium_with_form * insurance_score_factor;
  let wind_hail_coverage_c_premium_with_home_type = wind_hail_coverage_c_premium_with_insurance_score * home_type_factor;
  let wind_hail_coverage_c_premium_with_occasional_vacation = wind_hail_coverage_c_premium_with_home_type * occasional_vacation_rental_factor;
  let wind_hail_coverage_c_premium_with_occupancy = wind_hail_coverage_c_premium_with_occasional_vacation * occupancy_factor;

  let wind_hail_coverage_c_premium_with_community_status;
  let wind_hail_community_discount_amount = ratingConstants.numberConstants.zero;
  if(ratingHelpers.getUnitLocation(unit_location) == ">25 Units")
  {
    let wind_hail_with_community_discount = wind_hail_coverage_c_premium_with_occupancy * community_status_factor;
    wind_hail_community_discount_amount = wind_hail_coverage_c_premium_with_occupancy - wind_hail_with_community_discount;
    wind_hail_coverage_c_premium_with_community_status = wind_hail_coverage_c_premium_with_occupancy * community_status_factor;
  }
  else
  {
    wind_hail_coverage_c_premium_with_community_status = wind_hail_coverage_c_premium_with_occupancy * community_status_factor;
  }

  let wind_hail_coverage_c_premium_with_roof_age;
  let wind_hail_new_roof_discount_amount = ratingConstants.numberConstants.zero;
  if(age_of_roof < ratingConstants.numberConstants.five && roof_condition == ratingConstants.roofConditionConstants.unknown)
  {
    let wind_hail_with_new_roof_discount = wind_hail_coverage_c_premium_with_community_status * roof_age_factor;
    wind_hail_new_roof_discount_amount = wind_hail_coverage_c_premium_with_community_status - wind_hail_with_new_roof_discount;
    wind_hail_coverage_c_premium_with_roof_age = wind_hail_coverage_c_premium_with_community_status * roof_age_factor;
  }
  else
  {
    wind_hail_coverage_c_premium_with_roof_age = wind_hail_coverage_c_premium_with_community_status * roof_age_factor;
  }
    
  let wind_hail_coverage_c_premium_with_roof_condition;
  let wind_hail_roof_condition_discount_amount = ratingConstants.numberConstants.zero;
  if(roof_condition == ratingConstants.roofConditionConstants.excellent || roof_condition == ratingConstants.roofConditionConstants.good)
  {
    let wind_hail_with_roof_condition_discount = wind_hail_coverage_c_premium_with_roof_age * roof_condition_factor;
    wind_hail_roof_condition_discount_amount = wind_hail_coverage_c_premium_with_roof_age - wind_hail_with_roof_condition_discount;
    wind_hail_coverage_c_premium_with_roof_condition = wind_hail_coverage_c_premium_with_roof_age * roof_condition_factor;
  }
  else
  {
    wind_hail_coverage_c_premium_with_roof_condition = wind_hail_coverage_c_premium_with_roof_age * roof_condition_factor;
  }

  let wind_hail_coverage_c_premium_with_roof_material = wind_hail_coverage_c_premium_with_roof_condition * roof_material_factor;
  let wind_hail_coverage_c_premium_with_settlement_option = wind_hail_coverage_c_premium_with_roof_material * settlement_option_factor;
  let wind_hail_coverage_c_premium_with_territory_factor = wind_hail_coverage_c_premium_with_settlement_option * territory_factor;
  let wind_hail_coverage_c_premium_with_coverage_limit = wind_hail_coverage_c_premium_with_territory_factor * coverage_limit_factor;
  
  let wind_hail_cov_c_premium_with_association_discount = wind_hail_coverage_c_premium_with_coverage_limit * association_discount_factor;
  let wind_hail_association_discount_amount = wind_hail_coverage_c_premium_with_coverage_limit - wind_hail_cov_c_premium_with_association_discount;

  let wind_hail_cov_c_premium_with_home_discount = wind_hail_cov_c_premium_with_association_discount * home_discount_factor;
  let wind_hail_home_discount_amount = wind_hail_cov_c_premium_with_association_discount - wind_hail_cov_c_premium_with_home_discount;

  let wind_hail_cov_c_premium_with_claims_free_discount = wind_hail_cov_c_premium_with_home_discount * claims_free_discount_factor;
  let wind_hail_claims_free_discount_amount = wind_hail_cov_c_premium_with_home_discount - wind_hail_cov_c_premium_with_claims_free_discount;

  let wind_hail_cov_c_premium_with_burglar_alarm_discount = wind_hail_cov_c_premium_with_claims_free_discount * burglar_alarm_discount_factor;
  let wind_hail_burglar_alarm_discount_amount = wind_hail_cov_c_premium_with_claims_free_discount - wind_hail_cov_c_premium_with_burglar_alarm_discount;

  let wind_hail_cov_c_premium_with_community_policy_dicount = wind_hail_cov_c_premium_with_burglar_alarm_discount * community_policy_discount_factor;
  let wind_hail_community_policy_discount_amount = wind_hail_cov_c_premium_with_burglar_alarm_discount - wind_hail_cov_c_premium_with_community_policy_dicount;

  let wind_hail_cov_c_premium_with_multi_policy_discount = wind_hail_cov_c_premium_with_community_policy_dicount * multi_policy_discount_factor;
  let wind_hail_multi_policy_discount_amount = wind_hail_cov_c_premium_with_community_policy_dicount - wind_hail_cov_c_premium_with_multi_policy_discount;

  let wind_hail_cov_c_premium_with_multi_unit_discount = wind_hail_cov_c_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let wind_hail_multi_unit_discount_amount = wind_hail_cov_c_premium_with_multi_policy_discount - wind_hail_cov_c_premium_with_multi_unit_discount;

  let wind_hail_cov_c_premium_with_paid_in_full_discount = wind_hail_cov_c_premium_with_multi_unit_discount * paid_in_full_discount_factor;
  let wind_hail_paid_in_full_discount_amount = wind_hail_cov_c_premium_with_multi_unit_discount - wind_hail_cov_c_premium_with_paid_in_full_discount;
  
  let wind_hail_cov_c_premium_with_wrought_iron_bar_discount = wind_hail_cov_c_premium_with_paid_in_full_discount * wrought_iron_bar_discount_factor;
  let wind_hail_wrought_iron_bar_discount_amount = wind_hail_cov_c_premium_with_paid_in_full_discount - wind_hail_cov_c_premium_with_wrought_iron_bar_discount;
 
  let wind_hail_cov_c_premium_with_private_fire_company_tax_credit_discount = wind_hail_cov_c_premium_with_wrought_iron_bar_discount * private_fire_company_tax_credit_discount_factor;
  let wind_hail_private_fire_company_tax_credit_discount_amount = wind_hail_cov_c_premium_with_wrought_iron_bar_discount - wind_hail_cov_c_premium_with_private_fire_company_tax_credit_discount;

  let wind_hail_cov_c_premium_with_claims_surcharge = wind_hail_cov_c_premium_with_private_fire_company_tax_credit_discount * claims_surcharge_factor;
  let wind_hail_cov_c_premium_with_prior_lapse_surcharge = wind_hail_cov_c_premium_with_claims_surcharge * prior_lapse_surcharge_factor;
  let wind_hail_cov_c_premium_with_short_term_rental_surcharge = wind_hail_cov_c_premium_with_prior_lapse_surcharge * short_term_rental_surcharge_factor;
  

  let wind_hail_coverage_c_premium = Math.round(wind_hail_cov_c_premium_with_short_term_rental_surcharge);
    


  let consoleLogArray = [
                         "Wind Hail Coverage C Base Rate:" +wind_hail_coverage_c_base_rate,
                         "Age Of Insured Factor:" +age_of_insured_factor,
                         "distribution_channel_factor:" +distribution_channel_factor,
                         "Form Factor:" +form_factor,
                         "Insurance Score Factor:" +insurance_score_factor,
                         "Home Type Factor:" +home_type_factor,
                         "Occupancy Factor:" +occupancy_factor,
                         "Roof Condition Factor:" +roof_condition_factor,
                         "Settlement Option Factor:" +settlement_option_factor,
                         "Occasional Vacation Rental Factor:" +occasional_vacation_rental_factor,
                         "Coverage Limit Factor:" +coverage_limit_factor,
                         "Territory Factor:" +territory_factor,
                         "Calendar Year Modifier Factor:" +calendar_year_modifier_factor,
                         "Roof Material Factor:" +roof_material_factor,
                         "Community Status Factor:" +community_status_factor,
                         "Prior Lapse Surcharge Factor:" +prior_lapse_surcharge_factor,
                         "Short Term Rental Surcharge Factor:" +short_term_rental_surcharge_factor,
                         "Claims Surcharge Factor:" +claims_surcharge_factor,
                         "Wind Hail Deductible Factor:" +wind_hail_deductible_factor,
                         "Roof Age Factor:" +roof_age_factor,
                         "Age Of Home Factor:" +age_of_home_factor,
                         "Association Discount Factor:" +association_discount_factor,
                         "Multi Policy Discount Factor:" +multi_policy_discount_factor,
                         "Multi Unit Discount Factor:" +multi_unit_discount_factor,
                         "Claims Free Discount Factor:" +claims_free_discount_factor,
                         "Paid In Full Discount Factor:" +paid_in_full_discount_factor,
                         "Community Policy Discount Factor:" +community_policy_discount_factor,
                         "Home discount Factor:" +home_discount_factor,
                         "Private Fire Company Tax Credit Discount Factor:" +private_fire_company_tax_credit_discount_factor
                        ]
  console.log("Coverage C Wind Hail Factors", JSON.stringify(consoleLogArray));

  return {
    wind_hail_coverage_c_premium,
    wind_hail_association_discount_amount,
    wind_hail_multi_policy_discount_amount,
    wind_hail_multi_unit_discount_amount,
    wind_hail_claims_free_discount_amount,
    wind_hail_paid_in_full_discount_amount,
    wind_hail_community_policy_discount_amount,
    wind_hail_private_fire_company_tax_credit_discount_amount,
    wind_hail_home_discount_amount,
    wind_hail_age_of_home_discount_amount, 
    wind_hail_mature_discount_amount,
    wind_hail_community_discount_amount,
    wind_hail_roof_condition_discount_amount,
    wind_hail_new_roof_discount_amount,
    wind_hail_burglar_alarm_discount_amount,
    wind_hail_wrought_iron_bar_discount_amount
  }
}
    
exports.getPremiumForCoverageC = getPremiumForCoverageC;
exports.getAOPCoverageCPremium = getAOPCoverageCPremium;
exports.getWindstormOrHailCoverageCPremium = getWindstormOrHailCoverageCPremium;