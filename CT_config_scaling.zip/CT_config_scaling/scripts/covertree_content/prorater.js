let moment = require('./libraries/moment-with-locales.js');
let prorationConstants = require("./constants/constants.js");
let constantValues = require("./underwriting/ruleComparisionFactors.js");

function getProrationResult(data) {
  return {
    items: data.items.map(item => prorateItem(data, item))
  };
}

function prorateItem(data, item) {
  let fraction = getLinearFraction(data, item);
  let holdbackAmount;

  if(data.operation == prorationConstants.operationConstants.cancellation)
  {
    holdbackAmount = getholdbackAmount(data, item);
  }
  else
  {
    holdbackAmount = 0;
  }

  let amount;
  if (item.perilName == prorationConstants.perilNameConstants.trip_collision || item.type == prorationConstants.feeConstants.fee || item.perilName == prorationConstants.perilNameConstants.policy_minimum_premium) {
    amount = prorationConstants.numberConstants.zero;
  }
  else
  {
    amount = round2(fraction * parseFloat(item.amount));
  }

  return {
    id: item.id,
    proratedAmount: amount,
    holdbackAmount: holdbackAmount
  };
}

function getDaysBetweenTimestamp(end_timestamp, start_timestamp) {
  var start_time = new Date(+start_timestamp);
  start_time = moment(start_time).format(constantValues.dateFormat.year_month_date);
  var end_time = new Date(+end_timestamp);
  end_time = moment(end_time).format(constantValues.dateFormat.year_month_date);
  let days_diff = moment(new Date(end_time)).diff(new Date(start_time), 'days', true);
  console.log(Math.round(days_diff));
  return Math.round(days_diff);
}

function getLinearFraction(data, item) {
  return Math.max(0,
    Math.min(1.0,
      (getDaysBetweenTimestamp(parseInt(data.segmentSplitTimestamp), parseInt(item.segmentStartTimestamp))) /
      (getDaysBetweenTimestamp(parseInt(item.segmentEndTimestamp), parseInt(item.segmentStartTimestamp)))));
}

function getholdbackAmount(data, item) {
  if (data.operation == prorationConstants.operationConstants.cancellation) {
    let holdbackAmount = prorationConstants.numberConstants.zero;
    let policyMinPremium = parseFloat(socotraApi.tableLookup(prorationConstants.tableNameConstants.policy_Minimum_Premium, prorationConstants.tablekeyConstants.policy_earned));
    if (item.perilName == prorationConstants.perilNameConstants.trip_collision || item.type == prorationConstants.feeConstants.fee) {
      holdbackAmount = parseInt(item.amount);
    } else if (item.perilName == prorationConstants.perilNameConstants.policy_minimum_premium) {
      holdbackAmount = policyMinPremium;
    }
    return holdbackAmount;
  }
}

function round2(num) {
  return Math.round(num * 100) / 100.0;
}

exports.getProrationResult = getProrationResult;
exports.getDaysBetweenTimestamp =  getDaysBetweenTimestamp;