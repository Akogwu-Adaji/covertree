"use strict";

let ratingConstants = require('./ratingConstants.js');
let ratingHelpers = require("./helpersRating.js");
let policyLevelCoverages = require("./exposures/policyLevelCoverages.js");
let unitCoverages = require("./exposures/unitCoverages.js");
let coverageA = require('./exposures/perils/coverageA.js');
let coverageB = require('./exposures/perils/coverageB.js');
let coverageC = require('./exposures/perils/coverageC.js');
let earthquake = require('./exposures/perils/earthquake.js');
let waterDamage = require('./exposures/perils/waterDamage.js');
let flatPremiumComputations = require("./exposures/perils/flatPremiumComputations.js");
let lib = require("../libraries/lib.js");
let dates = require('../libraries/dates.js');

let sum_of_premium = ratingConstants.numberConstants.zero;

function getPerilRates(data)
{
  if(!data.tenantTimeZone)      
    throw "Missing tenantTimeZone";
  const tenantTimeZone = data.tenantTimeZone;

  lib.polyfill();

  let pricedPerilCharacteristics = {};
  let exposures = data.policy.exposures;

  let perils = exposures.flatMap((ex) => ex.perils);

  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;

  let agency_id = policy_fgv[policy_fv.agency_information].agency_id;
  let agent_id = policy_fgv[policy_fv.agency_information].agent_id;
  let application_intiation = policy_fv.application_intiation;

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let pcl = policy_exposure_peril.perilCharacteristicsLocator;
    let peril = perils.find((p) =>
      p.characteristics.some((ch) =>
        ch.locator == policy_exposure_peril.perilCharacteristicsLocator));

        let ct_commission_percent;
        let independent_agent_commission_percent;
        let agent_id_from_table;
        let table_name;
        let agent_table_name;
          if(peril.name == ratingConstants.perilNameConstants.identity_fraud_coverage || peril.name == ratingConstants.perilNameConstants.policy_min_coverage || peril.name == ratingConstants.perilNameConstants.scheduled_personal_property)
          {
            let exposure; 
            let state;
            for (exposure of exposures)
            {
              if (exposure.name != ratingConstants.exposureNameConstants.policy_level_coverages)
              {
                let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
                let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
                let unit_address_group = exposure_fv.unit_address;
                state = exposure_fgv[unit_address_group].state;

                table_name = ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.commission_table)
                agent_table_name = ratingHelpers.getTableName(state,ratingConstants.tableNameConstants.agent_commission_table)
              }
            }
          }
          else
          {
          table_name = ratingHelpers.getTableNameForFlatpremiums(peril, exposures, ratingConstants.tableNameConstants.commission_table)
          agent_table_name = ratingHelpers.getTableNameForFlatpremiums(peril, exposures, ratingConstants.tableNameConstants.agent_commission_table)
          }
           let CommissionTable = ratingHelpers.getTableObject(table_name, agency_id);
           agent_id_from_table = CommissionTable[ratingConstants.commissionsConstants.agent_id];
           if(agent_id_from_table == undefined)
           {
            let commission_key = "*" + ratingConstants.tableToObjectConstants.pipe + agent_id;
            let CommissionTable = ratingHelpers.getTableObject(agent_table_name, commission_key);
            ct_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.ct_commission]);
            independent_agent_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.independent_agent_commission]);
           }
           else if(agent_id_from_table != "*" && agent_id_from_table != undefined)
           {
              let commission_key = agency_id + ratingConstants.tableToObjectConstants.pipe + agent_id;
              let CommissionTable = ratingHelpers.getTableObject(agent_table_name, commission_key);
              ct_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.ct_commission]);
              independent_agent_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.independent_agent_commission]);
           }
           else
           {
           ct_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.ct_commission]);
           independent_agent_commission_percent = parseFloat(CommissionTable[ratingConstants.commissionsConstants.independent_agent_commission]);
           }
    
    if (peril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      let coverage_a = coverageA.getPremiumForCoverageA(peril, data);
      let coverage_a_premium =  coverage_a.coverage_a_premium;
      console.log("🚀 ~ file: ratingCalculations.js ~ line 71 ~ coverage_a_premium", coverage_a_premium)
      
      setPerilPremium(coverage_a_premium);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_a_premium)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_a_premium : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_a_premium)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_a_premium : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_a_premium)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_a_premium : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_association_discount_amount) ? coverage_a.coverage_a_association_discount_amount : 0,
        recipient: ratingConstants.discountConstants.association_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_multi_policy_discount_amount) ? coverage_a.coverage_a_multi_policy_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_multi_unit_discount_amount) ? coverage_a.coverage_a_multi_unit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_unit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_paperless_discount_amount) ? coverage_a.coverage_a_paperless_discount_amount : 0,
        recipient: ratingConstants.discountConstants.paperless_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_claims_free_discount_amount) ? coverage_a.coverage_a_claims_free_discount_amount : 0,
        recipient: ratingConstants.discountConstants.claims_free_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_paid_in_full_discount_amount) ? coverage_a.coverage_a_paid_in_full_discount_amount : 0,
        recipient: ratingConstants.discountConstants.paid_in_full_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_community_discount_amount) ? coverage_a.coverage_a_community_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_private_fire_company_tax_credit_discount_amount) ? coverage_a.coverage_a_private_fire_company_tax_credit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.private_fire_company_tax_credit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_home_discount_amount) ? coverage_a.coverage_a_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_age_of_home_discount_amount) ? coverage_a.coverage_a_age_of_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.age_of_home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_mature_discount_amount) ? coverage_a.coverage_a_mature_discount_amount : 0,
        recipient: ratingConstants.discountConstants.mature_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_community_status_discount_amount) ? coverage_a.coverage_a_community_status_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_roof_condition_discount_amount) ? coverage_a.coverage_a_roof_condition_discount_amount : 0,
        recipient: ratingConstants.discountConstants.roof_condition_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_new_roof_discount_amount) ? coverage_a.coverage_a_new_roof_discount_amount : 0,
        recipient: ratingConstants.discountConstants.new_roof_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_wrought_iron_bar_discount_amount) ? coverage_a.coverage_a_wrought_iron_bar_discount_amount : 0,
        recipient: ratingConstants.discountConstants.wrought_iron_bar_discount
      },
      {
        yearlyAmount: !isNaN(coverage_a.coverage_a_burglar_alarm_discount_amount) ? coverage_a.coverage_a_burglar_alarm_discount_amount : 0,
        recipient: ratingConstants.discountConstants.burglar_alarm_discount
      }
    ]
    let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(coverage_a_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_b)
    {
      let coverage_b = coverageB.getPremiumForCoverageB(peril, data);
      let coverage_b_premium = coverage_b.coverage_b_premium;
      console.log("🚀 ~ file: ratingCalculations.js ~ line 105 ~ coverage_b_premium", coverage_b_premium)
      setPerilPremium(coverage_b_premium);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_b_premium)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_b_premium : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_b_premium)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_b_premium : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_b_premium)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_b_premium : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_association_discount_amount) ? coverage_b.coverage_b_association_discount_amount : 0,
        recipient: ratingConstants.discountConstants.association_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_multi_policy_discount_amount) ? coverage_b.coverage_b_multi_policy_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_multi_unit_discount_amount) ? coverage_b.coverage_b_multi_unit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_unit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_claims_free_discount_amount) ? coverage_b.coverage_b_claims_free_discount_amount : 0,
        recipient: ratingConstants.discountConstants.claims_free_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_paid_in_full_discount_amount) ? coverage_b.coverage_b_paid_in_full_discount_amount : 0,
        recipient: ratingConstants.discountConstants.paid_in_full_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_community_discount_amount) ? coverage_b.coverage_b_community_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_private_fire_company_tax_credit_discount_amount) ? coverage_b.coverage_b_private_fire_company_tax_credit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.private_fire_company_tax_credit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_home_discount_amount) ? coverage_b.coverage_b_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_age_of_home_discount_amount) ? coverage_b.coverage_b_age_of_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.age_of_home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_mature_discount_amount) ? coverage_b.coverage_b_mature_discount_amount : 0,
        recipient: ratingConstants.discountConstants.mature_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_community_status_discount_amount) ? coverage_b.coverage_b_community_status_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_roof_condition_discount_amount) ? coverage_b.coverage_b_roof_condition_discount_amount : 0,
        recipient: ratingConstants.discountConstants.roof_condition_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_new_roof_discount_amount) ? coverage_b.coverage_b_new_roof_discount_amount : 0,
        recipient: ratingConstants.discountConstants.new_roof_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_wrought_iron_bar_discount_amount) ? coverage_b.coverage_b_wrought_iron_bar_discount_amount : 0,
        recipient: ratingConstants.discountConstants.wrought_iron_bar_discount
      },
      {
        yearlyAmount: !isNaN(coverage_b.coverage_b_burglar_alarm_discount_amount) ? coverage_b.coverage_b_burglar_alarm_discount_amount : 0,
        recipient: ratingConstants.discountConstants.burglar_alarm_discount
      }
    ]
    let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(coverage_b_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      let coverage_c = coverageC.getPremiumForCoverageC(peril, data);
      let coverage_c_premium = coverage_c.coverage_c_premium;
      console.log("🚀 ~ file: ratingCalculations.js ~ line 168 ~ coverage_c_premium", coverage_c_premium)
      setPerilPremium(coverage_c_premium);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_c_premium)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_c_premium : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_c_premium)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_c_premium : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_c_premium)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_c_premium : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_association_discount_amount) ? coverage_c.coverage_c_association_discount_amount : 0,
        recipient: ratingConstants.discountConstants.association_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_multi_policy_discount_amount) ? coverage_c.coverage_c_multi_policy_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_multi_unit_discount_amount) ? coverage_c.coverage_c_multi_unit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.multi_unit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_paperless_discount_amount) ? coverage_c.coverage_c_paperless_discount_amount : 0,
        recipient: ratingConstants.discountConstants.paperless_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_claims_free_discount_amount) ? coverage_c.coverage_c_claims_free_discount_amount : 0,
        recipient: ratingConstants.discountConstants.claims_free_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_paid_in_full_discount_amount) ? coverage_c.coverage_c_paid_in_full_discount_amount : 0,
        recipient: ratingConstants.discountConstants.paid_in_full_discount
      }, 
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_community_discount_amount) ? coverage_c.coverage_c_community_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_policy_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_private_fire_company_tax_credit_discount_amount) ? coverage_c.coverage_c_private_fire_company_tax_credit_discount_amount : 0,
        recipient: ratingConstants.discountConstants.private_fire_company_tax_credit_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_home_discount_amount) ? coverage_c.coverage_c_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_age_of_home_discount_amount) ? coverage_c.coverage_c_age_of_home_discount_amount : 0,
        recipient: ratingConstants.discountConstants.age_of_home_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_mature_discount_amount) ? coverage_c.coverage_c_mature_discount_amount : 0,
        recipient: ratingConstants.discountConstants.mature_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_community_status_discount_amount) ? coverage_c.coverage_c_community_status_discount_amount : 0,
        recipient: ratingConstants.discountConstants.community_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_roof_condition_discount_amount) ? coverage_c.coverage_c_roof_condition_discount_amount : 0,
        recipient: ratingConstants.discountConstants.roof_condition_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_new_roof_discount_amount) ? coverage_c.coverage_c_new_roof_discount_amount : 0,
        recipient: ratingConstants.discountConstants.new_roof_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_wrought_iron_bar_discount_amount) ? coverage_c.coverage_c_wrought_iron_bar_discount_amount : 0,
        recipient: ratingConstants.discountConstants.wrought_iron_bar_discount
      },
      {
        yearlyAmount: !isNaN(coverage_c.coverage_c_burglar_alarm_discount_amount) ? coverage_c.coverage_c_burglar_alarm_discount_amount : 0,
        recipient: ratingConstants.discountConstants.burglar_alarm_discount
      }]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(coverage_c_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_d)
    {
      let premium_for_coverage_d = unitCoverages.getPremiumForCoverageD(peril, data);
      let coverage_d_premium = premium_for_coverage_d.coverage_d_premium;
      setPerilPremium(coverage_d_premium);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_d_premium)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*coverage_d_premium : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_d_premium)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*coverage_d_premium : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_d_premium)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*coverage_d_premium : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        },
        {
          yearlyAmount: !isNaN(premium_for_coverage_d.discount_amount) ? premium_for_coverage_d.discount_amount : 0,
          recipient: ratingConstants.discountConstants.private_fire_company_tax_credit_discount
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(coverage_d_premium, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_e_premises_liability)
    {
      let premium_for_coverage_e_premises_liability = unitCoverages.getPremiumForCoverageEPremisesLiability(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 240 ~ premium_for_coverage_e_premises_liability", premium_for_coverage_e_premises_liability)
      setPerilPremium(premium_for_coverage_e_premises_liability);
      let AllCommissions =  [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_premises_liability : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_coverage_e_premises_liability, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_e_personal_liability)
    {
      let premium_for_coverage_e_personal_liability = unitCoverages.getPremiumForCoverageEPersonalLiability(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 246 ~ premium_for_coverage_e_personal_liability", premium_for_coverage_e_personal_liability)
      setPerilPremium(premium_for_coverage_e_personal_liability);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_e_personal_liability : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_coverage_e_personal_liability, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }    
    else if (peril.name == ratingConstants.perilNameConstants.coverage_f)
    {
      let premium_for_coverage_f = unitCoverages.getPremiumForCoverageF(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 252 ~ premium_for_coverage_f", premium_for_coverage_f)
      setPerilPremium(premium_for_coverage_f);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_f)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_coverage_f : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_f)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_f : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_f)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_coverage_f : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_coverage_f, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.earthquake)
    {
      let premium_for_earthquake = earthquake.getPremiumForEarthquake(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 258 ~ premium_for_earthquake", premium_for_earthquake)
      setPerilPremium(premium_for_earthquake);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_earthquake)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_earthquake : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_earthquake)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_earthquake : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission                                   
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_earthquake)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_earthquake : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_earthquake, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.identity_fraud_coverage)
    {
      let premium_for_identity_fraud_coverage = policyLevelCoverages.getPremiumForIdentityFraudExpense(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 264 ~ premium_for_identity_fraud_coverage", premium_for_identity_fraud_coverage)
      setPerilPremium(premium_for_identity_fraud_coverage);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission                                   
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_identity_fraud_coverage : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_identity_fraud_coverage, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.trip_collision)
    {
      let premium_for_trip_collision = flatPremiumComputations.getPremiumForTripCollision(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 270 ~ premium_for_trip_collision", premium_for_trip_collision)
      setPerilPremium(premium_for_trip_collision);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_trip_collision)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_trip_collision : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_trip_collision)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_trip_collision : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_trip_collision)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_trip_collision : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_trip_collision, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.scheduled_personal_property)
    {
      let premium_for_scheduled_personal_property = policyLevelCoverages.getPremiumForScheduledPersonalProperty(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 276 ~ premium_for_scheduled_personal_property", premium_for_scheduled_personal_property)
      setPerilPremium(premium_for_scheduled_personal_property);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_scheduled_personal_property : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_scheduled_personal_property, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.golf_cart)
    {
      let premium_for_golf_cart = flatPremiumComputations.getPremiumForGolfCart(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 282 ~ premium_for_golf_cart", premium_for_golf_cart)
      setPerilPremium(premium_for_golf_cart);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_golf_cart)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_golf_cart : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_golf_cart)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_golf_cart : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_golf_cart)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_golf_cart : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_golf_cart, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.water_damage_coverage)
    {
      let premium_for_water_damage_coverage = waterDamage.getPremiumForWaterDamageCoverage(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 288 ~ premium_for_water_damage_coverage", premium_for_water_damage_coverage)
      setPerilPremium(premium_for_water_damage_coverage);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_damage_coverage : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_water_damage_coverage, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
      premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
      commissions: getValidCommissions(AllCommissions)
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.hobby_farming)
    {
      let premium_hobby_farming = flatPremiumComputations.getPremiumForHobbyFarming(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 294 ~ premium_hobby_farming", premium_hobby_farming)
      setPerilPremium(premium_hobby_farming);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_hobby_farming)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_hobby_farming : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_hobby_farming)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_hobby_farming : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_hobby_farming)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_hobby_farming : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_hobby_farming, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }
    }
    else if (peril.name == ratingConstants.perilNameConstants.animal_liability)
    {
      let premium_for_animal_liability = flatPremiumComputations.getPremiumForAnimalLiability(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 300 ~ premium_for_animal_liability", premium_for_animal_liability)
      setPerilPremium(premium_for_animal_liability);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_animal_liability)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_animal_liability : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_animal_liability)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_animal_liability : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_animal_liability)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_animal_liability : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_animal_liability, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.debris_removal)
    {
      let premium_for_debris_removal = flatPremiumComputations.getPremiumForDebrisRemoval(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 306 ~ premium_for_debris_removal", premium_for_debris_removal)
      setPerilPremium(premium_for_debris_removal);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_debris_removal)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_debris_removal : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_debris_removal)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_debris_removal : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_debris_removal)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_debris_removal : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_debris_removal, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.enhanced_coverage)
    {
      let premium_for_enhanced_coverage = flatPremiumComputations.getPremiumForEnhancedCoverage(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 312 ~ premium_for_enhanced_coverage", premium_for_enhanced_coverage)
      setPerilPremium(premium_for_enhanced_coverage);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_enhanced_coverage : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_enhanced_coverage, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }   
     }
    else if (peril.name == ratingConstants.perilNameConstants.landlord_personal_injury)
    {
      let premium_for_landlord_personal_injury = flatPremiumComputations.getPremiumForLandlordPersonalInjury(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 318 ~ premium_for_landlord_personal_injury", premium_for_landlord_personal_injury)
      setPerilPremium(premium_for_landlord_personal_injury);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_landlord_personal_injury : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_landlord_personal_injury, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.loss_assessment)
    {
      let premium_for_loss_assessment = flatPremiumComputations.getPremiumForLossAssessment(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 324 ~ premium_for_loss_assessment", premium_for_loss_assessment)
      setPerilPremium(premium_for_loss_assessment);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_loss_assessment : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_loss_assessment, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }
    }
    else if (peril.name == ratingConstants.perilNameConstants.water_backup_and_sump_overflow)
    {
      let premium_for_water_backup_and_sump_overflow = flatPremiumComputations.getPremiumForWaterBackupandSumpOverflow(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 330 ~ premium_for_water_backup_and_sump_overflow", premium_for_water_backup_and_sump_overflow)
      setPerilPremium(premium_for_water_backup_and_sump_overflow);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_water_backup_and_sump_overflow : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_water_backup_and_sump_overflow, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.roof_exclusion)
    {
      let premium_for_roof_exclusion = flatPremiumComputations.getPremiumForRoofExclusion(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 336 ~ premium_for_roof_exclusion", premium_for_roof_exclusion)
      setPerilPremium(premium_for_roof_exclusion);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_roof_exclusion  : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_roof_exclusion, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }
    }
    else if (peril.name == ratingConstants.perilNameConstants.specific_structure_exclusion)
    {
      let premium_for_specific_structure_exclusion = flatPremiumComputations.getPremiumForSpecificStructureExclusion(peril, exposures);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 342 ~ premium_for_specific_structure_exclusion", premium_for_specific_structure_exclusion)
      setPerilPremium(premium_for_specific_structure_exclusion);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_specific_structure_exclusion : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_specific_structure_exclusion, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }   
    }
    else if (peril.name == ratingConstants.perilNameConstants.theft_limitation)
    {
      let premium_for_theft_limitation = unitCoverages.getPremiumForTheftLimitation(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 348 ~ premium_for_theft_limitation", premium_for_theft_limitation)
      setPerilPremium(premium_for_theft_limitation);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_theft_limitation : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_theft_limitation, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.mine_subsidence)
    {
      let premium_for_mine_subsidence = unitCoverages.getPremiumForMineSubsidence(peril, data);
      console.log("🚀 ~ file: ratingCalculations.js ~ line 354 ~ premium_for_mine_subsidence", premium_for_mine_subsidence)
      setPerilPremium(premium_for_mine_subsidence);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_mine_subsidence, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.mine_subsidence_dwelling)
    {
      let premium_for_mine_subsidence_dwelling = unitCoverages.getPremiumForMineSubsidenceDwelling(peril, data);
      setPerilPremium(premium_for_mine_subsidence_dwelling);
      let AllCommissions =  [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_dwelling : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_mine_subsidence_dwelling, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.mine_subsidence_other_structures)
    {
      let premium_for_mine_subsidence_other_structures = unitCoverages.getPremiumForMineSubsidenceOtherStructures(peril, data);
      setPerilPremium(premium_for_mine_subsidence_other_structures);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_other_structures : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_mine_subsidence_other_structures, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else if (peril.name == ratingConstants.perilNameConstants.mine_subsidence_ale)
    {
      let premium_for_mine_subsidence_ale = unitCoverages.getPremiumForMineSubsidenceALE(peril, data);
      setPerilPremium(premium_for_mine_subsidence_ale);
      let AllCommissions = [
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.d2c && !isNaN((ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale)) ? (ratingConstants.numberConstants.twenty_two_point_five/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale : 0,
          recipient: ratingConstants.commissionsConstants.d2c_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale)) ? (ct_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale : 0,
          recipient: ratingConstants.commissionsConstants.ct_commission_from_agent_commission
        },
        {
          yearlyAmount: (ratingHelpers.getChannel(application_intiation) == ratingConstants.applicationInitConstants.broker && !isNaN((independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale)) ? (independent_agent_commission_percent/ratingConstants.numberConstants.hundred)*premium_for_mine_subsidence_ale : 0,
          recipient: ratingHelpers.getRecipientName(agent_id_from_table)
        }
      ]
      let adjustedPremiumForDayAccrual = getPremiumAdjustedForDayAccrual(premium_for_mine_subsidence_ale, peril, pcl, tenantTimeZone, data.policy.originalContractStartTimestamp);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(adjustedPremiumForDayAccrual) ? adjustedPremiumForDayAccrual : 0,
        commissions: getValidCommissions(AllCommissions)
        }    
    }
    else
    {
      pricedPerilCharacteristics[pcl] = {
        premium: 0,
      };
    }
  }

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let pcl = policy_exposure_peril.perilCharacteristicsLocator;
    let peril = perils.find((p) =>
      p.characteristics.some((ch) =>
        ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (peril.name == ratingConstants.perilNameConstants.policy_min_coverage)
    {
      let exposure; 
      let state;
      for (exposure of exposures)
      {
        if (exposure.name == ratingConstants.exposureNameConstants.owner_occupied || exposure.name == ratingConstants.exposureNameConstants.seasonal_occupied || exposure.name == ratingConstants.exposureNameConstants.landlord_occupied  || exposure.name == ratingConstants.exposureNameConstants.vacant || exposure.name == ratingConstants.exposureNameConstants.tenant_occupied)
        {
          let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
          let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
          let unit_address_group = exposure_fv.unit_address;
          state = exposure_fgv[unit_address_group].state;
        }
      }
      let policy_min_coverage = getPolicyMinimumPremium(data, state, sum_of_premium);
      sum_of_premium = ratingConstants.numberConstants.zero;
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(policy_min_coverage) ? policy_min_coverage : 0
      };
    }
  }
  return {
    pricedPerilCharacteristics
  };
}

function getValidCommissions(AllCommissions){
  let commission;
  var validCommissions = new Array();
  for (commission of AllCommissions)
  {
    if(commission.yearlyAmount != 0)
    {
      validCommissions.push(commission);
    }
  }
  return validCommissions;
}

function setPerilPremium(peril_premium)
{
  if (!isNaN(peril_premium))
  {
    sum_of_premium = sum_of_premium + peril_premium;
  }
  return {
    premium: !isNaN(peril_premium) ? peril_premium : 0
  };
}

function getPolicyMinimumPremium(data, state, sum_of_premium)
{
  if(data.operation == ratingConstants.operationConstants.new_business)
  {
    let policy_min_premium = parseFloat(socotraApi.tableLookup(ratingHelpers.getTableName(state, ratingConstants.tableNameConstants.policy_minimum_premium),ratingConstants.policyMinPremiumKeys.policy_written));
    if (sum_of_premium < policy_min_premium)
    {
      let minimum_premium = policy_min_premium - sum_of_premium;
      return minimum_premium;
    }
    else
    {
      return ratingConstants.numberConstants.zero;
    }
  }
}

function getPremiumAdjustedForDayAccrual(unadjustedPremium, peril, pcl, tenantTimeZone, policyStartTimestamp)
{
  let pricedPerilCharacteristic;
  for(let char of peril.characteristics)
  {
    if(char.locator == pcl)
    {
      pricedPerilCharacteristic = char;
    }
  }
  let coverageStartTimestamp = parseInt(pricedPerilCharacteristic.coverageStartTimestamp);
  let coverageEndTimestamp = parseInt(pricedPerilCharacteristic.coverageEndTimestamp);
  policyStartTimestamp = parseInt(policyStartTimestamp);
  let unadjustedRate = unadjustedPremium;
  let daysRated = dates.dayCountByTimestamp(coverageStartTimestamp,
                                     coverageEndTimestamp,
                                     tenantTimeZone);
  let targetPremium = (unadjustedRate * daysRated / 365);
  let monthsForChar = dates.monthCountByTimestamp(coverageStartTimestamp,
                                       coverageEndTimestamp,
                                       tenantTimeZone,
                                       policyStartTimestamp);
  let returnPremium = targetPremium * 12 / monthsForChar;
  return returnPremium;
}

exports.getPerilRates = getPerilRates;