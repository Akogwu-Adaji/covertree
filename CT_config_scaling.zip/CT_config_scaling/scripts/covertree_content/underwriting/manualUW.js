let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");

function getManualUWDecision(data) {
   let uw_decisions;
   let uw_notes;
   let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
   let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
   if (policy_fgv[policy_fv.uw_details].manual_decision == constantValues.decisions.manual_reject) {
      uw_decisions = constantValues.decisions.uw_reject;
      if (policy_fgv[policy_fv.uw_details].uw_description == undefined) {
         uw_notes = constantValues.numberConstants.empty;
      } else {
         uw_notes = policy_fgv[policy_fv.uw_details].uw_description;
      }
   } else if (policy_fgv[policy_fv.uw_details].manual_decision == constantValues.decisions.manual_accept) {
      uw_decisions = constantValues.decisions.uw_accept;
      if (policy_fgv[policy_fv.uw_details].uw_description == undefined) {
         uw_notes = constantValues.numberConstants.empty;
      } else {
         uw_notes = policy_fgv[policy_fv.uw_details].uw_description;
      }
   }
   if (helpers.uw_result.uw_decisions == constantValues.decisions.uw_none) {
      uw_notes += helpers.uw_result.uw_notes;
   }
   return {
      uw_decisions,
      uw_notes
   };
}
exports.getManualUWDecision = getManualUWDecision;