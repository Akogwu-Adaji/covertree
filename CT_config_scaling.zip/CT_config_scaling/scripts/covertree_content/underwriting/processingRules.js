let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");
let moment = require("../libraries/moment-with-locales.js")

function getProcessingRulesUWDecision(data, policy_fv, policy_fgv) {
  getProcessingRules(data, policy_fv);
  getUnitConstructionGroup(data);
  getTrampolineLiability(data)
  getUnitDetails(data);
  getFungiWet(data);
  getWaterDamage(data);
  getCoverageA(data);
  getAdditionalInterest(data);
  getUnitAddress(data, policy_fv);
  getUnitLevelUnderwriting(data);
  getCoverageB(data);
  getPriorInsurance(data);
  getDeductibles(data);
  getStateSpecificRules(data);
  getPriorClaims(data);
}

function getPriorClaims(data) {
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let prior_claims_group = policy_fv.prior_claims;
  if (prior_claims_group != undefined) {
    for (let each_prior_claim of prior_claims_group) {
      let uw_claim_date = policy_fgv[each_prior_claim].claim_date;
      uw_claim_date = new Date(uw_claim_date);
      let uw_today = new Date();
      uw_today = moment(uw_today).format(constantValues.dateFormat.year_month_date);
      uw_claim_date = moment(uw_claim_date).format(constantValues.dateFormat.year_month_date);
      let days_difference = moment(new Date(uw_claim_date)).diff(new Date(uw_today), 'days', true);
      if (days_difference > 0) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.claim_date_current_year);
      }
    }
  }
}

function getPriorInsurance(data) {
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let uw_prior_insurance_details = policy_fv.prior_insurance_details;
  let uw_prior_insurance = policy_fgv[uw_prior_insurance_details].prior_insurance;
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_details_group = exposure_fv.unit_details;
      let uw_purchase_date = exposure_fgv[unit_details_group].purchase_date;
      if ((uw_prior_insurance == constantValues.policyValueConstants.buying_new_home) && (uw_purchase_date == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.home_owenership);
      }
    }
  }

}

function getCoverageA(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let perilNamesArray = [];
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.vacant && exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if ((!(perilNamesArray.indexOf(constantValues.perilNameConstants.dwelling) > -1)) && exposure.name != constantValues.exposureNameConstants.vacant) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.coverage_a);
      }
    }
    if (exposure.name != constantValues.exposureNameConstants.vacant &&
      exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if ((!(perilNamesArray.indexOf(constantValues.perilNameConstants.loss_of_use) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.coverage_d_mandotory);
      }
    }
  }
}

function getDeductibles(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let perilNamesArray = [];
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
        if (peril.name == constantValues.perilNameConstants.deductibles) {
          let wind_hail_deductible = JSON.stringify(peril_fv.wind_hail_deductible);
          wind_hail_deductible = helpers.removeSpecialCharacters(wind_hail_deductible);
          let aop_deductible = JSON.stringify(peril_fv.all_other_perils_deductible);
          aop_deductible = helpers.removeSpecialCharacters(aop_deductible)
          if (wind_hail_deductible < aop_deductible) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.wind_aop_deductible);
          }
        }
      }
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if (!(perilNamesArray.indexOf(constantValues.perilNameConstants.deductibles) > -1)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.deductible + exposure.name + constantValues.messageConstants.deductible_part_two);
      }
    }
  }
}

function getFungiWet(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let perilNamesArray = [];
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.fungi_wet) > -1) &&
        (!(perilNamesArray.indexOf(constantValues.perilNameConstants.water_damage) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.fungi);
      }
    }
  }
}

function getWaterDamage(data) {
  let allExposures = data.policy.exposures;
  let unit_details_group;
  let uw_form;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      unit_details_group = exposure_fv.unit_details;
      uw_form = exposure_fgv[unit_details_group].form;
      for (let peril of exposure.perils) {
        if (peril.name == constantValues.perilNameConstants.water_damage) {
          if (uw_form == constantValues.policyValueConstants.basic) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.water);
          }
        }
      }
    }
  }
}

function getProcessingRules(data, policy_fv) {
  let allExposures = data.policy.exposures;
  let values = data.policyholder.entity.values;
  let third_party_consumer;
  let exposureNamesArray = [];
  let perilNamesArray;
  if (values.third_party_notification_non_consumer != undefined) {
    third_party_consumer = values.third_party_notification_non_consumer;
  } else {
    third_party_consumer = helpers.getPolicyholderFieldValue("third_party_notification_non_consumer", values);
  }
  if (third_party_consumer == constantValues.binaryConstants.uw_no) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.third_party_consumer);
  }
  

  for (let exposure of allExposures) {
    perilNamesArray = [];
    exposureNamesArray = [];
    exposureNamesArray.push(exposure.name);
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      if ((exposure.name != constantValues.exposureNameConstants.tenant_occupied) && (exposure.name != constantValues.exposureNameConstants.policy_level_coverages)) {
        if (data.operation == constantValues.operationConstants.new_business && peril.name == constantValues.perilNameConstants.specific_structure_exclusion) {
          helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.new_business_specific);
        }
      }
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.medical_payments) > -1) &&
        (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_medical_payments);
      }
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.damage_to_property_others) > -1) &&
        (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_without_personal);
      }
    }

    if ((exposure.name == constantValues.exposureNameConstants.landlord_occupied) || (exposure.name == constantValues.exposureNameConstants.vacant)) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.landlord_personal_injury) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_landlord);
      }
    }
    if ((exposure.name == constantValues.exposureNameConstants.tenant_occupied) || (exposure.name == constantValues.exposureNameConstants.owner_occupied)) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.animal_liability) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_animal_liability);
      }
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.damage_to_property_others) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_with_personal);
      }
    }
  }

  for (let exposure of allExposures) {
    exposureNamesArray.push(exposure.name)
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
  }
  if ((!(exposureNamesArray.indexOf(constantValues.exposureNameConstants.policy_level_coverages) > -1)) &&
    (!(perilNamesArray.indexOf(constantValues.perilNameConstants.minimum_premium_coverage) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.processing_rule_minimum_premium);
  }
  if ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.policy_level_coverages) > -1) &&
    (!(perilNamesArray.indexOf(constantValues.perilNameConstants.minimum_premium_coverage) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.processing_rule_minimum_premium);
  }

  if ((perilNamesArray.indexOf(constantValues.perilNameConstants.schedule_personal_property) > -1) &&
    ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.seasonal_occupied) > -1 ||
      (exposureNamesArray.indexOf(constantValues.exposureNameConstants.landlord_occupied) > -1)))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.processing_rule_schedule_personal)
  }
  if ((helpers.getNumberOfExposures(allExposures) > constantValues.numberConstants.one) &&
    ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.owner_occupied) > -1) ||
      (exposureNamesArray.indexOf(constantValues.exposureNameConstants.seasonal_occupied) > -1) ||
      (exposureNamesArray.indexOf(constantValues.exposureNameConstants.tenant_occupied) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.occupancy);
  }
  if ((helpers.getNumberOfPolicyLevelExposures(allExposures) > constantValues.numberConstants.one) &&
    ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.policy_level_coverages) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_policy_level_coverage);
  }
}

function getUnitConstructionGroup(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
      (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      let uw_unit_construction_group = exposure_fv.unit_construction;
      let uw_model_year = exposure_fgv[uw_unit_construction_group].model_year;
      let roof_year = exposure_fgv[uw_unit_construction_group].roof_year_yyyy;
      let current_year = new Date();
      current_year = current_year.getFullYear();
      if (uw_model_year > roof_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_model_year);
      }
      if (uw_model_year > current_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_current_year);
      }
      if (roof_year > current_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_roof_year);
      }
    }
  }
}

function getTrampolineLiability(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let perilNamesArray = [];
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
      (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      let unit_level_suppl_uw = exposure_fv.unit_level_suppl_uw;
      let uw_trampoline_safety_net = exposure_fgv[unit_level_suppl_uw].trampoline_safety_net;
      for (let peril of exposure.perils) {
        perilNamesArray.push(peril.name);
        if (uw_trampoline_safety_net != undefined) {
          if (peril.name == constantValues.perilNameConstants.trampoline_liability_extension) {
            if ((uw_trampoline_safety_net == constantValues.binaryConstants.uw_no) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.trampoline_liability_extension) > -1))) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.trampoline_safety_net);
            }
          }
          if (peril.name == constantValues.perilNameConstants.diving_board) {
            if ((uw_trampoline_safety_net == constantValues.binaryConstants.uw_no) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.diving_board) > -1))) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.diving);
            }
          }
        }
      }
    }
  }
}

function getUnitDetails(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_details_group = exposure_fv.unit_details;
      let community_policy_discount = exposure_fgv[unit_details_group].community_policy_discount;
      if (community_policy_discount == undefined) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.community_policy_Discount);
      }
    }
  }
}

function getAdditionalInterest(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let additional_interest_group = exposure_fv.additional_interest;
      if (additional_interest_group != undefined) {
        for (let each_ad_interest of additional_interest_group) {
          let name_of_interested_party = exposure_fgv[each_ad_interest].name;
          let type_of_interest = exposure_fgv[each_ad_interest].type;
          if ((name_of_interested_party != undefined) && (type_of_interest == undefined)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.additional_interest);
          }
        }
      }
    }
  }
}

function getUnitAddress(data, policy_fv) {
  let allExposures = data.policy.exposures;
  let insurance_score = policy_fv.insurance_score;
  let statesArray = [];
  let adverse_action_group = policy_fv.adverse_action;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let uw_unit_address_group = exposure_fv.unit_address;
      let uw_state = exposure_fgv[uw_unit_address_group].state;
      statesArray.push(uw_state);
      if ((uw_state == constantValues.stateConstants.michigan) ||
        (uw_state == constantValues.stateConstants.ohio) ||
        (uw_state == constantValues.stateConstants.arizona) ||
        (uw_state == constantValues.stateConstants.new_mexico) ||
        (uw_state == constantValues.stateConstants.indiana)) {
        if ((insurance_score < constantValues.numberConstants.six_twenty_one) && (adverse_action_group == undefined)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.insurance_score);
        }
      }
      let state = socotraApi.tableLookup(constantValues.tableNameConstants.available_State_table, uw_state);
      if (state == constantValues.numberConstants.empty) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.property_address);
      }
    }
  }
  statesArray = helpers.removeDuplicateUWResults(statesArray);
  if (statesArray.length > constantValues.numberConstants.one) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.multi_state_rule);
  }
}

function getStateSpecificRules(data) {
  let state_name;
  let uw_state;
  let uw_county;
  let uw_county_in;
  let uw_county_not_in;
  let uw_county_not_in_in;
  for (let exposure of data.policy.exposures) {
    let perilNamesArray = [];
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let uw_unit_address_group = exposure_fv.unit_address;
      uw_state = exposure_fgv[uw_unit_address_group].state;
      let all_states_table = constantValues.tableNameConstants.all_states;
      state_name = socotraApi.tableLookup(all_states_table, uw_state);
      uw_county = exposure_fgv[uw_unit_address_group].county;
      uw_county_in = socotraApi.tableLookup(constantValues.tableNameConstants.mandatory_counties, uw_county);
      uw_county_not_in = socotraApi.tableLookup(constantValues.tableNameConstants.applicable_counties, uw_county);
      uw_county_not_in_in = socotraApi.tableLookup(constantValues.tableNameConstants.applicable_counties_in, uw_county);

    }
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      perilNamesArray.push(peril.name);
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
        (exposure.name != constantValues.exposureNameConstants.vacant) &&
        (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        if ((uw_state != constantValues.stateConstants.ohio) && (peril.name == constantValues.perilNameConstants.mine_subsidence)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.mine_subsidence_part_one + state_name + constantValues.messageConstants.state_part_two);
        }
        if (uw_state == constantValues.stateConstants.ohio) {
          if ((uw_county != uw_county_not_in) && (peril.name == constantValues.perilNameConstants.mine_subsidence)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.county_not_in);
          }
        }
      }
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
        (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        if ((uw_state != constantValues.stateConstants.indiana) && (peril.name == constantValues.perilNameConstants.mine_subsidence_dwelling)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.mine_subsidence_dwelling + state_name + constantValues.messageConstants.state_part_two);
        }
        if ((uw_state != constantValues.stateConstants.indiana) && (peril.name == constantValues.perilNameConstants.mine_subsidence_other_structures)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.mine_subsidence_other_structures + state_name + constantValues.messageConstants.state_part_two);
        }
        if (uw_state == constantValues.stateConstants.indiana) {
          if ((uw_county != uw_county_not_in_in) && (peril.name == constantValues.perilNameConstants.mine_subsidence_dwelling)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.county_not_in_dwelling);
          }
        }
        if (uw_state == constantValues.stateConstants.indiana) {
          if ((uw_county != uw_county_not_in_in) && (peril.name == constantValues.perilNameConstants.mine_subsidence_other_structures)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.county_not_in_other_structures);
          }
        }
        if (peril.name == constantValues.perilNameConstants.deductibles) {
          let wind_hail_deductible = JSON.stringify(peril_fv.wind_hail_deductible);
          wind_hail_deductible = helpers.removeSpecialCharacters(wind_hail_deductible);
          if (uw_state != constantValues.stateConstants.indiana && wind_hail_deductible == constantValues.numberConstants.five_hundred) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.wind_hail_five_hundred + state_name + constantValues.messageConstants.state_part_two);
          }
        }
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          let cov_a_settlement_option;
          cov_a_settlement_option = peril_fv.cov_a_settlement_option;
          if (uw_state == constantValues.stateConstants.new_mexico && cov_a_settlement_option == constantValues.perilValueConstants.actual_cash_value) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.nm_dwelling);
          }
        }
      }
      if (exposure.name == constantValues.exposureNameConstants.owner_occupied) {
        if ((uw_state != constantValues.stateConstants.indiana) && (peril.name == constantValues.perilNameConstants.mine_subsidence_additional_living_expense)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.mine_subsidence_additional_living_expense + state_name + constantValues.messageConstants.state_part_two);
        }
        if (uw_state == constantValues.stateConstants.indiana) {
          if ((uw_county != uw_county_not_in_in) && (peril.name == constantValues.perilNameConstants.mine_subsidence_additional_living_expense)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.county_not_in_additional_living);
          }
        }
      }
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.personal_property) {
          let cov_c_settlement_option;
          cov_c_settlement_option = peril_fv.cov_c_settlement_option;
          if (uw_state == constantValues.stateConstants.new_mexico && cov_c_settlement_option == constantValues.perilValueConstants.actual_cash_value) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.nm_cov_c);
          }
        }
      }
      if (exposure.name == constantValues.exposureNameConstants.vacant) {
        if (peril.name == constantValues.perilNameConstants.personal_property) {
          let cov_c_settlement_option;
          cov_c_settlement_option = peril_fv.cov_c_settlement_option;
          if ((uw_state != constantValues.stateConstants.new_mexico) && (cov_c_settlement_option == constantValues.perilValueConstants.replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.vacant_nm + state_name + constantValues.messageConstants.state_part_two)
          }
        }
      }
      if (exposure.name == constantValues.exposureNameConstants.vacant) {
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          let cov_a_settlement_option;
          cov_a_settlement_option = peril_fv.cov_a_settlement_option;
          if ((uw_state != constantValues.stateConstants.new_mexico) && (cov_a_settlement_option == constantValues.perilValueConstants.replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.vacant_nm_cov_a + state_name + constantValues.messageConstants.state_part_two);
          }
        }
      }

    }
    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
      (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      let uw_wrought_iron;
      let uw_burglar_alarm;
      let uw_unit_level_suppl_uw = exposure_fv.unit_level_suppl_uw;
      uw_wrought_iron = exposure_fgv[uw_unit_level_suppl_uw].wrought_iron;
      uw_burglar_alarm = exposure_fgv[uw_unit_level_suppl_uw].burglar_alarm;
      if (uw_state == constantValues.stateConstants.new_mexico && uw_wrought_iron == undefined) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.wrought_iron);
      }
      if (uw_state == constantValues.stateConstants.new_mexico && uw_burglar_alarm == undefined) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.burglar_alarm);
      }
    }

    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
      (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      if (uw_state == constantValues.stateConstants.indiana) {
        if ((perilNamesArray.indexOf(constantValues.perilNameConstants.mine_subsidence_other_structures) > -1) &&
          (!(perilNamesArray.indexOf(constantValues.perilNameConstants.other_structures) > -1))) {
          helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.in_mine_cov_b);
        }
      }
    }
    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) &&
      (exposure.name != constantValues.exposureNameConstants.vacant) &&
      (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      if (uw_state == constantValues.stateConstants.ohio) {
        if ((uw_county == uw_county_in) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.mine_subsidence) > -1))) {
          helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.county_in);
        }
      }
    }
    
  }
}

function getUnitLevelUnderwriting(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let perilNamesArray = [];
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_level_suppl_uw_group = exposure_fv.unit_level_suppl_uw;
      let uw_daycare_on_premises = exposure_fgv[unit_level_suppl_uw_group].daycare_on_premises;
      let uw_business_on_premises = exposure_fgv[unit_level_suppl_uw_group].business_on_premises;
      let business_employees_on_premises = exposure_fgv[unit_level_suppl_uw_group].business_employees_on_premises;
      let visitors_in_a_month = exposure_fgv[unit_level_suppl_uw_group].visitors_in_a_month;
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (uw_daycare_on_premises == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.daycare_on_premises);
      }
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (business_employees_on_premises == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.business_empolyess);
      }
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (visitors_in_a_month == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.number_of_visitors);
      }
    }
  }
}

function getCoverageB(data) {
  let allExposures = data.policy.exposures;
  let cov_b_settlement_option;
  let cov_a_settlement_option;
  for (let exposure of allExposures) {
    cov_a_settlement_option = constantValues.numberConstants.empty;
    cov_b_settlement_option = constantValues.numberConstants.empty;
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) && (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          cov_a_settlement_option = JSON.stringify(peril_fv.cov_a_settlement_option);
        }
        if (peril.name == constantValues.perilNameConstants.other_structures) {
          cov_b_settlement_option = JSON.stringify(peril_fv.cov_b_settlement_option);
        }
        if ((peril.name == constantValues.perilNameConstants.dwelling) ||
          (peril.name == constantValues.perilNameConstants.other_structures)) {
          if ((cov_a_settlement_option != undefined) &&
            (cov_b_settlement_option != undefined) &&
            (cov_a_settlement_option != constantValues.numberConstants.empty) &&
            (cov_b_settlement_option != constantValues.numberConstants.empty)) {
            if (cov_a_settlement_option != cov_b_settlement_option) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.cov_b_cov_a);
            }
          }
        }
      }
    }
  }
}
exports.getProcessingRulesUWDecision = getProcessingRulesUWDecision;